# Music search/playback integration audit

This patch adapts the music player integration to the existing Xiaozhi Taiji Pi S3 project and ESP-IDF 6.0.2 APIs.

## Changes in this audit

- `GetStatusCode()` and `Read()` are handled as `NetworkResult<int>`: transport errors are checked before reading the contained integer.
- SHA-256 authentication hashing uses the PSA Crypto API (`psa/crypto.h`) available in the ESP-IDF 6 toolchain.
- LRC timestamp parsing no longer uses `try`/`catch` or exception-based `std::stoi`/`std::stof`, because this firmware is built with C++ exceptions disabled.
- The MP3 component is declared in `main/idf_component.yml` and included in `main/CMakeLists.txt`.
- The complete `Esp32Music` declaration is included where the class is instantiated.
- Music HTTP clients use bounded reads; stopping playback joins worker threads rather than detaching workers that still reference the player.
- PCM spectrum-buffer allocation is checked and sized for a full MP3 frame; allocated memory is released during decoder cleanup.
- Network/HTTP client creation failures are checked before use.

## Validation performed

- Checked the edited source for the known legacy `GetStatusCode()`/`Read()` assignments, exception handlers, exception-based timestamp parsing, and unsafe thread detachment.
- Checked C++ delimiters and parsed `main/idf_component.yml` as YAML.
- The ZIP archive is integrity-tested after packaging.

## Validation limitation

A full ESP-IDF compile was not run in this environment because `idf.py`, the ESP32 cross-compiler, and Docker are unavailable here. The existing GitHub Actions build remains the authoritative full compile check.

## Runtime configuration note

The inherited music API code contains the secret string `your-esp32-secret-key-2024` and a hard-coded API endpoint. Build success does not prove that the remote music service will accept authentication; the secret must match the server configuration.

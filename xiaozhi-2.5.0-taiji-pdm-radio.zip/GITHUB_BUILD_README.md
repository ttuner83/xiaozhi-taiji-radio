# Xiaozhi 2.5.0 — Taiji Pi S3 PDM + Internet Radio

This source is based on the official Xiaozhi ESP32 v2.5.0 Taiji Pi S3 board and keeps the `taiji-pi-s3-pdm` variant. It adds a local web radio page on port 80.

## Build in GitHub

1. Create a new GitHub repository.
2. Upload the **contents** of this folder to the repository root (do not upload the folder itself as an extra nesting level).
3. Open **Actions**.
4. Select **Build Taiji Pi S3 PDM Radio**.
5. Click **Run workflow** and run it on `main`.
6. Wait for the job to finish successfully.
7. Open the completed workflow run and download the artifact:
   `xiaozhi-2.5.0-taiji-pi-s3-pdm-radio`
8. Inside it is `merged-binary.bin`.

The build command is:

    python scripts/build.py taiji-pi-s3 --name taiji-pi-s3-pdm

The GitHub runner supplies ESP-IDF 6.0.2, so no ESP-IDF installation is needed on the user's PC.

## Radio web page

After the board is connected to Wi-Fi, open the board's IP address in a browser:

    http://DEVICE_IP/

The page allows up to 8 stations. For each station you can enter a name, stream URL and type (MP3, AAC, OGG/Opus or WAV), save it, play it, edit it or delete it.

Station settings are stored in NVS and survive reboot.

## Important

The radio code is added to the Taiji Pi S3 board implementation without changing the PDM board selection. The build variant remains `taiji-pi-s3-pdm`.

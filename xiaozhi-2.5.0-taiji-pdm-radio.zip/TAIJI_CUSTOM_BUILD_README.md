# XiaoZhi 2.5.0 - Taiji Pi S3 PDM + local radio

Target: Taiji Pi / JC3636W518C (ESP32-S3), build variant `taiji-pi-s3-pdm`.

The supplied XiaoZhi 2.5.0 source already contains the correct PDM variant:
`main/boards/taiji-pi-s3/config.json` -> `CONFIG_TAIJIPAI_I2S_TYPE_PDM=y`.
The board source uses `NoAudioCodecSimplexPdm` for that variant and the PDM microphone pins from `config.h`.

This modified tree adds:
- local HTTP server on port 80 after Wi-Fi station connection;
- `/` web UI for up to 8 radio stations;
- NVS persistence of station name, URL and codec type;
- MP3/AAC/OGG/WAV streaming via ESP Audio Simple Decoder;
- stereo-to-mono downmix and resampling to the board's 24 kHz output;
- play/stop controls.

Build:
    python scripts/build.py taiji-pi-s3 --name taiji-pi-s3-pdm

Requires ESP-IDF >= 6.0.1; 6.1 is recommended by this source tree.
The resulting full flash image is `build/merged-binary.bin`.

Radio limitations:
- The selected codec must match the stream.
- Default is MP3.
- HTTP/HTTPS streams and HTTP redirects are supported.
- HLS/m3u8 is not implemented in this small player.
- Radio playback directly uses the board audio output and temporarily resets XiaoZhi protocol audio activity.

Web UI:
After the board is connected to Wi-Fi, open `http://<device-ip>/`.

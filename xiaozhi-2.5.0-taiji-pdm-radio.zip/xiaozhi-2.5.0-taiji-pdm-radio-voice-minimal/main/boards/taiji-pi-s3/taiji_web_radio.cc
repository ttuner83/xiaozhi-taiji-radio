#include "taiji_web_radio.h"

#include "application.h"
#include "board.h"
#include "settings.h"
#include "mcp_server.h"

#include <algorithm>
#include <cstring>
#include <cstdlib>

#include <cJSON.h>
#include <esp_audio_dec_default.h>
#include <esp_audio_simple_dec.h>
#include <esp_audio_simple_dec_default.h>
#include <esp_http_client.h>
#include <esp_log.h>
#include <esp_ae_rate_cvt.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

#define TAG "TaijiWebRadio"
#define MAX_STATIONS 8
#define HTTP_BUF_SIZE 4096
#define PCM_BUF_SIZE 8192
#define RADIO_TASK_STACK 12288

TaijiWebRadio* TaijiWebRadio::instance_ = nullptr;

static const char kHtml[] = R"HTML(
<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Taiji Pi Radio</title>
<style>
body{font-family:Arial,sans-serif;max-width:760px;margin:20px auto;padding:0 12px;background:#f4f4f4;color:#222}
h2{margin-bottom:8px}.card{background:#fff;padding:14px;margin:10px 0;border-radius:10px}
input,select,button{font-size:16px;padding:9px;margin:4px 0;box-sizing:border-box}
input{width:100%}button{cursor:pointer}.row{display:flex;gap:8px;flex-wrap:wrap}.row button{flex:1}
small{color:#666;word-break:break-all}.playing{font-weight:bold}
</style></head><body>
<h2>Taiji Pi S3 — Internet Radio</h2>
<div class="card"><div id="list">Загрузка...</div></div>
<div class="card"><b>Добавить / изменить станцию</b>
<input id="slot" type="number" min="0" max="7" value="0" placeholder="Номер 0..7">
<input id="name" placeholder="Название станции">
<input id="url" placeholder="http://... или https://...">
<select id="type"><option value="mp3">MP3</option><option value="aac">AAC</option><option value="ogg">OGG/Opus</option><option value="wav">WAV</option></select>
<div class="row"><button onclick="save()">Сохранить</button><button onclick="stop()">Стоп</button></div>
</div>
<script>
async function load(){
 let r=await fetch('/api/radios'); let a=await r.json();
 let h='';
 a.forEach((x,i)=>{if(!x.url)return;
 h+=`<div class="card"><b>${i}: ${esc(x.name||'Без названия')}</b><br><small>${esc(x.url)} [${esc(x.type||'mp3')}]</small>
 <div class="row"><button onclick="play(${i})">▶ Играть</button><button onclick="edit(${i})">Изменить</button><button onclick="del(${i})">Удалить</button></div></div>`});
 document.getElementById('list').innerHTML=h||'Станций пока нет';
}
function esc(s){return String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]))}
async function save(){
 let o={slot:+slot.value,name:name.value,url:url.value,type:type.value};
 await fetch('/api/radios',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(o)});
 load();
}
async function play(i){await fetch('/api/play?slot='+i);load()}
async function stop(){await fetch('/api/stop')}
async function del(i){await fetch('/api/radios',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({slot:i,delete:true})});load()}
async function edit(i){
 let a=await (await fetch('/api/radios')).json(),x=a[i];
 slot.value=i;name.value=x.name||'';url.value=x.url||'';type.value=x.type||'mp3';
}
load();
</script></body></html>
)HTML";

static bool ReadBody(httpd_req_t* req, std::string& body) {
    if (req->content_len <= 0 || req->content_len > 4096) {
        return false;
    }
    body.resize(req->content_len);
    size_t received = 0;
    while (received < body.size()) {
        int ret = httpd_req_recv(req, body.data() + received, body.size() - received);
        if (ret <= 0) {
            return false;
        }
        received += ret;
    }
    return true;
}

TaijiWebRadio::TaijiWebRadio() {
    instance_ = this;
    LoadStations();

    auto& mcp = McpServer::GetInstance();
    mcp.AddTool("self.radio.play",
        "Start the selected saved Internet radio station. Use for requests such as: 'Включи радио', 'Запусти радио'.",
        PropertyList(),
        [this](const PropertyList&) -> ReturnValue { return PlaySelected(); });
    mcp.AddTool("self.radio.next",
        "Switch to the next configured Internet radio station and start it. Use for requests such as: 'Следующая радиостанция', 'Переключи радио'.",
        PropertyList(),
        [this](const PropertyList&) -> ReturnValue { return NextStation(); });
    mcp.AddTool("self.radio.stop",
        "Stop Internet radio playback. Use for requests such as: 'Выключи радио', 'Останови радио'.",
        PropertyList(),
        [this](const PropertyList&) -> ReturnValue { return StopPlayback(); });
}

TaijiWebRadio::~TaijiWebRadio() {
    Stop();
    if (instance_ == this) {
        instance_ = nullptr;
    }
}

void TaijiWebRadio::LoadStations() {
    stations_.clear();
    stations_.resize(MAX_STATIONS);
    Settings settings("radio", false);
    for (int i = 0; i < MAX_STATIONS; ++i) {
        std::string key = "r" + std::to_string(i);
        std::string value = settings.GetString(key, "");
        if (value.empty()) {
            continue;
        }
        cJSON* obj = cJSON_Parse(value.c_str());
        if (!obj) {
            continue;
        }
        auto get = [&](const char* key) -> std::string {
            cJSON* item = cJSON_GetObjectItemCaseSensitive(obj, key);
            return cJSON_IsString(item) ? item->valuestring : "";
        };
        stations_[i].name = get("name");
        stations_[i].url = get("url");
        stations_[i].type = get("type");
        if (stations_[i].type.empty()) {
            stations_[i].type = "mp3";
        }
        cJSON_Delete(obj);
    }
}

void TaijiWebRadio::SaveStation(int slot, const Station& station) {
    if (slot < 0 || slot >= MAX_STATIONS) {
        return;
    }
    cJSON* obj = cJSON_CreateObject();
    cJSON_AddStringToObject(obj, "name", station.name.c_str());
    cJSON_AddStringToObject(obj, "url", station.url.c_str());
    cJSON_AddStringToObject(obj, "type", station.type.c_str());
    char* text = cJSON_PrintUnformatted(obj);
    Settings settings("radio", true);
    settings.SetString("r" + std::to_string(slot), text ? text : "");
    if (text) {
        cJSON_free(text);
    }
    cJSON_Delete(obj);
    stations_[slot] = station;
}

void TaijiWebRadio::ClearStation(int slot) {
    if (slot < 0 || slot >= MAX_STATIONS) {
        return;
    }
    Settings settings("radio", true);
    settings.EraseKey("r" + std::to_string(slot));
    stations_[slot] = Station{};
}

void TaijiWebRadio::Start() {
    if (server_) {
        return;
    }

    httpd_config_t config = HTTPD_DEFAULT_CONFIG();
    config.server_port = 80;
    config.max_uri_handlers = 12;
    config.stack_size = 8192;

    if (httpd_start(&server_, &config) != ESP_OK) {
        server_ = nullptr;
        ESP_LOGE(TAG, "Failed to start HTTP server");
        return;
    }

    httpd_uri_t root = {.uri = "/", .method = HTTP_GET, .handler = RootHandler, .user_ctx = this};
    httpd_uri_t get = {.uri = "/api/radios", .method = HTTP_GET, .handler = StationsGetHandler, .user_ctx = this};
    httpd_uri_t post = {.uri = "/api/radios", .method = HTTP_POST, .handler = StationsPostHandler, .user_ctx = this};
    httpd_uri_t play = {.uri = "/api/play", .method = HTTP_GET, .handler = PlayHandler, .user_ctx = this};
    httpd_uri_t stop = {.uri = "/api/stop", .method = HTTP_GET, .handler = StopHandler, .user_ctx = this};

    httpd_register_uri_handler(server_, &root);
    httpd_register_uri_handler(server_, &get);
    httpd_register_uri_handler(server_, &post);
    httpd_register_uri_handler(server_, &play);
    httpd_register_uri_handler(server_, &stop);

    ESP_LOGI(TAG, "Local radio server started");
}

bool TaijiWebRadio::PlaySelected() {
    int slot = current_slot_;
    if (slot < 0 || slot >= MAX_STATIONS || stations_[slot].url.empty()) {
        slot = -1;
        for (int i = 0; i < MAX_STATIONS; ++i) {
            if (!stations_[i].url.empty()) {
                slot = i;
                break;
            }
        }
    }
    if (slot < 0) {
        return false;
    }
    StartRadio(slot);
    return true;
}

bool TaijiWebRadio::NextStation() {
    int start = current_slot_;
    if (start < 0 || start >= MAX_STATIONS) {
        start = -1;
    }
    for (int n = 1; n <= MAX_STATIONS; ++n) {
        int slot = (start + n) % MAX_STATIONS;
        if (!stations_[slot].url.empty()) {
            StartRadio(slot);
            return true;
        }
    }
    return false;
}

bool TaijiWebRadio::StopPlayback() {
    StopRadio();
    return true;
}

void TaijiWebRadio::Stop() {
    StopRadio();
    if (server_) {
        httpd_stop(server_);
        server_ = nullptr;
    }
}

esp_err_t TaijiWebRadio::RootHandler(httpd_req_t* req) {
    return static_cast<TaijiWebRadio*>(req->user_ctx)->HandleRoot(req);
}
esp_err_t TaijiWebRadio::StationsGetHandler(httpd_req_t* req) {
    return static_cast<TaijiWebRadio*>(req->user_ctx)->HandleStationsGet(req);
}
esp_err_t TaijiWebRadio::StationsPostHandler(httpd_req_t* req) {
    return static_cast<TaijiWebRadio*>(req->user_ctx)->HandleStationsPost(req);
}
esp_err_t TaijiWebRadio::PlayHandler(httpd_req_t* req) {
    return static_cast<TaijiWebRadio*>(req->user_ctx)->HandlePlay(req);
}
esp_err_t TaijiWebRadio::StopHandler(httpd_req_t* req) {
    return static_cast<TaijiWebRadio*>(req->user_ctx)->HandleStop(req);
}

esp_err_t TaijiWebRadio::HandleRoot(httpd_req_t* req) {
    httpd_resp_set_type(req, "text/html; charset=utf-8");
    return httpd_resp_send(req, kHtml, HTTPD_RESP_USE_STRLEN);
}

esp_err_t TaijiWebRadio::HandleStationsGet(httpd_req_t* req) {
    cJSON* array = cJSON_CreateArray();
    for (int i = 0; i < MAX_STATIONS; ++i) {
        cJSON* obj = cJSON_CreateObject();
        cJSON_AddNumberToObject(obj, "slot", i);
        cJSON_AddStringToObject(obj, "name", stations_[i].name.c_str());
        cJSON_AddStringToObject(obj, "url", stations_[i].url.c_str());
        cJSON_AddStringToObject(obj, "type", stations_[i].type.c_str());
        cJSON_AddBoolToObject(obj, "playing", current_slot_ == i && radio_task_ != nullptr);
        cJSON_AddItemToArray(array, obj);
    }
    char* text = cJSON_PrintUnformatted(array);
    cJSON_Delete(array);
    httpd_resp_set_type(req, "application/json");
    esp_err_t ret = httpd_resp_send(req, text ? text : "[]", HTTPD_RESP_USE_STRLEN);
    if (text) {
        cJSON_free(text);
    }
    return ret;
}

esp_err_t TaijiWebRadio::HandleStationsPost(httpd_req_t* req) {
    std::string body;
    if (!ReadBody(req, body)) {
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Invalid body");
        return ESP_OK;
    }
    cJSON* obj = cJSON_Parse(body.c_str());
    if (!obj) {
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Invalid JSON");
        return ESP_OK;
    }

    cJSON* slot_item = cJSON_GetObjectItem(obj, "slot");
    int slot = cJSON_IsNumber(slot_item) ? slot_item->valueint : -1;
    cJSON* del = cJSON_GetObjectItem(obj, "delete");
    if (cJSON_IsTrue(del)) {
        StopRadio();
        ClearStation(slot);
    } else {
        cJSON* name = cJSON_GetObjectItem(obj, "name");
        cJSON* url = cJSON_GetObjectItem(obj, "url");
        cJSON* type = cJSON_GetObjectItem(obj, "type");
        if (slot < 0 || slot >= MAX_STATIONS || !cJSON_IsString(url)) {
            cJSON_Delete(obj);
            httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Invalid station");
            return ESP_OK;
        }
        Station station;
        station.name = cJSON_IsString(name) ? name->valuestring : "";
        station.url = url->valuestring;
        station.type = cJSON_IsString(type) ? type->valuestring : "mp3";
        if (station.url.size() > 400 || station.name.size() > 80) {
            cJSON_Delete(obj);
            httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Too long");
            return ESP_OK;
        }
        if (station.type != "mp3" && station.type != "aac" &&
            station.type != "ogg" && station.type != "wav") {
            station.type = "mp3";
        }
        SaveStation(slot, station);
    }
    cJSON_Delete(obj);
    httpd_resp_set_type(req, "application/json");
    return httpd_resp_sendstr(req, "{\"ok\":true}");
}

esp_err_t TaijiWebRadio::HandlePlay(httpd_req_t* req) {
    char query[64];
    char value[16];
    if (httpd_req_get_url_query_str(req, query, sizeof(query)) != ESP_OK ||
        httpd_query_key_value(query, "slot", value, sizeof(value)) != ESP_OK) {
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "slot required");
        return ESP_OK;
    }
    int slot = atoi(value);
    if (slot < 0 || slot >= MAX_STATIONS || stations_[slot].url.empty()) {
        httpd_resp_send_err(req, HTTPD_404_NOT_FOUND, "Station not found");
        return ESP_OK;
    }
    StartRadio(slot);
    return httpd_resp_sendstr(req, "{\"ok\":true}");
}

esp_err_t TaijiWebRadio::HandleStop(httpd_req_t* req) {
    StopRadio();
    return httpd_resp_sendstr(req, "{\"ok\":true}");
}

void TaijiWebRadio::StartRadio(int slot) {
    StopRadio();
    if (slot < 0 || slot >= MAX_STATIONS || stations_[slot].url.empty()) {
        return;
    }

    // Stop the XiaoZhi protocol/audio activity before direct radio playback.
    Application::GetInstance().ResetProtocol();
    vTaskDelay(pdMS_TO_TICKS(150));

    radio_stop_ = false;
    current_slot_ = slot;
    xTaskCreate(RadioTaskEntry, "radio_stream", RADIO_TASK_STACK, this, 4, &radio_task_);
}

void TaijiWebRadio::StopRadio() {
    radio_stop_ = true;
    if (radio_task_) {
        // Give the streaming task time to close the HTTP connection.
        for (int i = 0; i < 30 && radio_task_; ++i) {
            vTaskDelay(pdMS_TO_TICKS(20));
        }
    }
    current_slot_ = -1;
}

void TaijiWebRadio::RadioTaskEntry(void* arg) {
    auto* self = static_cast<TaijiWebRadio*>(arg);
    self->RadioTask();
    self->radio_task_ = nullptr;
    vTaskDelete(nullptr);
}

static esp_audio_simple_dec_type_t DecoderType(const std::string& type) {
    if (type == "aac") return ESP_AUDIO_SIMPLE_DEC_TYPE_AAC;
    if (type == "ogg") return ESP_AUDIO_SIMPLE_DEC_TYPE_OGG;
    if (type == "wav") return ESP_AUDIO_SIMPLE_DEC_TYPE_WAV;
    return ESP_AUDIO_SIMPLE_DEC_TYPE_MP3;
}

void TaijiWebRadio::RadioTask() {
    if (current_slot_ < 0 || current_slot_ >= MAX_STATIONS) {
        return;
    }
    RadioTaskImpl(stations_[current_slot_]);
}

void TaijiWebRadio::RadioTaskImpl(const Station& station) {
    auto codec = Board::GetInstance().GetAudioCodec();
    if (!codec) {
        return;
    }

    esp_http_client_config_t http_cfg = {};
    http_cfg.url = station.url.c_str();
    http_cfg.timeout_ms = 10000;
    http_cfg.buffer_size = HTTP_BUF_SIZE;
    http_cfg.buffer_size_tx = 1024;
    http_cfg.disable_auto_redirect = false;
    http_cfg.max_redirection_count = 5;

    esp_http_client_handle_t client = esp_http_client_init(&http_cfg);
    if (!client) {
        ESP_LOGE(TAG, "HTTP client init failed");
        return;
    }

    esp_audio_dec_register_default();
    esp_audio_simple_dec_register_default();

    esp_audio_simple_dec_cfg_t dec_cfg = {};
    dec_cfg.dec_type = DecoderType(station.type);
    dec_cfg.use_frame_dec = false;

    esp_audio_simple_dec_handle_t decoder = nullptr;
    auto dec_ret = esp_audio_simple_dec_open(&dec_cfg, &decoder);
    if (dec_ret != ESP_AUDIO_ERR_OK || !decoder) {
        ESP_LOGE(TAG, "Decoder open failed: %d", dec_ret);
        esp_audio_simple_dec_unregister_default();
        esp_audio_dec_unregister_default();
        esp_http_client_cleanup(client);
        return;
    }

    uint8_t* input = static_cast<uint8_t*>(malloc(HTTP_BUF_SIZE));
    uint8_t* pcm = static_cast<uint8_t*>(malloc(PCM_BUF_SIZE));
    if (!input || !pcm) {
        free(input);
        free(pcm);
        esp_audio_simple_dec_close(decoder);
        esp_audio_simple_dec_unregister_default();
        esp_audio_dec_unregister_default();
        esp_http_client_cleanup(client);
        return;
    }

    esp_err_t ret = esp_http_client_open(client, 0);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "HTTP open failed: %s", esp_err_to_name(ret));
        goto cleanup;
    }
    if (esp_http_client_fetch_headers(client) < 0) {
        ESP_LOGE(TAG, "HTTP headers failed");
        goto cleanup;
    }
    if (esp_http_client_get_status_code(client) < 200 ||
        esp_http_client_get_status_code(client) >= 400) {
        ESP_LOGE(TAG, "HTTP status %d", esp_http_client_get_status_code(client));
        goto cleanup;
    }

    codec->EnableInput(false);
    codec->EnableOutput(true);

    {
        esp_ae_rate_cvt_handle_t resampler = nullptr;
        int source_rate = 0;
        int source_channels = 0;
        std::vector<uint8_t> stream_data;
        stream_data.reserve(HTTP_BUF_SIZE * 2);

        while (!radio_stop_) {
            int n = esp_http_client_read(client, reinterpret_cast<char*>(input), HTTP_BUF_SIZE);
            if (n <= 0) {
                if (n < 0) {
                    ESP_LOGW(TAG, "HTTP stream ended/error");
                }
                break;
            }

            stream_data.insert(stream_data.end(), input, input + n);

            size_t consumed_total = 0;
            while (!radio_stop_ && consumed_total < stream_data.size()) {
                esp_audio_simple_dec_raw_t raw = {};
                raw.buffer = stream_data.data() + consumed_total;
                raw.len = stream_data.size() - consumed_total;
                raw.eos = false;

                esp_audio_simple_dec_out_t out = {};
                out.buffer = pcm;
                out.len = PCM_BUF_SIZE;

                auto dr = esp_audio_simple_dec_process(decoder, &raw, &out);
                if (dr == ESP_AUDIO_ERR_BUFF_NOT_ENOUGH) {
                    ESP_LOGE(TAG, "Radio PCM frame too large");
                    radio_stop_ = true;
                    break;
                }
                if (dr != ESP_AUDIO_ERR_OK) {
                    ESP_LOGW(TAG, "Radio decode error: %d", dr);
                    // A parser may need more bytes before it can decode.
                    break;
                }

                if (out.decoded_size) {
                    esp_audio_simple_dec_info_t info = {};
                    if (esp_audio_simple_dec_get_info(decoder, &info) == ESP_AUDIO_ERR_OK &&
                        info.sample_rate > 0 && info.channel > 0) {
                        const int decoded_channels = info.channel;

                        if (source_rate != static_cast<int>(info.sample_rate) ||
                            source_channels != decoded_channels) {
                            if (resampler) {
                                esp_ae_rate_cvt_close(resampler);
                                resampler = nullptr;
                            }
                            source_rate = info.sample_rate;
                            source_channels = decoded_channels;

                            if (source_rate != codec->output_sample_rate()) {
                                esp_ae_rate_cvt_cfg_t cfg = {
                                    .src_rate = static_cast<uint32_t>(source_rate),
                                    .dest_rate = static_cast<uint32_t>(codec->output_sample_rate()),
                                    .channel = 1,
                                    .bits_per_sample = ESP_AUDIO_BIT16,
                                    .complexity = 2,
                                    .perf_type = ESP_AE_RATE_CVT_PERF_TYPE_SPEED,
                                };
                                if (esp_ae_rate_cvt_open(&cfg, &resampler) != ESP_OK) {
                                    resampler = nullptr;
                                }
                            }
                        }

                        int sample_count = out.decoded_size / sizeof(int16_t) / decoded_channels;
                        if (decoded_channels > 1) {
                            // Downmix interleaved PCM to mono.
                            int16_t* samples_in = reinterpret_cast<int16_t*>(pcm);
                            for (int i = 0; i < sample_count; ++i) {
                                int32_t sum = 0;
                                for (int c = 0; c < decoded_channels; ++c) {
                                    sum += samples_in[i * decoded_channels + c];
                                }
                                int32_t mixed = sum / decoded_channels;
                                if (mixed < -32768) mixed = -32768;
                                if (mixed > 32767) mixed = 32767;
                                samples_in[i] = static_cast<int16_t>(mixed);
                            }
                        }

                        if (resampler) {
                            uint32_t max_out = 0;
                            esp_ae_rate_cvt_get_max_out_sample_num(resampler, sample_count, &max_out);
                            std::vector<int16_t> converted(max_out);
                            uint32_t actual = max_out;
                            esp_ae_rate_cvt_process(
                                resampler, reinterpret_cast<esp_ae_sample_t*>(pcm), sample_count,
                                reinterpret_cast<esp_ae_sample_t*>(converted.data()), &actual);
                            converted.resize(actual);
                            codec->OutputData(converted);
                        } else {
                            std::vector<int16_t> samples(
                                reinterpret_cast<int16_t*>(pcm),
                                reinterpret_cast<int16_t*>(pcm) + sample_count);
                            codec->OutputData(samples);
                        }
                    }
                }

                if (raw.consumed == 0) {
                    // Keep the unconsumed bytes and append more data on the next read.
                    break;
                }
                consumed_total += raw.consumed;
            }

            if (consumed_total > 0) {
                stream_data.erase(stream_data.begin(), stream_data.begin() + consumed_total);
            }

            // Prevent a corrupt/unsupported stream from growing RAM forever.
            if (stream_data.size() > 65536) {
                ESP_LOGE(TAG, "Radio decoder stalled; dropping buffered data");
                stream_data.clear();
            }
        }

        if (resampler) {
            esp_ae_rate_cvt_close(resampler);
        }
    }

cleanup:
    codec->EnableOutput(false);
    free(input);
    free(pcm);
    esp_audio_simple_dec_close(decoder);
    esp_audio_simple_dec_unregister_default();
    esp_audio_dec_unregister_default();
    esp_http_client_close(client);
    esp_http_client_cleanup(client);
}

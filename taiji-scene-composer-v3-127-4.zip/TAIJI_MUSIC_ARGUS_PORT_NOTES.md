# Taiji music and Argus update

Base: taiji-v123-features-port-fix1.
Reference: Zhengchen v127 music/playlist behavior and v125 Argus session/parser fixes.

## Music
- Kept Taiji's existing Meting/NetEase search implementation and independent persisted music volume.
- Replaced the JSON-only playlist input with the latest line format: one `artist|song` row per requested track.
- Playlist playback is sequential: resolve one track, wait for its natural end, then resolve the next; unavailable/short tracks are skipped.
- Added cancellation checks so a playlist cancelled by assistant takeover does not start a late track after a blocking HTTP search returns.
- Added a compact playlist position to the existing circular player status label; no 240x240 Zhengchen UI layout was copied.
- Kept Taiji's circular 360x360 display and existing volume controls/settings.

## Argus
- Replaced the older one-shot parser with the v125/v127 Argus session bootstrap and live-event parser.
- Adds session cookies/headers, longer request timeout, UAV threat record filtering, event-specific text extraction, coordinate aliases (`lat`/`latitude`, `lng`/`lon`/`longitude`), and arrays `points`/`coordinates`/`locations`.
- Prevents unrelated nested metadata (e.g. airport notices) from polluting location results.

## Validation
- ZIP integrity and source-level checks are performed when packaging.
- ESP-IDF compilation and physical-device behavior have not been run in this environment.

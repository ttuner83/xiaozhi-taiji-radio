# Taiji Pi port of Zhengchen v123 features

This archive keeps the Taiji Pi S3 PDM board target and its existing 360x360 round display, CST816S touch handling, Cozmo eyes, radio artwork, and native touch-based assistant/player controls. The Zhengchen 240x240 display layout and physical-button handlers were not copied.

Ported from Zhengchen v123:
- one-shot spoken reminders (`self.reminder.set`), including wake from idle display power-save, success chime, display color-inversion blink, and temporary reminder-volume boost/restore;
- music search/download stability improvements: longer HTTP timeout, retry for transient empty Meting responses, candidate duration/size checks, artist-only fallback when a title match is absent, and skipping known short tracks;
- configurable listening timeout and concise-by-default Wikipedia summaries.

Preserved from Taiji v95-37:
- existing round-screen UI geometry and Cozmo eye integration;
- Taiji CST816S touch mapping and the on-player `Помощник` touch button;
- all original assistant/radio/music base and current volume settings, web controls, and software music-volume scaling;
- existing radio, RSS, drone-map, playlist, and audio diagnostic code.

Build target remains `taiji-pi-s3 --name taiji-pi-s3-pdm --language ru-RU --wake-word wn9_hiandy_tts2`. This port has been ZIP-checked and statically inspected, but not compiled with ESP-IDF or tested on hardware.

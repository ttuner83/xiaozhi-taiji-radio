# Taiji Pi local generated-scene composer

This version works with the **stock XiaoZhi cloud server**. It does not require a custom server, server-side prompt, new websocket fields, or an image-generation API.

## How it works

1. The standard XiaoZhi server sends its normal `type: "stt"` transcript to the device.
2. Taiji runs a small local Russian phrase detector on the ESP32-S3.
3. If it detects an explicit visual request, a game invitation, a context phrase (for example a jar or shooting), or a strong-emotion phrase, it composes a temporary scene locally.
4. As a second autonomous trigger, Taiji also watches the standard XiaoZhi `emotion` metadata. Strong tags (`angry`, `shocked`, `surprised`, `crying`, `laughing`) can start a scene even when the transcript did not match a local phrase. A scene already started from STT is not restarted by the emotion event.
5. The LVGL renderer draws and animates the scene. Each episode runs for 1–3 seconds regardless of the TTS stop event; the camera returns to the normal Cosmo display after the final queued episode.

Normal conversation does not start a scene. Current local trigger phrases include `давай поиграем`, `нарисуй`, `покажи`, `изобрази`, phrases about putting Cosmo in a jar or shooting at it, and deliberately intense emotional phrases such as `я в ярости`, `я в шоке`, `я в восторге`, `я тебя обожаю`, and `я умираю со смеху`. The detector normalizes Russian uppercase/lowercase text. The standard cloud emotion metadata provides an additional autonomous strong-emotion signal.

## On-device scene composition

The ESP32 creates the scene from LVGL primitives; no finished image is downloaded. The local scene grammar recognizes action requests (shooting, hammering, sawing, grilling shashlik over a campfire, dancing, waving, jumping, hugging/sending a heart, sleeping) and common objects (cat, car, rocket, flower, ball), as well as the jar, game and emotion scenes. When a transcript contains several supported actions, the planner sorts their first mentions by text position and queues a separate short scene for each action. It chooses a matching composition from the recognized object/action combination. The shooting composition includes a pistol assembled from a slide, barrel, grip and trigger, positioned at the robot's hand; the robot, arm and weapon share a recoil cycle, while the muzzle flash and projectile animate separately.

The renderer supports coordinated translation on both axes, pulse scaling/opacity and flashing. Character components that belong together use the same motion cycle, rather than drifting independently. Current objects are stylized vector-like drawings assembled from circles, rounded rectangles and outlines; they are not detailed raster illustrations.

## Important limits

This is local rule-based interpretation, **not an on-device LLM**. It can react autonomously to strong phrases and known semantic cues, but it cannot reliably understand every novel metaphor or invent a semantically accurate scene for arbitrary text. It also does not generate photorealistic artwork. Expanding the local phrase/scene grammar and renderer can add more scene families without changing the cloud server; fully open-ended semantic creativity would require a model or structured scene description that the stock server does not currently provide.

## Trigger contract compatibility

The renderer still accepts an optional server-provided `scene` object for compatibility with custom servers, but local STT-based scenes no longer depend on that field.


## Composite-scene revision

The local scene composer now uses coherent silhouettes instead of independently drifting decorative primitives. The jar scene contains a glass container and a recognizable captive robot with a head, eyes, torso, arms, hands and feet. The shooting scene shows a full robot recoiling from a visible projectile and comic impact marks. The game scene resembles a compact arcade cabinet with a screen, ball and robot player. Emotion reactions use a complete robot figure with restrained animated accents. The renderer accepts up to 40 elements per scene. Most character parts remain fixed relative to one another; only selected accent elements animate.

This is still procedural vector-style artwork, not AI-generated arbitrary pictures. It recognizes only the local vocabulary and scene grammar compiled into the firmware. It can choose among known objects and actions while running, but it cannot reliably infer an unknown object, metaphor, or complex relationship from arbitrary speech. The stock cloud server's ordinary STT and emotion events do not contain a structured drawing plan. Open-ended semantic scene generation would require the cloud model to return a scene description or a local language model; neither is supplied by the unchanged stock-server protocol.

## Expanded local action vocabulary (127-3 experimental package)

The local phrase grammar additionally recognizes running/chasing, thinking/curiosity, sadness/tears, anger/threatening, celebration/victory, and travel/walking prompts. These use a shared Cosmo character composition with action-specific motion timing, facial accents, tears, thought bubbles, celebratory particles, or a travel frame. This keeps the character as the visual focus instead of scattering unrelated moving primitives. Existing jar, shooting, arcade, dance, greeting, affection, sleep, jump, cat, car, rocket, flower, ball, and strong-emotion scenes remain available.

Recognition is intentionally conservative and phrase-based. A word such as "покажи" alone enables the generic show/reaction scene; the engine does not infer arbitrary objects or relations beyond the compiled vocabulary. The stock cloud protocol still supplies only STT text and optional emotion metadata.

## Live-eye camera transition (127-3)

Generated scenes now use a shared LVGL camera stage for the actual `CozmoEyes`
framebuffer and the scene composition. On scene start, the stage eases from
100% to 50% over 850 ms, revealing a robot head/body silhouette
and the generated scene around the same live eyes. The eyes widget is reparented
into this stage (not copied to a still image), so its normal 30 ms renderer keeps
updating during the pull-back and scene. After the final episode has reached its 1–3 second duration, the stage eases
back to 100% over 900 ms, regardless of whether TTS has finished. The same eyes
widget is then returned to its normal UI parent and its prior hidden/visible
state is restored.

The camera transition uses LVGL 9 transform scale and smoothstep easing. This
source change has been structurally checked; a full ESP-IDF compile and physical
display test are still required to validate runtime rendering and timing.


## Ordered multi-scene sequences and timing

The local planner can recognize several supported action families in one STT transcript and play them in spoken order (for example: shooting → hammering → grilling shashlik, or shooting → being put in a jar). It supports up to five distinct scene episodes per utterance. The current phrase grammar includes shooting, jar/capture, hammering, sawing, campfire grilling, dancing, waving, jumping and running. Repeated synonyms for the same action are collapsed into one episode. A directly negated cue such as “не буду стрелять” is ignored by the sequence planner.

Each episode defaults to 1800 ms. The display renderer clamps per-scene durations to 1000–3000 ms. Playback is independent of TTS stop: a long spoken sentence does not hold a scene on screen, and a short sentence does not truncate the queue. The camera pulls back only once at the beginning, stays at the wide framing between episodes, and returns to the same live Cosmo eyes after the final episode.

New visual compositions include a robot hammering an anvil, sawing a log, and grilling skewered meat above a campfire with animated flames. These remain stylized LVGL vector-like scenes built from primitives, not photorealistic drawings.

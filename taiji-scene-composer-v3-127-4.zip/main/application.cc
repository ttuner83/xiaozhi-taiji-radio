#include "application.h"

#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
#include "boards/taiji-pi-s3/taiji_web_radio.h"
#endif
#include "assets.h"
#include "assets/lang_config.h"
#include "audio_codec.h"
#include "board.h"
#include "display.h"
#include "mcp_server.h"
#include "mqtt_protocol.h"
#include "settings.h"
#include "system_info.h"
#include "text_glyph_payload.h"
#include "websocket_protocol.h"

#include <driver/gpio.h>
#include <esp_log.h>
#include <esp_timer.h>
#include <esp_wifi.h>
#include <arpa/inet.h>
#include <cJSON.h>
#include <cstring>
#include <cctype>
#include <limits>
#include <string>
#include <vector>
#include <algorithm>

#define TAG "Application"

#include "assets/common/reminder_ogg.h"

#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
static bool IsRadioStopVoiceCommand(const std::string& text) {
    // STT normally emits lowercase text; include common capitalization variants too.
    // STT sends a transcript, not a command intent. Match explicit stop phrases
    // locally so stopping playback never depends on the cloud LLM calling MCP.
    static const char* phrases[] = {
        "выключи радио", "Выключи радио", "ВЫКЛЮЧИ РАДИО", "Выключи Радио",
        "выключи, пожалуйста, радио", "выключи радио пожалуйста", "радио выключи",
        "выруби радио", "Выруби радио", "ВЫРУБИ РАДИО",
        "отключи радио", "Отключи радио", "ОТКЛЮЧИ РАДИО",
        "останови радио", "Останови радио", "ОСТАНОВИ РАДИО",
        "останови радиостанцию", "останови музыку", "прекрати радио",
        "хватит радио", "Хватит радио", "ХВАТИТ РАДИО",
        "радио, выключи", "Радио выключи", "Радио, выключи",
        "стоп радио", "Стоп радио", "СТОП РАДИО", "радио стоп",
        "выключи музыку", "Выключи музыку", "отключи музыку", "Отключи музыку"
    };
    for (const char* phrase : phrases) {
        if (text.find(phrase) != std::string::npos) return true;
    }
    return false;
}
#endif

#if CONFIG_BOARD_TYPE_TAIJI_PI_S3
static bool g_local_scene_triggered_for_turn = false;

// Local scene composer: it consumes the ordinary STT transcript received from
// the stock XiaoZhi cloud. No server-side scene field or custom cloud prompt is
// required. It is intentionally conservative: normal conversation stays Cosmo-only.
static std::string LowerRussianUtf8(const std::string& input) {
    std::string out;
    out.reserve(input.size());
    for (size_t i = 0; i < input.size();) {
        const unsigned char c = static_cast<unsigned char>(input[i]);
        if (c < 0x80) {
            out.push_back(static_cast<char>(std::tolower(c)));
            ++i;
        } else if (i + 1 < input.size() && c == 0xD0) {
            const unsigned char d = static_cast<unsigned char>(input[i + 1]);
            if (d == 0x81) { out += "ё"; i += 2; }
            else if (d >= 0x90 && d <= 0x9F) {
                out.push_back(static_cast<char>(0xD0)); out.push_back(static_cast<char>(d + 0x20)); i += 2;
            } else if (d >= 0xA0 && d <= 0xAF) {
                out.push_back(static_cast<char>(0xD1)); out.push_back(static_cast<char>(d - 0x20)); i += 2;
            } else { out.push_back(input[i++]); out.push_back(input[i++]); }
        } else {
            out.push_back(input[i++]);
        }
    }
    return out;
}

static bool HasAnyPhrase(const std::string& text, const char* const* phrases, size_t count) {
    for (size_t i = 0; i < count; ++i) {
        if (text.find(phrases[i]) != std::string::npos) return true;
    }
    return false;
}

static void AddLocalSceneItem(cJSON* items, const char* type, int x, int y, int w, int h,
                              const char* color, int motion = 0, const char* axis = "y",
                              int period = 1200, const char* label = nullptr,
                              const char* effect = nullptr) {
    cJSON* item = cJSON_CreateObject();
    if (!item) return;
    cJSON_AddStringToObject(item, "type", type);
    cJSON_AddNumberToObject(item, "x", x);
    cJSON_AddNumberToObject(item, "y", y);
    cJSON_AddNumberToObject(item, "w", w);
    cJSON_AddNumberToObject(item, "h", h);
    cJSON_AddStringToObject(item, "color", color);
    cJSON_AddNumberToObject(item, "motion", motion);
    cJSON_AddStringToObject(item, "axis", axis);
    cJSON_AddNumberToObject(item, "period", period);
    if (label) cJSON_AddStringToObject(item, "text", label);
    if (effect) cJSON_AddStringToObject(item, "effect", effect);
    cJSON_AddItemToArray(items, item);
}

// Returns empty when the utterance is ordinary. The scene is composed from
// LVGL primitives on-device; variation is procedural, not a cloud image request.
static std::string BuildLocalSingleScene(const std::string& original_text) {
    const std::string text = LowerRussianUtf8(original_text);
    static const char* const game_phrases[] = {
        "давай поиграем", "давай играть", "поиграем", "сыграем", "начнем игру", "начнём игру", "поиграй со мной"
    };
    static const char* const draw_phrases[] = {
        "нарисуй", "покажи", "изобрази", "сделай сценку", "представь на экране"
    };
    static const char* const jar_phrases[] = {
        "в банку", "посажу тебя в банку", "закрою в банке", "запру в банке", "банку"
    };
    static const char* const shot_phrases[] = {
        "стреляю", "стрелять", "выстрелю", "стрельну", "в тебя стреля", "пулей", "пулями", "пистолет", "выстрел", "прицелился"
    };
    static const char* const hammer_phrases[] = {"молотком", "молоток", "бить молотком", "ударить молотком", "ударю молотком", "колотить", "колочу", "стучу молотком", "забивать гвозд"};
    static const char* const saw_phrases[] = {"пилой", "пила", "пилить", "пилю", "распилю", "распилить", "пилит", "пилить доску"};
    static const char* const grill_phrases[] = {"зажарю", "жарить шашлык", "жарю шашлык", "шашлык", "шашлыч", "на костре", "костер", "костёр", "жарить мясо", "мясо на огне", "мангал", "шампур"};
    static const char* const dance_phrases[] = {"танцуй", "потанцуй", "давай танцевать", "робот танцует", "танцуй для меня"};
    static const char* const wave_phrases[] = {"помаши", "помахай", "маши рукой", "поздоровайся", "поприветствуй"};
    static const char* const love_phrases[] = {"обними", "поцелуй", "обнимаю", "поцеловать", "сердечко"};
    static const char* const sleep_phrases[] = {"спи", "засыпай", "иди спать", "спокойной ночи", "пора спать"};
    static const char* const jump_phrases[] = {"прыгай", "прыгни", "подпрыгни", "скачи"};
    static const char* const run_phrases[] = {"беги", "побежали", "бегай", "убегай", "догоняй", "погони"};
    static const char* const think_phrases[] = {"подумай", "задумайся", "размышляй", "что ты думаешь", "интересно", "любопытно"};
    static const char* const cry_phrases[] = {"поплачь", "грусти", "мне грустно", "я грущу", "плачу", "слезы", "слёзы"};
    static const char* const angry_phrases[] = {"разозлись", "злись", "сердись", "я злюсь", "я зол", "я зла", "угрожай"};
    static const char* const celebrate_phrases[] = {"празднуй", "победа", "мы победили", "ура", "поздравляю", "отпразднуй"};
    static const char* const travel_phrases[] = {"путешествуй", "поехали в путешествие", "гуляем", "прогулка", "идем гулять", "идём гулять", "отправляемся"};
    static const char* const cat_phrases[] = {"кот", "кошк", "котенок", "котёнок"};
    static const char* const car_phrases[] = {"машин", "автомобил", "авто", "тачк"};
    static const char* const rocket_phrases[] = {"ракет", "космический корабль", "космолет", "космолёт"};
    static const char* const flower_phrases[] = {"цветок", "цветочек", "розу", "ромашк"};
    static const char* const ball_phrases[] = {"мяч", "шарик", "футбольный мяч"};
    // Strong-emotion detection is phrase based to avoid scenes on routine "хорошо"/"спасибо".
    static const char* const strong_phrases[] = {
        "я в ярости", "я вне себя", "меня трясет", "меня трясёт", "я в шоке",
        "это невероятно", "я потрясен", "я потрясён", "я в восторге", "я обожаю тебя",
        "я безумно рад", "я ужасно зол", "я ненавижу", "я тебя обожаю", "я тебя люблю",
        "мне страшно до", "я сейчас расплачусь", "я реву", "я умираю со смеху",
        "это кошмар", "это ужас", "я так счастлив", "я так зол", "я так испугался",
        "я в полном восторге", "я просто в ярости", "я очень испуган", "я очень счастлив"
    };

    const bool game = HasAnyPhrase(text, game_phrases, sizeof(game_phrases)/sizeof(game_phrases[0]));
    const bool explicit_draw = HasAnyPhrase(text, draw_phrases, sizeof(draw_phrases)/sizeof(draw_phrases[0]));
    const bool jar = HasAnyPhrase(text, jar_phrases, sizeof(jar_phrases)/sizeof(jar_phrases[0]));
    const bool shot = HasAnyPhrase(text, shot_phrases, sizeof(shot_phrases)/sizeof(shot_phrases[0]));
    const bool hammer = HasAnyPhrase(text, hammer_phrases, sizeof(hammer_phrases)/sizeof(hammer_phrases[0]));
    const bool saw = HasAnyPhrase(text, saw_phrases, sizeof(saw_phrases)/sizeof(saw_phrases[0]));
    const bool grill = HasAnyPhrase(text, grill_phrases, sizeof(grill_phrases)/sizeof(grill_phrases[0]));
    const bool dance = HasAnyPhrase(text, dance_phrases, sizeof(dance_phrases)/sizeof(dance_phrases[0]));
    const bool wave = HasAnyPhrase(text, wave_phrases, sizeof(wave_phrases)/sizeof(wave_phrases[0]));
    const bool love = HasAnyPhrase(text, love_phrases, sizeof(love_phrases)/sizeof(love_phrases[0]));
    const bool sleep = HasAnyPhrase(text, sleep_phrases, sizeof(sleep_phrases)/sizeof(sleep_phrases[0]));
    const bool jump = HasAnyPhrase(text, jump_phrases, sizeof(jump_phrases)/sizeof(jump_phrases[0]));
    const bool run = HasAnyPhrase(text, run_phrases, sizeof(run_phrases)/sizeof(run_phrases[0]));
    const bool think = HasAnyPhrase(text, think_phrases, sizeof(think_phrases)/sizeof(think_phrases[0]));
    const bool cry = HasAnyPhrase(text, cry_phrases, sizeof(cry_phrases)/sizeof(cry_phrases[0]));
    const bool angry = HasAnyPhrase(text, angry_phrases, sizeof(angry_phrases)/sizeof(angry_phrases[0]));
    const bool celebrate = HasAnyPhrase(text, celebrate_phrases, sizeof(celebrate_phrases)/sizeof(celebrate_phrases[0]));
    const bool travel = HasAnyPhrase(text, travel_phrases, sizeof(travel_phrases)/sizeof(travel_phrases[0]));
    const bool cat = HasAnyPhrase(text, cat_phrases, sizeof(cat_phrases)/sizeof(cat_phrases[0]));
    const bool car = HasAnyPhrase(text, car_phrases, sizeof(car_phrases)/sizeof(car_phrases[0]));
    const bool rocket = HasAnyPhrase(text, rocket_phrases, sizeof(rocket_phrases)/sizeof(rocket_phrases[0]));
    const bool flower = HasAnyPhrase(text, flower_phrases, sizeof(flower_phrases)/sizeof(flower_phrases[0]));
    const bool ball = HasAnyPhrase(text, ball_phrases, sizeof(ball_phrases)/sizeof(ball_phrases[0]));
    const bool has_object = cat || car || rocket || flower || ball;
    const bool strong = HasAnyPhrase(text, strong_phrases, sizeof(strong_phrases)/sizeof(strong_phrases[0]));
    const bool action_scene = dance || wave || love || sleep || jump || run || think || cry || angry || celebrate || travel;
    if (!game && !explicit_draw && !jar && !shot && !hammer && !saw && !grill && !action_scene && !has_object && !strong) return {};

    cJSON* root = cJSON_CreateObject();
    cJSON* items = cJSON_CreateArray();
    if (!root || !items) { cJSON_Delete(root); cJSON_Delete(items); return {}; }
    const bool visual_context = explicit_draw || jar || shot || hammer || saw || grill || action_scene || has_object;
    cJSON_AddStringToObject(root, "trigger", game ? "game" : (visual_context ? "explicit" : "strong_emotion"));
    cJSON_AddItemToObject(root, "items", items);

    // Small deterministic variation keeps repeated scenes from looking frozen.
    unsigned seed = 2166136261u;
    for (unsigned char c : text) seed = (seed ^ c) * 16777619u;
    const int dx = static_cast<int>(seed % 19) - 9;

    // Scenes are built as recognizable silhouettes: every body part is placed
    // relative to the same character anchor. Keep the character mostly still;
    // animate only a few accents so the composition does not dissolve into dots.
    const int cx = 180 + dx / 2;
    if (jar) {
        // Jar: lid, glass walls/base, captive robot (head, face, torso, arms, feet).
        AddLocalSceneItem(items, "outline_rect", 91, 75, 178, 218, "#48C8F5", 0);
        AddLocalSceneItem(items, "rect", 103, 63, 154, 20, "#48C8F5", 0);
        AddLocalSceneItem(items, "rect", 111, 87, 6, 184, "#48C8F5", 0);
        AddLocalSceneItem(items, "rect", 243, 87, 6, 184, "#48C8F5", 0);
        AddLocalSceneItem(items, "outline_rect", 132, 121, 96, 73, "#FFFFFF", 0);
        AddLocalSceneItem(items, "circle", 145, 143, 18, 22, "#FFFFFF", 0);
        AddLocalSceneItem(items, "circle", 196, 143, 18, 22, "#FFFFFF", 0);
        AddLocalSceneItem(items, "circle", 151, 150, 7, 10, "#101820", 0);
        AddLocalSceneItem(items, "circle", 202, 150, 7, 10, "#101820", 0);
        AddLocalSceneItem(items, "rect", 168, 173, 25, 5, "#48C8F5", 0);
        AddLocalSceneItem(items, "rect", 151, 199, 58, 55, "#FFFFFF", 0);
        AddLocalSceneItem(items, "rect", 126, 205, 27, 9, "#FFFFFF", 0);
        AddLocalSceneItem(items, "rect", 207, 205, 27, 9, "#FFFFFF", 0);
        AddLocalSceneItem(items, "circle", 119, 202, 13, 13, "#FFFFFF", 0);
        AddLocalSceneItem(items, "circle", 228, 202, 13, 13, "#FFFFFF", 0);
        AddLocalSceneItem(items, "rect", 157, 250, 15, 20, "#FFFFFF", 0);
        AddLocalSceneItem(items, "rect", 188, 250, 15, 20, "#FFFFFF", 0);
        AddLocalSceneItem(items, "rect", 149, 265, 28, 8, "#48C8F5", 0);
        AddLocalSceneItem(items, "rect", 183, 265, 28, 8, "#48C8F5", 0);
        AddLocalSceneItem(items, "text", 75, 310, 210, 30, "#48C8F5", 0, "y", 1200, "ВЫПУСТИ МЕНЯ!");
        // Knocking marks on the glass.
        AddLocalSceneItem(items, "rect", 116, 119, 4, 23, "#FFCF4A", 4, "y", 500);
        AddLocalSceneItem(items, "rect", 238, 119, 4, 23, "#FFCF4A", 4, "y", 500);
    } else if (shot) {
        // Action scene: the robot body recoils as one character; the extended arm
        // and the clearly recognizable pistol stay visually connected.
        const int rx = 92 + dx / 3;
        // floor and recoil shadow
        AddLocalSceneItem(items, "rect", 48, 292, 205, 4, "#526575", 2, "x", 900);
        // antenna and head: all parts share the same body motion phase
        AddLocalSceneItem(items, "rect", rx+42, 49, 6, 19, "#48C8F5", 8, "x", 620);
        AddLocalSceneItem(items, "circle", rx+35, 35, 20, 20, "#FFCF4A", 5, "xy", 620, nullptr, "pulse");
        AddLocalSceneItem(items, "outline_rect", rx, 69, 104, 78, "#48C8F5", 8, "x", 620);
        AddLocalSceneItem(items, "circle", rx+19, 91, 22, 28, "#FFFFFF", 8, "x", 620);
        AddLocalSceneItem(items, "circle", rx+63, 91, 22, 28, "#FFFFFF", 8, "x", 620);
        AddLocalSceneItem(items, "circle", rx+25, 99, 9, 13, "#101820", 8, "x", 620);
        AddLocalSceneItem(items, "circle", rx+69, 99, 9, 13, "#101820", 8, "x", 620);
        AddLocalSceneItem(items, "outline_circle", rx+43, 124, 17, 17, "#FFCF4A", 8, "x", 620);
        // torso and legs
        AddLocalSceneItem(items, "outline_rect", rx+12, 157, 82, 78, "#FFFFFF", 8, "x", 620);
        AddLocalSceneItem(items, "rect", rx+34, 173, 38, 6, "#48C8F5", 8, "x", 620);
        AddLocalSceneItem(items, "rect", rx+30, 235, 16, 43, "#FFFFFF", 8, "x", 620);
        AddLocalSceneItem(items, "rect", rx+62, 235, 16, 43, "#FFFFFF", 8, "x", 620);
        AddLocalSceneItem(items, "rect", rx+20, 274, 35, 11, "#48C8F5", 8, "x", 620);
        AddLocalSceneItem(items, "rect", rx+56, 274, 35, 11, "#48C8F5", 8, "x", 620);
        // left arm hangs back; right arm is extended toward the target
        AddLocalSceneItem(items, "rect", rx+78, 174, 34, 10, "#FFFFFF", 8, "x", 620);
        AddLocalSceneItem(items, "circle", rx+105, 169, 18, 18, "#FFCF4A", 8, "x", 620);
        AddLocalSceneItem(items, "rect", rx+6, 181, 31, 10, "#FFFFFF", 8, "x", 620);
        AddLocalSceneItem(items, "circle", rx-2, 178, 17, 17, "#FFCF4A", 8, "x", 620);
        // PISTOL in the robot's right hand: barrel, slide, muzzle, grip and trigger.
        // Its parts use the same phase as the hand, so the weapon is not detached.
        AddLocalSceneItem(items, "rect", rx+108, 166, 45, 12, "#D8E6F2", 8, "x", 620);
        AddLocalSceneItem(items, "rect", rx+139, 169, 19, 6, "#FFCF4A", 8, "x", 620);
        AddLocalSceneItem(items, "rect", rx+115, 177, 14, 25, "#48C8F5", 8, "x", 620);
        AddLocalSceneItem(items, "outline_rect", rx+113, 176, 18, 29, "#FFFFFF", 8, "x", 620);
        AddLocalSceneItem(items, "outline_circle", rx+130, 179, 10, 10, "#FFCF4A", 8, "x", 620);
        // Muzzle flash and projectile animate independently from the character.
        AddLocalSceneItem(items, "circle", rx+153, 157, 24, 24, "#FFCF4A", 2, "xy", 260, nullptr, "flash");
        AddLocalSceneItem(items, "circle", 252, 158, 17, 17, "#FF5B65", 82, "x", 520, nullptr, "travel");
        AddLocalSceneItem(items, "rect", 238, 164, 34, 6, "#FFCF4A", 82, "x", 520, nullptr, "travel");
        AddLocalSceneItem(items, "text", 88, 315, 184, 28, "#FFCF4A", 0, "y", 1000, "ПИФ-ПАФ!");
    } else if (hammer) {
        // Angry workshop scene: the hammer stays visually connected to the robot's raised hand.
        const int rx = 106 + dx / 3;
        AddLocalSceneItem(items, "rect", 62, 285, 236, 5, "#526575", 0);
        AddLocalSceneItem(items, "outline_rect", 103, 75, 112, 84, "#48C8F5", 5, "y", 520);
        AddLocalSceneItem(items, "circle", 126, 101, 22, 26, "#FFFFFF", 5, "y", 520);
        AddLocalSceneItem(items, "circle", 171, 101, 22, 26, "#FFFFFF", 5, "y", 520);
        AddLocalSceneItem(items, "circle", 133, 109, 9, 12, "#101820", 5, "y", 520);
        AddLocalSceneItem(items, "circle", 178, 109, 9, 12, "#101820", 5, "y", 520);
        AddLocalSceneItem(items, "outline_rect", 117, 166, 84, 83, "#FFFFFF", 5, "y", 520);
        AddLocalSceneItem(items, "rect", 94, 177, 38, 10, "#FFFFFF", 4, "xy", 420);
        AddLocalSceneItem(items, "rect", 190, 151, 11, 62, "#FFFFFF", 15, "y", 360);
        AddLocalSceneItem(items, "circle", 184, 204, 22, 20, "#FFCF4A", 15, "y", 360);
        AddLocalSceneItem(items, "rect", 178, 119, 57, 18, "#D8E6F2", 15, "y", 360);
        AddLocalSceneItem(items, "rect", 197, 119, 14, 44, "#D8E6F2", 15, "y", 360);
        AddLocalSceneItem(items, "outline_rect", 229, 244, 72, 32, "#A7B5C4", 0);
        AddLocalSceneItem(items, "text", 91, 315, 180, 28, "#FF5B65", 0, "y", 1000, "БА-БАХ!");
    } else if (saw) {
        // Sawing scene: a long saw blade crosses a clearly drawn log; arm moves with it.
        AddLocalSceneItem(items, "rect", 52, 275, 256, 5, "#526575", 0);
        AddLocalSceneItem(items, "outline_rect", 145, 219, 157, 49, "#B77A45", 0);
        AddLocalSceneItem(items, "rect", 158, 229, 130, 5, "#E2B17B", 0);
        AddLocalSceneItem(items, "outline_rect", 80, 76, 106, 82, "#48C8F5", 4, "y", 620);
        AddLocalSceneItem(items, "circle", 101, 103, 22, 27, "#FFFFFF", 4, "y", 620);
        AddLocalSceneItem(items, "circle", 145, 103, 22, 27, "#FFFFFF", 4, "y", 620);
        AddLocalSceneItem(items, "circle", 108, 111, 9, 12, "#101820", 4, "y", 620);
        AddLocalSceneItem(items, "circle", 152, 111, 9, 12, "#101820", 4, "y", 620);
        AddLocalSceneItem(items, "outline_rect", 94, 166, 82, 76, "#FFFFFF", 4, "y", 620);
        AddLocalSceneItem(items, "rect", 151, 174, 35, 10, "#FFFFFF", 12, "x", 360);
        AddLocalSceneItem(items, "rect", 177, 165, 111, 8, "#D8E6F2", 18, "x", 360);
        AddLocalSceneItem(items, "rect", 165, 157, 24, 25, "#FFCF4A", 18, "x", 360);
        AddLocalSceneItem(items, "text", 95, 315, 170, 28, "#FFCF4A", 0, "y", 1000, "ЖЖЖИК!");
    } else if (grill) {
        // Campfire and shashlik scene: skewered pieces sit above animated flames.
        AddLocalSceneItem(items, "rect", 57, 286, 246, 5, "#526575", 0);
        AddLocalSceneItem(items, "outline_rect", 99, 230, 162, 45, "#A7B5C4", 0);
        AddLocalSceneItem(items, "rect", 119, 244, 123, 9, "#8B5A2B", 0);
        AddLocalSceneItem(items, "circle", 130, 222, 29, 34, "#FF5B35", 8, "y", 360, nullptr, "pulse");
        AddLocalSceneItem(items, "circle", 165, 208, 33, 48, "#FFCF4A", 10, "y", 420, nullptr, "pulse");
        AddLocalSceneItem(items, "circle", 205, 222, 29, 34, "#FF5B35", 8, "y", 390, nullptr, "pulse");
        AddLocalSceneItem(items, "rect", 92, 130, 174, 5, "#D8E6F2", 0);
        AddLocalSceneItem(items, "rect", 118, 113, 34, 31, "#A85B35", 4, "y", 650);
        AddLocalSceneItem(items, "rect", 157, 113, 34, 31, "#C77A42", 4, "y", 650);
        AddLocalSceneItem(items, "rect", 196, 113, 34, 31, "#A85B35", 4, "y", 650);
        AddLocalSceneItem(items, "circle", 122, 117, 8, 8, "#FFCF4A", 2, "y", 500);
        AddLocalSceneItem(items, "circle", 169, 120, 8, 8, "#FFCF4A", 2, "y", 500);
        AddLocalSceneItem(items, "circle", 207, 117, 8, 8, "#FFCF4A", 2, "y", 500);
        AddLocalSceneItem(items, "text", 83, 315, 194, 28, "#FFCF4A", 0, "y", 1000, "ШАШЛЫЧОК ГОТОВ!");
    } else if (cat || car || rocket || flower || ball) {
        // Object-first scene selection: recognizable silhouettes with moving parts.
        if (cat) {
            // Cat: head, ears, eyes, muzzle, whiskers, body, tail and paws.
            AddLocalSceneItem(items, "outline_circle", 115, 74, 130, 118, "#F5B85A", 3, "y", 900);
            AddLocalSceneItem(items, "rect", 126, 67, 30, 40, "#F5B85A", 2, "y", 900);
            AddLocalSceneItem(items, "rect", 204, 67, 30, 40, "#F5B85A", 2, "y", 900);
            AddLocalSceneItem(items, "circle", 145, 111, 19, 22, "#FFFFFF", 2, "y", 900);
            AddLocalSceneItem(items, "circle", 196, 111, 19, 22, "#FFFFFF", 2, "y", 900);
            AddLocalSceneItem(items, "circle", 151, 118, 8, 10, "#101820", 2, "y", 900);
            AddLocalSceneItem(items, "circle", 202, 118, 8, 10, "#101820", 2, "y", 900);
            AddLocalSceneItem(items, "circle", 172, 145, 16, 12, "#FF76B7", 2, "y", 900);
            AddLocalSceneItem(items, "rect", 129, 150, 38, 3, "#F5B85A", 3, "x", 700);
            AddLocalSceneItem(items, "rect", 192, 150, 38, 3, "#F5B85A", 3, "x", 700);
            AddLocalSceneItem(items, "outline_rect", 139, 194, 82, 77, "#F5B85A", 4, "xy", 1100);
            AddLocalSceneItem(items, "circle", 122, 215, 25, 25, "#F5B85A", 6, "xy", 850);
            AddLocalSceneItem(items, "circle", 213, 215, 25, 25, "#F5B85A", 6, "xy", 850);
            AddLocalSceneItem(items, "text", 125, 310, 110, 28, "#F5B85A", 0, "y", 1000, "МЯУ!");
        } else if (car) {
            // Car body, cabin, windows, wheels and moving road.
            AddLocalSceneItem(items, "rect", 51, 209, 258, 8, "#526575", 9, "x", 650);
            AddLocalSceneItem(items, "outline_rect", 65, 164, 230, 76, "#48C8F5", 5, "x", 900);
            AddLocalSceneItem(items, "rect", 111, 120, 135, 52, "#48C8F5", 5, "x", 900);
            AddLocalSceneItem(items, "rect", 123, 130, 48, 32, "#102331", 5, "x", 900);
            AddLocalSceneItem(items, "rect", 180, 130, 54, 32, "#102331", 5, "x", 900);
            AddLocalSceneItem(items, "circle", 91, 213, 53, 53, "#D8E6F2", 8, "x", 520);
            AddLocalSceneItem(items, "circle", 221, 213, 53, 53, "#D8E6F2", 8, "x", 520);
            AddLocalSceneItem(items, "circle", 106, 228, 23, 23, "#102331", 8, "x", 520);
            AddLocalSceneItem(items, "circle", 236, 228, 23, 23, "#102331", 8, "x", 520);
            AddLocalSceneItem(items, "rect", 264, 184, 24, 12, "#FFCF4A", 4, "x", 900);
            AddLocalSceneItem(items, "text", 120, 310, 120, 28, "#48C8F5", 0, "y", 1000, "ВЖЖЖ!");
        } else if (rocket) {
            // Rocket body with fins, porthole and animated exhaust plume.
            AddLocalSceneItem(items, "outline_rect", 139, 84, 82, 173, "#D8E6F2", 7, "y", 900);
            AddLocalSceneItem(items, "circle", 157, 104, 46, 46, "#48C8F5", 7, "y", 900);
            AddLocalSceneItem(items, "circle", 170, 117, 20, 20, "#102331", 7, "y", 900);
            AddLocalSceneItem(items, "rect", 108, 207, 33, 43, "#FF5B65", 7, "y", 900);
            AddLocalSceneItem(items, "rect", 219, 207, 33, 43, "#FF5B65", 7, "y", 900);
            AddLocalSceneItem(items, "rect", 164, 254, 32, 48, "#FFCF4A", 15, "y", 320, nullptr, "pulse");
            AddLocalSceneItem(items, "circle", 165, 282, 30, 30, "#FF5B65", 13, "y", 360, nullptr, "pulse");
            AddLocalSceneItem(items, "text", 117, 315, 126, 28, "#FFCF4A", 0, "y", 1000, "ПОЕХАЛИ!");
        } else if (flower) {
            // Flower with stem, leaves and petals; petals pulse together.
            AddLocalSceneItem(items, "rect", 177, 174, 7, 122, "#6CE39A", 3, "x", 1400);
            AddLocalSceneItem(items, "outline_rect", 125, 221, 56, 20, "#6CE39A", 5, "xy", 1100);
            AddLocalSceneItem(items, "outline_rect", 181, 247, 56, 20, "#6CE39A", 5, "xy", 1100);
            AddLocalSceneItem(items, "circle", 159, 75, 42, 42, "#FF76B7", 3, "y", 700, nullptr, "pulse");
            AddLocalSceneItem(items, "circle", 197, 112, 42, 42, "#FF76B7", 3, "y", 700, nullptr, "pulse");
            AddLocalSceneItem(items, "circle", 159, 149, 42, 42, "#FF76B7", 3, "y", 700, nullptr, "pulse");
            AddLocalSceneItem(items, "circle", 121, 112, 42, 42, "#FF76B7", 3, "y", 700, nullptr, "pulse");
            AddLocalSceneItem(items, "circle", 164, 117, 34, 34, "#FFCF4A", 2, "y", 700, nullptr, "pulse");
            AddLocalSceneItem(items, "text", 122, 315, 116, 28, "#FF76B7", 0, "y", 1000, "ЦВЕТОЧЕК");
        } else {
            // Ball: rolling/spinning impression from a moving seam and bouncing.
            AddLocalSceneItem(items, "circle", 104, 95, 152, 152, "#FFCF4A", 11, "xy", 620, nullptr, "pulse");
            AddLocalSceneItem(items, "outline_circle", 119, 110, 122, 122, "#FFFFFF", 9, "xy", 620);
            AddLocalSceneItem(items, "rect", 176, 105, 8, 132, "#FFFFFF", 15, "x", 520);
            AddLocalSceneItem(items, "rect", 115, 168, 132, 8, "#FFFFFF", 15, "y", 520);
            AddLocalSceneItem(items, "text", 130, 310, 100, 28, "#FFCF4A", 0, "y", 1000, "ЛОВИ!");
        }
    } else if (action_scene) {
        // A single articulated-looking character. The limbs are given different
        // oscillation phases/rates to create an actual action rather than drifting debris.
        const char* accent = (love ? "#FF76B7" : (sleep || think ? "#8DBBFF" :
                              (angry ? "#FF5B65" : (cry ? "#48C8F5" : "#6CE39A"))));
        const int bob = (jump || run) ? 12 : (dance || celebrate ? 6 : 2);
        const int body_motion = (jump || run || dance || celebrate) ? 13 : bob;
        const int body_period = run ? 360 : (jump ? 430 : (dance ? 470 : (celebrate ? 520 : 850)));
        AddLocalSceneItem(items, "rect", 88, 291, 184, 4, "#526575", 0);
        AddLocalSceneItem(items, "rect", cx-3, 49, 6, 18, accent, body_motion, "y", body_period);
        AddLocalSceneItem(items, "circle", cx-12, 36, 24, 24, accent, bob+2, "y", jump ? 430 : 850, nullptr, "pulse");
        AddLocalSceneItem(items, "outline_rect", cx-58, 68, 116, 83, "#48C8F5", body_motion, "y", body_period);
        AddLocalSceneItem(items, "circle", cx-35, 94, 23, 28, "#FFFFFF", body_motion, "y", body_period);
        AddLocalSceneItem(items, "circle", cx+12, 94, 23, 28, "#FFFFFF", body_motion, "y", body_period);
        AddLocalSceneItem(items, "circle", cx-28, 102, 9, 12, "#101820", body_motion, "y", body_period);
        AddLocalSceneItem(items, "circle", cx+19, 102, 9, 12, "#101820", body_motion, "y", body_period);
        AddLocalSceneItem(items, "rect", cx-13, 134, 26, 5, accent, body_motion, "y", body_period);
        AddLocalSceneItem(items, "outline_rect", cx-40, 160, 80, 73, "#FFFFFF", body_motion, "y", body_period);
        // Arms: waving/dancing arms move on different cycles.
        AddLocalSceneItem(items, "rect", cx-77, wave ? 93 : 174, 39, 10, "#FFFFFF", 15, "xy", wave ? 520 : 680);
        AddLocalSceneItem(items, "circle", cx-87, wave ? 87 : 169, 19, 19, accent, 15, "xy", wave ? 520 : 680);
        AddLocalSceneItem(items, "rect", cx+38, dance ? 128 : (wave ? 91 : 174), 39, 10, "#FFFFFF", 15, "xy", dance ? 470 : 520);
        AddLocalSceneItem(items, "circle", cx+69, dance ? 119 : (wave ? 85 : 169), 19, 19, accent, 15, "xy", dance ? 470 : 520);
        // Legs kick alternately while dancing/jumping.
        AddLocalSceneItem(items, "rect", cx-27, 231, 15, 42, "#FFFFFF", dance || jump || run || celebrate ? 16 : bob, "y", run ? 300 : 520);
        AddLocalSceneItem(items, "rect", cx+12, 231, 15, 42, "#FFFFFF", dance || jump || run || celebrate ? 16 : bob, "y", run ? 380 : 690);
        AddLocalSceneItem(items, "rect", cx-39, 267, 34, 10, accent, dance || jump || run || celebrate ? 16 : bob, "y", run ? 300 : 520);
        AddLocalSceneItem(items, "rect", cx+6, 267, 34, 10, accent, dance || jump || run || celebrate ? 16 : bob, "y", run ? 380 : 690);
        if (cry) {
            AddLocalSceneItem(items, "circle", cx-31, 128, 8, 19, "#48C8F5", 18, "y", 620, nullptr, "travel");
            AddLocalSceneItem(items, "circle", cx+19, 128, 8, 19, "#48C8F5", 18, "y", 740, nullptr, "travel");
            AddLocalSceneItem(items, "text", 105, 315, 150, 28, accent, 0, "y", 1000, "БУ-У...");
        } else if (angry) {
            AddLocalSceneItem(items, "rect", cx-39, 85, 31, 6, accent, 4, "x", 420);
            AddLocalSceneItem(items, "rect", cx+8, 85, 31, 6, accent, 4, "x", 420);
            AddLocalSceneItem(items, "text", 105, 315, 150, 28, accent, 0, "y", 1000, "ГР-Р-Р!");
        } else if (think) {
            AddLocalSceneItem(items, "circle", cx+69, 49, 13, 13, "#FFFFFF", 5, "y", 700, nullptr, "pulse");
            AddLocalSceneItem(items, "circle", cx+88, 28, 21, 21, "#FFFFFF", 5, "y", 900, nullptr, "pulse");
            AddLocalSceneItem(items, "text", 105, 315, 150, 28, accent, 0, "y", 1000, "ХМ-М...");
        } else if (celebrate) {
            AddLocalSceneItem(items, "circle", 78, 70, 14, 14, "#FFCF4A", 12, "xy", 420, nullptr, "travel");
            AddLocalSceneItem(items, "circle", 270, 78, 12, 12, "#FF76B7", 12, "xy", 510, nullptr, "travel");
            AddLocalSceneItem(items, "circle", 95, 180, 10, 10, "#48C8F5", 12, "xy", 460, nullptr, "travel");
            AddLocalSceneItem(items, "text", 105, 315, 150, 28, accent, 0, "y", 1000, "УРА-А-А!");
        } else if (run) {
            AddLocalSceneItem(items, "rect", 45, 286, 270, 3, "#526575", 24, "x", 420, nullptr, "travel");
            AddLocalSceneItem(items, "text", 105, 315, 150, 28, accent, 0, "y", 1000, "БЕГУ!");
        } else if (travel) {
            AddLocalSceneItem(items, "outline_rect", 58, 74, 244, 185, "#48C8F5", 0);
            AddLocalSceneItem(items, "circle", 85, 99, 17, 17, "#FFCF4A", 5, "xy", 800, nullptr, "pulse");
            AddLocalSceneItem(items, "circle", 250, 120, 12, 12, "#FFFFFF", 5, "xy", 900, nullptr, "pulse");
            AddLocalSceneItem(items, "text", 105, 315, 150, 28, accent, 0, "y", 1000, "В ПУТЬ!");
        } else if (love) {
            AddLocalSceneItem(items, "circle", 72, 106, 28, 28, accent, 5, "y", 700, nullptr, "pulse");
            AddLocalSceneItem(items, "circle", 260, 106, 28, 28, accent, 5, "y", 700, nullptr, "pulse");
            AddLocalSceneItem(items, "text", 90, 315, 180, 28, accent, 0, "y", 1000, "ОБНИМАЮ!");
        } else if (sleep) {
            AddLocalSceneItem(items, "text", 135, 315, 90, 28, accent, 3, "y", 1400, "Z Z Z");
        } else if (wave) {
            AddLocalSceneItem(items, "text", 105, 315, 150, 28, accent, 0, "y", 1000, "ПРИВЕТ!");
        } else if (dance) {
            AddLocalSceneItem(items, "text", 105, 315, 150, 28, accent, 0, "y", 1000, "ТАНЦУЕМ!");
        } else {
            AddLocalSceneItem(items, "text", 105, 315, 150, 28, accent, 0, "y", 1000, "ПРЫГ-СKОК!");
        }
    } else if (game) {
        // A small arcade cabinet with a robot player and a bouncing ball.
        AddLocalSceneItem(items, "outline_rect", 57, 72, 246, 220, "#48C8F5", 0);
        AddLocalSceneItem(items, "rect", 77, 92, 206, 137, "#102331", 0);
        AddLocalSceneItem(items, "outline_rect", 127, 109, 106, 105, "#6CE39A", 0);
        AddLocalSceneItem(items, "circle", 151, 133, 24, 24, "#FFCF4A", 4, "y", 650);
        AddLocalSceneItem(items, "circle", 188, 166, 18, 18, "#FFFFFF", 5, "x", 720);
        // robot on the lower edge of the game screen
        AddLocalSceneItem(items, "outline_rect", 157, 174, 44, 33, "#48C8F5", 0);
        AddLocalSceneItem(items, "circle", 166, 184, 7, 8, "#FFFFFF", 0);
        AddLocalSceneItem(items, "circle", 185, 184, 7, 8, "#FFFFFF", 0);
        AddLocalSceneItem(items, "rect", 147, 206, 14, 5, "#FFFFFF", 0);
        AddLocalSceneItem(items, "rect", 197, 206, 14, 5, "#FFFFFF", 0);
        AddLocalSceneItem(items, "rect", 110, 243, 140, 10, "#48C8F5", 0);
        AddLocalSceneItem(items, "circle", 91, 252, 24, 24, "#FFCF4A", 0);
        AddLocalSceneItem(items, "circle", 245, 252, 24, 24, "#FFCF4A", 0);
        AddLocalSceneItem(items, "text", 91, 310, 178, 30, "#48C8F5", 0, "y", 1000, "ПОЕХАЛИ!");
    } else {
        // Emotion scene: recognizable robot character, not floating ornaments.
        const char* accent = "#FFCF4A";
        const char* reaction = explicit_draw ? "СМОТРИ!" : "ВОТ ЭТО ДА!";
        if (text.find("ярости") != std::string::npos || text.find("зол") != std::string::npos) {
            accent = "#FF5B65"; reaction = "ГРРР!";
        } else if (text.find("шоке") != std::string::npos || text.find("потряс") != std::string::npos) {
            accent = "#FFCF4A"; reaction = "ЧТО?!";
        } else if (text.find("расплачусь") != std::string::npos || text.find("реву") != std::string::npos) {
            accent = "#48C8F5"; reaction = "ОЙ...";
        } else if (text.find("смеху") != std::string::npos) {
            accent = "#6CE39A"; reaction = "ХА-ХА!";
        } else if (text.find("восторге") != std::string::npos || text.find("счастлив") != std::string::npos) {
            accent = "#6CE39A"; reaction = "УРААА!";
        } else if (text.find("люб") != std::string::npos || text.find("обож") != std::string::npos) {
            accent = "#FF76B7"; reaction = "ОБНИМАЮ!";
        }
        AddLocalSceneItem(items, "rect", 107, 270, 146, 5, "#526575", 0);
        AddLocalSceneItem(items, "rect", cx-3, 62, 6, 18, accent, 0);
        AddLocalSceneItem(items, "circle", cx-11, 50, 22, 22, accent, 3, "y", 700);
        AddLocalSceneItem(items, "outline_rect", cx-61, 82, 122, 91, accent, 0);
        AddLocalSceneItem(items, "circle", cx-37, 111, 24, 29, "#FFFFFF", 0);
        AddLocalSceneItem(items, "circle", cx+13, 111, 24, 29, "#FFFFFF", 0);
        AddLocalSceneItem(items, "circle", cx-29, 119, 10, 14, "#101820", 0);
        AddLocalSceneItem(items, "circle", cx+21, 119, 10, 14, "#101820", 0);
        AddLocalSceneItem(items, "rect", cx-12, 151, 24, 5, accent, 0);
        AddLocalSceneItem(items, "outline_rect", cx-42, 183, 84, 72, "#FFFFFF", 0);
        AddLocalSceneItem(items, "rect", cx-69, 190, 27, 10, "#FFFFFF", 0);
        AddLocalSceneItem(items, "rect", cx+42, 190, 27, 10, "#FFFFFF", 0);
        AddLocalSceneItem(items, "circle", cx-75, 187, 15, 15, accent, 0);
        AddLocalSceneItem(items, "circle", cx+60, 187, 15, 15, accent, 0);
        AddLocalSceneItem(items, "rect", cx-28, 254, 16, 20, "#FFFFFF", 0);
        AddLocalSceneItem(items, "rect", cx+12, 254, 16, 20, "#FFFFFF", 0);
        AddLocalSceneItem(items, "rect", cx-38, 270, 35, 9, accent, 0);
        AddLocalSceneItem(items, "rect", cx+4, 270, 35, 9, accent, 0);
        // A few expressive marks frame the character without obscuring it.
        AddLocalSceneItem(items, "rect", 66, 103, 28, 5, accent, 5, "x", 600);
        AddLocalSceneItem(items, "rect", 266, 103, 28, 5, accent, 5, "x", 600);
        AddLocalSceneItem(items, "text", 87, 310, 186, 30, accent, 0, "y", 1000, reaction);
    }

    char* raw = cJSON_PrintUnformatted(root);
    std::string result = raw ? raw : "";
    if (raw) cJSON_free(raw);
    cJSON_Delete(root);
    return result;
}

// Ordered multi-action scene planner. It finds all supported action mentions in
// the transcript, sorts them by their position and emits up to five short scenes.
static std::string BuildLocalScene(const std::string& original_text) {
    const std::string text = LowerRussianUtf8(original_text);
    struct EventPhrase { const char* phrase; const char* scene_text; };
    struct Event { size_t position; std::string scene_text; };
    static const EventPhrase shot[] = {
        {"стреляю", "я стреляю"}, {"стрелять", "я стреляю"}, {"выстрелю", "я стреляю"},
        {"стрельну", "я стреляю"}, {"пистолет", "я стреляю"}, {"выстрел", "я стреляю"}
    };
    static const EventPhrase jar[] = {
        {"посажу тебя в банку", "посажу тебя в банку"}, {"закрою в банке", "посажу тебя в банку"},
        {"запру в банке", "посажу тебя в банку"}, {"в банку", "посажу тебя в банку"}
    };
    static const EventPhrase hammer[] = {
        {"молотком", "робот бьет молотком"}, {"молоток", "робот бьет молотком"},
        {"колотить", "робот бьет молотком"}, {"колочу", "робот бьет молотком"},
        {"забивать гвозд", "робот бьет молотком"}
    };
    static const EventPhrase saw[] = {
        {"пилой", "робот пилит пилой"}, {"пила", "робот пилит пилой"},
        {"пилить", "робот пилит пилой"}, {"пилю", "робот пилит пилой"},
        {"распилю", "робот пилит пилой"}, {"распилить", "робот пилит пилой"}
    };
    static const EventPhrase grill[] = {
        {"зажарю", "робот жарит шашлык на костре"}, {"жарить шашлык", "робот жарит шашлык на костре"},
        {"жарю шашлык", "робот жарит шашлык на костре"}, {"шашлык", "робот жарит шашлык на костре"},
        {"на костре", "робот жарит шашлык на костре"}, {"костер", "робот жарит шашлык на костре"},
        {"костёр", "робот жарит шашлык на костре"}, {"жарить мясо", "робот жарит шашлык на костре"},
        {"мясо на огне", "робот жарит шашлык на костре"}, {"мангал", "робот жарит шашлык на костре"},
        {"шампур", "робот жарит шашлык на костре"}
    };
    static const EventPhrase dance[] = {{"танцевать", "робот танцует"}, {"танцуй", "робот танцует"}, {"танцует", "робот танцует"}};
    static const EventPhrase wave[] = {{"помаши", "робот приветствует"}, {"помахай", "робот приветствует"}, {"поздоровайся", "робот приветствует"}};
    static const EventPhrase jump[] = {{"прыгни", "робот прыгает"}, {"прыгай", "робот прыгает"}};
    static const EventPhrase run[] = {{"беги", "робот бежит"}, {"убегай", "робот бежит"}, {"догоняй", "робот бежит"}};
    std::vector<Event> events;
    auto add_event = [&](const EventPhrase* phrases, size_t count) {
        size_t best = std::string::npos;
        const char* scene_text = nullptr;
        for (size_t i = 0; i < count; ++i) {
            size_t pos = text.find(phrases[i].phrase);
            if (pos == std::string::npos) continue;
            // Ignore a directly negated action ("не буду стрелять").
            const size_t begin = pos > 9 ? pos - 9 : 0;
            const std::string prefix = text.substr(begin, pos - begin);
            if (prefix.find("не ") != std::string::npos || prefix.find("нельзя ") != std::string::npos) continue;
            if (pos < best) { best = pos; scene_text = phrases[i].scene_text; }
        }
        if (scene_text != nullptr) events.push_back({best, scene_text});
    };
    add_event(shot, sizeof(shot)/sizeof(shot[0]));
    add_event(jar, sizeof(jar)/sizeof(jar[0]));
    add_event(hammer, sizeof(hammer)/sizeof(hammer[0]));
    add_event(saw, sizeof(saw)/sizeof(saw[0]));
    add_event(grill, sizeof(grill)/sizeof(grill[0]));
    add_event(dance, sizeof(dance)/sizeof(dance[0]));
    add_event(wave, sizeof(wave)/sizeof(wave[0]));
    add_event(jump, sizeof(jump)/sizeof(jump[0]));
    add_event(run, sizeof(run)/sizeof(run[0]));
    std::sort(events.begin(), events.end(), [](const Event& a, const Event& b) { return a.position < b.position; });
    // Remove repeated category hits that collapse to the same generated action.
    std::vector<Event> unique_events;
    for (const auto& event : events) {
        if (unique_events.empty() || unique_events.back().scene_text != event.scene_text)
            unique_events.push_back(event);
    }
    if (unique_events.size() > 5) unique_events.resize(5);
    if (unique_events.size() >= 2) {
        cJSON* root = cJSON_CreateObject();
        cJSON* scenes = cJSON_CreateArray();
        if (!root || !scenes) { cJSON_Delete(root); cJSON_Delete(scenes); return {}; }
        cJSON_AddStringToObject(root, "trigger", "sequence");
        cJSON_AddItemToObject(root, "scenes", scenes);
        for (const auto& event : unique_events) {
            std::string payload = BuildLocalSingleScene(event.scene_text);
            cJSON* scene_root = cJSON_Parse(payload.c_str());
            if (!scene_root) continue;
            cJSON* items = cJSON_DetachItemFromObjectCaseSensitive(scene_root, "items");
            cJSON* scene = cJSON_CreateObject();
            if (scene && cJSON_IsArray(items)) {
                cJSON_AddItemToObject(scene, "items", items);
                cJSON_AddNumberToObject(scene, "duration_ms", 1800); // 1-3 seconds per scene.
                cJSON_AddItemToArray(scenes, scene);
            } else {
                cJSON_Delete(items);
                cJSON_Delete(scene);
            }
            cJSON_Delete(scene_root);
        }
        char* raw = cJSON_PrintUnformatted(root);
        std::string result = raw ? raw : "";
        if (raw) cJSON_free(raw);
        cJSON_Delete(root);
        return result;
    }
    return BuildLocalSingleScene(original_text);
}

static std::string BuildLocalEmotionScene(const char* emotion) {
    if (emotion == nullptr) return {};
    if (strcmp(emotion, "angry") == 0) return BuildLocalScene("я в ярости");
    if (strcmp(emotion, "shocked") == 0 || strcmp(emotion, "surprised") == 0)
        return BuildLocalScene("я в шоке");
    if (strcmp(emotion, "crying") == 0) return BuildLocalScene("я сейчас расплачусь");
    if (strcmp(emotion, "laughing") == 0) return BuildLocalScene("я умираю со смеху");
    return {};
}
#endif

Application::Application() : notify_player_(audio_service_) {
    event_group_ = xEventGroupCreate();

#if CONFIG_USE_DEVICE_AEC && CONFIG_USE_SERVER_AEC
#error "CONFIG_USE_DEVICE_AEC and CONFIG_USE_SERVER_AEC cannot be enabled at the same time"
#elif CONFIG_USE_DEVICE_AEC
    aec_mode_ = kAecOnDeviceSide;
#elif CONFIG_USE_SERVER_AEC
    aec_mode_ = kAecOnServerSide;
#else
    aec_mode_ = kAecOff;
#endif

    esp_timer_create_args_t clock_timer_args = {.callback =
                                                    [](void* arg) {
                                                        Application* app = (Application*)arg;
                                                        xEventGroupSetBits(app->event_group_,
                                                                           MAIN_EVENT_CLOCK_TICK);
                                                    },
                                                .arg = this,
                                                .dispatch_method = ESP_TIMER_TASK,
                                                .name = "clock_timer",
                                                .skip_unhandled_events = true};
    esp_timer_create(&clock_timer_args, &clock_timer_handle_);

    // <ttuner83> One-shot voice reminder timer; it does not alter normal idle sleep.
    esp_timer_create_args_t reminder_args = {
        .callback = &Application::VoiceReminderTimerCallback,
        .arg = this,
        .dispatch_method = ESP_TIMER_TASK,
        .name = "voice_reminder",
        .skip_unhandled_events = true,
    };
    esp_timer_create(&reminder_args, &voice_reminder_timer_);

#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
    esp_timer_create_args_t radio_grace_args = {
        .callback = &Application::RadioVoiceGraceTimerCallback,
        .arg = this,
        .dispatch_method = ESP_TIMER_TASK,
        .name = "radio_voice_grace",
        .skip_unhandled_events = true,
    };
    esp_timer_create(&radio_grace_args, &radio_voice_grace_timer_);
#endif
}

Application::~Application() {
    notify_player_.Stop();
    if (voice_reminder_timer_ != nullptr) {
        esp_timer_stop(voice_reminder_timer_);
        esp_timer_delete(voice_reminder_timer_);
    }
    if (clock_timer_handle_ != nullptr) {
        esp_timer_stop(clock_timer_handle_);
        esp_timer_delete(clock_timer_handle_);
    }
    if (radio_voice_grace_timer_ != nullptr) {
        esp_timer_stop(radio_voice_grace_timer_);
        esp_timer_delete(radio_voice_grace_timer_);
    }
    vEventGroupDelete(event_group_);
}

bool Application::SetDeviceState(DeviceState state) {
    const DeviceState previous = state_machine_.GetState();
    const bool changed = state_machine_.TransitionTo(state);
    if (changed && state != previous) {
        if (state == kDeviceStateIdle) {
            idle_since_us_ = esp_timer_get_time();
        } else {
            idle_since_us_ = 0;
            if (idle_display_off_) {
                idle_display_off_ = false;
                auto& board = Board::GetInstance();
                auto display = board.GetDisplay();
                if (display) display->SetPowerSaveMode(false);
                if (auto backlight = board.GetBacklight()) backlight->RestoreBrightness();
                board.SetPowerSaveLevel(PowerSaveLevel::PERFORMANCE);
                esp_err_t wifi_err = esp_wifi_set_ps(WIFI_PS_NONE);
                if (wifi_err != ESP_OK) ESP_LOGW(TAG, "Could not restore Wi-Fi performance mode: %s", esp_err_to_name(wifi_err));
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
                TaijiWebRadio::UpdateWifiPowerSave();
#endif
                ESP_LOGI(TAG, "Idle screen wake: display/backlight restored");
            }
        }
    }
    return changed;
}

void Application::Initialize() {
    auto& board = Board::GetInstance();
    SetDeviceState(kDeviceStateStarting);

    // Setup the display
    auto display = board.GetDisplay();
    display->SetupUI();
    // Print board name/version info
    display->SetChatMessage("system", SystemInfo::GetUserAgent().c_str());

    // Setup the audio service
    auto codec = board.GetAudioCodec();
    audio_service_.Initialize(codec);
    audio_service_.Start();
    ESP_LOGI(TAG, "After board/audio init");
    SystemInfo::PrintHeapStats();

    AudioServiceCallbacks callbacks;
    callbacks.on_send_queue_available = [this]() {
        xEventGroupSetBits(event_group_, MAIN_EVENT_SEND_AUDIO);
    };
    callbacks.on_wake_word_detected = [this](const std::string& wake_word) {
        xEventGroupSetBits(event_group_, MAIN_EVENT_WAKE_WORD_DETECTED);
    };
    callbacks.on_vad_change = [this](bool speaking) {
        xEventGroupSetBits(event_group_, MAIN_EVENT_VAD_CHANGE);
    };
    callbacks.on_playback_drained = [this]() {
        xEventGroupSetBits(event_group_, MAIN_EVENT_PLAYBACK_DRAINED);
    };
    callbacks.on_playback_progress = [this](uint32_t playback_id, uint32_t media_position_ms) {
        notify_player_.OnPlaybackProgress(playback_id, media_position_ms);
    };
    audio_service_.SetCallbacks(callbacks);

    // Add state change listeners
    state_machine_.AddStateChangeListener([this](DeviceState old_state, DeviceState new_state) {
        xEventGroupSetBits(event_group_, MAIN_EVENT_STATE_CHANGED);
    });

    // Start the clock timer to update the status bar
    esp_timer_start_periodic(clock_timer_handle_, 1000000);

    // Add MCP common tools (only once during initialization)
    auto& mcp_server = McpServer::GetInstance();
    mcp_server.AddCommonTools();
    mcp_server.AddUserOnlyTools();

    // Set network event callback for UI updates and network state handling
    board.SetNetworkEventCallback([this](NetworkEvent event, const std::string& data) {
        auto display = Board::GetInstance().GetDisplay();

        switch (event) {
            case NetworkEvent::Scanning:
                display->ShowNotification(Lang::Strings::SCANNING_WIFI, 30000);
                xEventGroupSetBits(event_group_, MAIN_EVENT_NETWORK_DISCONNECTED);
                break;
            case NetworkEvent::Connecting: {
                if (data.empty()) {
                    // Cellular network - registering without carrier info yet
                    display->SetStatus(Lang::Strings::REGISTERING_NETWORK);
                } else {
                    // WiFi or cellular with carrier info
                    std::string msg = Lang::Strings::CONNECT_TO;
                    msg += data;
                    msg += "...";
                    display->ShowNotification(msg.c_str(), 30000);
                }
                break;
            }
            case NetworkEvent::Connected: {
                std::string msg = Lang::Strings::CONNECTED_TO;
                msg += data;
                display->ShowNotification(msg.c_str(), 30000);
                xEventGroupSetBits(event_group_, MAIN_EVENT_NETWORK_CONNECTED);
                break;
            }
            case NetworkEvent::Disconnected:
                xEventGroupSetBits(event_group_, MAIN_EVENT_NETWORK_DISCONNECTED);
                break;
            case NetworkEvent::WifiConfigModeEnter:
                // WiFi config mode enter is handled by WifiBoard internally
                break;
            case NetworkEvent::WifiConfigModeExit:
                // WiFi config mode exit is handled by WifiBoard internally
                break;
            // Cellular modem specific events
            case NetworkEvent::ModemDetecting:
                display->SetStatus(Lang::Strings::DETECTING_MODULE);
                break;
            case NetworkEvent::ModemErrorNoSim:
                Alert(Lang::Strings::ERROR, Lang::Strings::PIN_ERROR, "warning",
                      Lang::Sounds::OGG_ERR_PIN);
                break;
            case NetworkEvent::ModemErrorRegDenied:
                Alert(Lang::Strings::ERROR, Lang::Strings::REG_ERROR, "warning",
                      Lang::Sounds::OGG_ERR_REG);
                break;
            case NetworkEvent::ModemErrorInitFailed:
                Alert(Lang::Strings::ERROR, Lang::Strings::MODEM_INIT_ERROR, "warning",
                      Lang::Sounds::OGG_EXCLAMATION);
                break;
            case NetworkEvent::ModemErrorTimeout:
                display->SetStatus(Lang::Strings::REGISTERING_NETWORK);
                break;
        }
    });

    // Start network asynchronously
    board.StartNetwork();

    // Update the status bar immediately to show the network state
    display->UpdateStatusBar(true);
}

void Application::Run() {
    // Set the priority of the main task to 10
    vTaskPrioritySet(nullptr, 10);

    const EventBits_t ALL_EVENTS =
        MAIN_EVENT_SCHEDULE | MAIN_EVENT_SEND_AUDIO | MAIN_EVENT_WAKE_WORD_DETECTED |
        MAIN_EVENT_VAD_CHANGE | MAIN_EVENT_CLOCK_TICK | MAIN_EVENT_ERROR |
        MAIN_EVENT_NETWORK_CONNECTED | MAIN_EVENT_NETWORK_DISCONNECTED | MAIN_EVENT_TOGGLE_CHAT |
        MAIN_EVENT_START_LISTENING | MAIN_EVENT_STOP_LISTENING | MAIN_EVENT_ACTIVATION_DONE |
        MAIN_EVENT_STATE_CHANGED | MAIN_EVENT_PLAYBACK_DRAINED;

    while (true) {
        auto bits = xEventGroupWaitBits(event_group_, ALL_EVENTS, pdTRUE, pdFALSE, portMAX_DELAY);

        if (bits & MAIN_EVENT_ERROR) {
            if (GetDeviceState() == kDeviceStateNotifying) {
                StopNotification();
            }
            SetDeviceState(kDeviceStateIdle);
            Alert(Lang::Strings::ERROR, last_error_message_.c_str(), "cancel",
                  Lang::Sounds::OGG_EXCLAMATION);
        }

        if (bits & MAIN_EVENT_NETWORK_CONNECTED) {
            HandleNetworkConnectedEvent();
        }

        if (bits & MAIN_EVENT_NETWORK_DISCONNECTED) {
            HandleNetworkDisconnectedEvent();
        }

        if (bits & MAIN_EVENT_ACTIVATION_DONE) {
            HandleActivationDoneEvent();
        }

        if (bits & MAIN_EVENT_STATE_CHANGED) {
            HandleStateChangedEvent();
        }

        if (bits & MAIN_EVENT_PLAYBACK_DRAINED) {
            if (audio_service_.IsPlaybackIdle()) {
                notify_player_.OnPlaybackDrained();
            }
            // Deferred listening start (auto mode): the playback queue has
            // drained, so it is now safe to enable voice processing.
            if (pending_listening_start_ && GetDeviceState() == kDeviceStateListening &&
                audio_service_.IsPlaybackIdle()) {
                pending_listening_start_ = false;
                StartListeningAudio();
            }
        }

        if (bits & MAIN_EVENT_TOGGLE_CHAT) {
            HandleToggleChatEvent();
        }

        if (bits & MAIN_EVENT_START_LISTENING) {
            HandleStartListeningEvent();
        }

        if (bits & MAIN_EVENT_STOP_LISTENING) {
            HandleStopListeningEvent();
        }

        if (bits & MAIN_EVENT_SEND_AUDIO) {
            while (auto packet = audio_service_.PopPacketFromSendQueue()) {
                if (protocol_ && !protocol_->SendAudio(std::move(packet))) {
                    // Drop the remaining packets. Leaving them in the queue would
                    // stall the Opus codec task (it waits for queue space), which in
                    // turn deadlocks the whole audio input pipeline, as no new
                    // MAIN_EVENT_SEND_AUDIO event would ever be triggered again.
                    while (audio_service_.PopPacketFromSendQueue())
                        ;
                    break;
                }
            }
        }

        if (bits & MAIN_EVENT_WAKE_WORD_DETECTED) {
            HandleWakeWordDetectedEvent();
        }

        if (bits & MAIN_EVENT_VAD_CHANGE) {
            if (GetDeviceState() == kDeviceStateListening) {
                auto led = Board::GetInstance().GetLed();
                led->OnStateChanged();
            }
        }

        if (bits & MAIN_EVENT_SCHEDULE) {
            std::unique_lock<std::mutex> lock(mutex_);
            auto tasks = std::move(main_tasks_);
            lock.unlock();
            for (auto& task : tasks) {
                task();
            }
        }

        if (bits & MAIN_EVENT_CLOCK_TICK) {
            clock_ticks_++;
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
            // Bound each continuous listening window independently from the idle/sleep timer.
            if (GetDeviceState() == kDeviceStateListening) {
                if (listening_since_us_ == 0) listening_since_us_ = esp_timer_get_time();
                const int listen_timeout_seconds = TaijiWebRadio::GetListeningTimeoutSeconds();
                if (esp_timer_get_time() - listening_since_us_ >= static_cast<int64_t>(listen_timeout_seconds) * 1000000LL) {
                    ESP_LOGI(TAG, "Listening timeout (%d s): stop listening", listen_timeout_seconds);
                    if (protocol_) protocol_->SendStopListening();
                    listening_since_us_ = 0;
                    SetDeviceState(kDeviceStateIdle);
                }
            } else {
                listening_since_us_ = 0;
            }
#endif
            auto& board = Board::GetInstance();
            auto display = board.GetDisplay();
            display->UpdateStatusBar();
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
            if (GetDeviceState() == kDeviceStateIdle && !idle_display_off_ && idle_since_us_ > 0 &&
                !TaijiWebRadio::IsAnyRadioActive()) {
                const int timeout_seconds = TaijiWebRadio::GetIdleTimeoutSeconds();
                // The state machine can return to IDLE before the assistant's final
                // audio packets have drained. Never dim the display or enter deep
                // Wi-Fi modem sleep while the protocol/audio pipeline is still busy.
                // Restart the countdown while busy so the full timeout starts only
                // after the response and audio channel have actually finished.
                if (!CanEnterSleepMode()) {
                    idle_since_us_ = esp_timer_get_time();
                } else if (esp_timer_get_time() - idle_since_us_ >= static_cast<int64_t>(timeout_seconds) * 1000000LL) {
                    display->SetPowerSaveMode(true);
                    if (auto backlight = board.GetBacklight()) backlight->TurnOff();
                    board.SetPowerSaveLevel(PowerSaveLevel::LOW_POWER);
                    esp_err_t wifi_err = esp_wifi_set_ps(WIFI_PS_MAX_MODEM);
                    if (wifi_err != ESP_OK) ESP_LOGW(TAG, "Could not set maximum Wi-Fi modem sleep: %s", esp_err_to_name(wifi_err));
                    idle_display_off_ = true;
                    ESP_LOGI(TAG, "Idle timeout (%d s): display off, maximum power saving", timeout_seconds);
                }
            }
#endif

            // Print debug info every 10 seconds
            if (clock_ticks_ % 10 == 0) {
                SystemInfo::PrintHeapStats();
                // SystemInfo::PrintTaskList();
                // SystemInfo::PrintTaskCpuUsage(pdMS_TO_TICKS(1000));
            }
        }
    }
}

void Application::HandleNetworkConnectedEvent() {
    ESP_LOGI(TAG, "Network connected");
    auto state = GetDeviceState();

    if (state == kDeviceStateStarting || state == kDeviceStateWifiConfiguring) {
        // Network is ready, start activation
        SetDeviceState(kDeviceStateActivating);
        if (activation_task_handle_ != nullptr) {
            ESP_LOGW(TAG, "Activation task already running");
            return;
        }

        xTaskCreate(
            [](void* arg) {
                Application* app = static_cast<Application*>(arg);
                app->ActivationTask();
                app->activation_task_handle_ = nullptr;
                vTaskDelete(NULL);
            },
            "activation", 4096 * 2, this, 2, &activation_task_handle_);
    }

    // Update the status bar immediately to show the network state
    auto display = Board::GetInstance().GetDisplay();
    display->UpdateStatusBar(true);
}

void Application::HandleNetworkDisconnectedEvent() {
    // Close current conversation when network disconnected
    auto state = GetDeviceState();
    if (state == kDeviceStateNotifying) {
        StopNotification();
    }
    if (state == kDeviceStateConnecting || state == kDeviceStateListening ||
        state == kDeviceStateSpeaking) {
        ESP_LOGI(TAG, "Closing audio channel due to network disconnection");
        protocol_->CloseAudioChannel();
    }

    // Update the status bar immediately to show the network state
    auto display = Board::GetInstance().GetDisplay();
    display->UpdateStatusBar(true);
}

void Application::HandleActivationDoneEvent() {
    ESP_LOGI(TAG, "Activation done");

    SystemInfo::PrintHeapStats();
    SetDeviceState(kDeviceStateIdle);

    has_server_time_ = ota_->HasServerTime();

    // Protocol start may have already raised MAIN_EVENT_ERROR. Do not replace
    // that alert with the "ready" UI/sound — the main loop can process both
    // events back-to-back because the activation task is lower priority.
    const bool has_error = !last_error_message_.empty();
    if (!has_error) {
        auto display = Board::GetInstance().GetDisplay();
        std::string message = std::string(Lang::Strings::VERSION) + ota_->GetCurrentVersion();
        display->ShowNotification(message.c_str());
        display->SetChatMessage("system", "");
    }

    // Release OTA object after activation is complete
    ota_.reset();
    auto& board = Board::GetInstance();
    board.SetPowerSaveLevel(PowerSaveLevel::LOW_POWER);

    if (!has_error) {
        Schedule([this]() {
            // Play the success sound to indicate the device is ready
            audio_service_.PlaySound(Lang::Sounds::OGG_SUCCESS);
        });
    }
}

void Application::ActivationTask() {
    // Create OTA object for activation process
    ota_ = std::make_unique<Ota>();

    // Check for new assets version
    CheckAssetsVersion();

    // Check for new firmware version
    CheckNewVersion();

    // Initialize the protocol
    InitializeProtocol();

    // Signal completion to main loop
    xEventGroupSetBits(event_group_, MAIN_EVENT_ACTIVATION_DONE);
}

void Application::CheckAssetsVersion() {
    // Only allow CheckAssetsVersion to be called once
    if (assets_version_checked_) {
        return;
    }
    assets_version_checked_ = true;

    auto& board = Board::GetInstance();
    auto display = board.GetDisplay();
    auto& assets = Assets::GetInstance();

    if (!assets.partition_valid()) {
        ESP_LOGW(TAG, "Assets partition is disabled for board %s", BOARD_NAME);
        return;
    }

    Settings settings("assets", true);
    // Check if there is a new assets need to be downloaded
    std::string download_url = settings.GetString("download_url");

    if (!download_url.empty()) {
        settings.EraseKey("download_url");

        char message[256];
        snprintf(message, sizeof(message), Lang::Strings::FOUND_NEW_ASSETS, download_url.c_str());
        Alert(Lang::Strings::LOADING_ASSETS, message, "cloud_download", Lang::Sounds::OGG_UPGRADE);

        // Wait for the audio service to be idle for 3 seconds
        vTaskDelay(pdMS_TO_TICKS(3000));
        SetDeviceState(kDeviceStateUpgrading);
        board.SetPowerSaveLevel(PowerSaveLevel::PERFORMANCE);
        display->SetChatMessage("system", Lang::Strings::PLEASE_WAIT);

        bool success =
            assets.Download(download_url, [this, display](int progress, size_t speed) -> void {
                char buffer[32];
                snprintf(buffer, sizeof(buffer), "%d%% %uKB/s", progress, speed / 1024);
                Schedule([display, message = std::string(buffer)]() {
                    display->SetChatMessage("system", message.c_str());
                });
            });

        board.SetPowerSaveLevel(PowerSaveLevel::LOW_POWER);
        vTaskDelay(pdMS_TO_TICKS(1000));

        if (!success) {
            Alert(Lang::Strings::ERROR, Lang::Strings::DOWNLOAD_ASSETS_FAILED, "cancel",
                  Lang::Sounds::OGG_EXCLAMATION);
            vTaskDelay(pdMS_TO_TICKS(2000));
            SetDeviceState(kDeviceStateActivating);
            return;
        }
    }

    // Apply assets
    assets.Apply();
    display->SetChatMessage("system", "");
    display->SetEmotion("robot_2");
}

void Application::CheckNewVersion() {
    const int MAX_RETRY = 10;
    int retry_count = 0;
    int retry_delay = 10;  // Initial retry delay in seconds

    auto& board = Board::GetInstance();
    while (true) {
        auto display = board.GetDisplay();
        display->SetStatus(Lang::Strings::CHECKING_NEW_VERSION);

        auto check = ota_->CheckVersion();
        if (!check) {
            retry_count++;
            if (retry_count >= MAX_RETRY) {
                ESP_LOGE(TAG, "Too many retries, exit version check");
                return;
            }

            const auto& err = check.error();
            char error_message[160];
            int error_message_length =
                snprintf(error_message, sizeof(error_message), "%s", err.ToString().c_str());
            if (error_message_length < 0 ||
                error_message_length >= static_cast<int>(sizeof(error_message))) {
                snprintf(error_message, sizeof(error_message), "%s", err.Message());
            }

            char buffer[320];
            int alert_message_length =
                snprintf(buffer, sizeof(buffer), Lang::Strings::CHECK_NEW_VERSION_FAILED,
                         retry_delay, error_message);
            if (alert_message_length < 0 ||
                alert_message_length >= static_cast<int>(sizeof(buffer))) {
                snprintf(buffer, sizeof(buffer), "%s", err.Message());
            }
            Alert(Lang::Strings::ERROR, buffer, "cloud_off", Lang::Sounds::OGG_EXCLAMATION);

            ESP_LOGW(TAG, "Check new version failed, retry in %d seconds (%d/%d)", retry_delay,
                     retry_count, MAX_RETRY);
            for (int i = 0; i < retry_delay; i++) {
                vTaskDelay(pdMS_TO_TICKS(1000));
                if (GetDeviceState() == kDeviceStateIdle) {
                    break;
                }
            }
            retry_delay *= 2;  // Double the retry delay
            continue;
        }
        retry_count = 0;
        retry_delay = 10;  // Reset retry delay

        if (ota_->HasNewVersion()) {
            if (UpgradeFirmware(ota_->GetFirmwareUrl(), ota_->GetFirmwareVersion())) {
                return;  // This line will never be reached after reboot
            }
            // If upgrade failed, continue to normal operation
        }

        // No new version, mark the current version as valid
        ota_->MarkCurrentVersionValid();
        if (!ota_->HasActivationCode() && !ota_->HasActivationChallenge()) {
            // Exit the loop if done checking new version
            break;
        }

        display->SetStatus(Lang::Strings::ACTIVATION);
        // Activation code is shown to the user and waiting for the user to input
        if (ota_->HasActivationCode()) {
            ShowActivationCode(ota_->GetActivationCode(), ota_->GetActivationMessage());
        }

        // This will block the loop until the activation is done or timeout
        for (int i = 0; i < 10; ++i) {
            ESP_LOGI(TAG, "Activating... %d/%d", i + 1, 10);
            esp_err_t err = ota_->Activate();
            if (err == ESP_OK) {
                break;
            } else if (err == ESP_ERR_TIMEOUT) {
                vTaskDelay(pdMS_TO_TICKS(3000));
            } else {
                vTaskDelay(pdMS_TO_TICKS(10000));
            }
            if (GetDeviceState() == kDeviceStateIdle) {
                break;
            }
        }
    }
}

void Application::InitializeProtocol() {
    auto& board = Board::GetInstance();
    auto display = board.GetDisplay();
    auto codec = board.GetAudioCodec();

    display->SetStatus(Lang::Strings::LOADING_PROTOCOL);

    if (ota_->HasMqttConfig()) {
        protocol_ = std::make_unique<MqttProtocol>();
    } else if (ota_->HasWebsocketConfig()) {
        protocol_ = std::make_unique<WebsocketProtocol>();
    } else {
        ESP_LOGW(TAG, "No protocol specified in the OTA config, using MQTT");
        protocol_ = std::make_unique<MqttProtocol>();
    }

    protocol_->OnConnected([this]() { DismissAlert(); });

    protocol_->OnNetworkError([this](const std::string& message) {
        last_error_message_ = message;
        xEventGroupSetBits(event_group_, MAIN_EVENT_ERROR);
    });

    protocol_->OnIncomingAudio([this](std::unique_ptr<AudioStreamPacket> packet) {
        if (GetDeviceState() == kDeviceStateSpeaking) {
            audio_service_.PushPacketToDecodeQueue(std::move(packet));
        }
    });

    protocol_->OnAudioChannelOpened([this, codec, &board]() {
        board.SetPowerSaveLevel(PowerSaveLevel::PERFORMANCE);
        if (protocol_->server_sample_rate() != codec->output_sample_rate()) {
            ESP_LOGW(TAG,
                     "Server sample rate %d does not match device output sample rate %d, "
                     "resampling may cause distortion",
                     protocol_->server_sample_rate(), codec->output_sample_rate());
        }
    });

    protocol_->OnAudioChannelClosed([this, &board]() {
        board.SetPowerSaveLevel(PowerSaveLevel::LOW_POWER);
        Schedule([this]() {
            auto display = Board::GetInstance().GetDisplay();
            display->SetChatMessage("system", "");
            SetDeviceState(kDeviceStateIdle);
        });
    });

    protocol_->OnIncomingJson([this, display](const cJSON* root) {
        // Parse JSON data
        auto type = cJSON_GetObjectItem(root, "type");
        if (!cJSON_IsString(type)) {
            ESP_LOGW(TAG, "Incoming JSON message has no type");
            return;
        }
        if (strcmp(type->valuestring, "notify") == 0) {
            auto audio_url = cJSON_GetObjectItem(root, "audio_url");
            if (!cJSON_IsString(audio_url) || audio_url->valuestring[0] == '\0') {
                ESP_LOGW(TAG, "Notify message requires audio_url");
                return;
            }

            std::vector<NotifySubtitle> subtitles;
            auto subtitles_json = cJSON_GetObjectItem(root, "subtitles");
            if (subtitles_json != nullptr && !cJSON_IsArray(subtitles_json)) {
                ESP_LOGW(TAG, "Notify subtitles must be an array");
                return;
            }
            if (cJSON_IsArray(subtitles_json)) {
                cJSON* item = nullptr;
                cJSON_ArrayForEach (item, subtitles_json) {
                    auto start_ms = cJSON_GetObjectItem(item, "start_ms");
                    auto text = cJSON_GetObjectItem(item, "text");
                    if (!cJSON_IsNumber(start_ms) || start_ms->valuedouble < 0 ||
                        start_ms->valuedouble > std::numeric_limits<uint32_t>::max() ||
                        !cJSON_IsString(text)) {
                        ESP_LOGW(TAG, "Ignoring invalid notify subtitle");
                        continue;
                    }
                    subtitles.push_back({.start_ms = static_cast<uint32_t>(start_ms->valuedouble),
                                         .text = text->valuestring});
                }
            }

            Schedule([this, url = std::string(audio_url->valuestring),
                      subtitles = std::move(subtitles)]() mutable {
                StartNotification(std::move(url), std::move(subtitles));
            });
        } else if (strcmp(type->valuestring, "tts") == 0) {
            auto state = cJSON_GetObjectItem(root, "state");
            if (!cJSON_IsString(state)) {
                return;
            }
            if (strcmp(state->valuestring, "start") == 0) {
                Schedule([this]() {
                    aborted_ = false;
                    SetDeviceState(kDeviceStateSpeaking);
                });
            } else if (strcmp(state->valuestring, "stop") == 0) {
                Schedule([this]() {
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3
                    Board::GetInstance().GetDisplay()->FinishGeneratedScene();
#endif
                    if (GetDeviceState() == kDeviceStateSpeaking) {
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
                        if (TaijiWebRadio::IsAnyRadioActive()) {
                            radio_voice_processing_grace_ = true;
                            TaijiWebRadio::SetAssistantDuck(true);
                            if (protocol_) protocol_->SendStopListening();
                            SetDeviceState(kDeviceStateIdle);
                            return;
                        }
#endif
                        if (listening_mode_ == kListeningModeManualStop) SetDeviceState(kDeviceStateIdle);
                        else SetDeviceState(kDeviceStateListening);
                    }
                });
            } else if (strcmp(state->valuestring, "sentence_start") == 0) {
                auto text = cJSON_GetObjectItem(root, "text");
                if (cJSON_IsString(text)) {
                    std::vector<TextGlyph> glyphs;
                    uint8_t bpp = 0;
                    if (!TextGlyphPayload::Parse(root, glyphs, bpp)) {
                        glyphs.clear();
                    }
                    ESP_LOGI(TAG, "<< %s", text->valuestring);
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3
                    // If the user transcript did not already start a scene, also
                    // inspect the assistant's actual spoken sentence. This lets
                    // Cosmo act out a multi-action answer, not only the prompt.
                    if (!g_local_scene_triggered_for_turn) {
                        const std::string assistant_scene = BuildLocalScene(text->valuestring);
                        if (!assistant_scene.empty()) {
                            g_local_scene_triggered_for_turn = true;
                            ESP_LOGI(TAG, "Local scene sequence detected in assistant sentence");
                            Schedule([display, scene_payload = assistant_scene]() {
                                display->ShowGeneratedScene(scene_payload.c_str());
                            });
                        }
                    }
#endif
                    Schedule([display, message = std::string(text->valuestring),
                              glyphs = std::move(glyphs), bpp]() {
                        display->AddTextGlyphs(glyphs, bpp);
                        display->SetChatMessage("assistant", message.c_str());
                    });
                }
            }
        } else if (strcmp(type->valuestring, "stt") == 0) {
            auto text = cJSON_GetObjectItem(root, "text");
            if (cJSON_IsString(text)) {
                std::vector<TextGlyph> glyphs;
                uint8_t bpp = 0;
                if (!TextGlyphPayload::Parse(root, glyphs, bpp)) {
                    glyphs.clear();
                }
                ESP_LOGI(TAG, ">> %s", text->valuestring);
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3
                g_local_scene_triggered_for_turn = false;
                {
                    const std::string local_scene = BuildLocalScene(text->valuestring);
                    if (!local_scene.empty()) {
                        g_local_scene_triggered_for_turn = true;
                        ESP_LOGI(TAG, "Local scene trigger detected from STT transcript");
                        Schedule([display, scene_payload = local_scene]() {
                            display->ShowGeneratedScene(scene_payload.c_str());
                        });
                    }
                }
#endif
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
                // Do not depend on the cloud model deciding to call MCP for this
                // safety-critical local control: stop the radio as soon as STT
                // recognizes the explicit command, on a worker so the protocol
                // receive callback and main event loop are not blocked.
                if (IsRadioStopVoiceCommand(text->valuestring)) {
                    ESP_LOGI(TAG, "Recognized local radio-stop command from STT: %s", text->valuestring);
                    BaseType_t task_ok = xTaskCreate(
                        [](void*) {
                            const bool stopped = TaijiWebRadio::StopActiveRadioFromVoice();
                            ESP_LOGI(TAG, "Local radio-stop result: %s", stopped ? "stopped" : "not stopped");
                            vTaskDelete(nullptr);
                        }, "voice_radio_stop", 3072, nullptr, 7, nullptr);
                    if (task_ok != pdPASS) {
                        ESP_LOGW(TAG, "Could not create local radio-stop task");
                    }
                }
#endif
                Schedule([display, message = std::string(text->valuestring),
                          glyphs = std::move(glyphs), bpp]() {
                    display->AddTextGlyphs(glyphs, bpp);
                    display->SetChatMessage("user", message.c_str());
                });
            }
        } else if (strcmp(type->valuestring, "llm") == 0) {
            auto emotion = cJSON_GetObjectItem(root, "emotion");
            if (cJSON_IsString(emotion)) {
                Schedule([display, emotion_str = std::string(emotion->valuestring)]() {
                    display->SetEmotion(emotion_str.c_str());
                });
            }
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3
            // Use standard XiaoZhi emotion metadata as an autonomous trigger.
            // Avoid restarting a scene already selected from this turn's STT.
            if (!g_local_scene_triggered_for_turn && cJSON_IsString(emotion)) {
                const std::string local_scene = BuildLocalEmotionScene(emotion->valuestring);
                if (!local_scene.empty()) {
                    g_local_scene_triggered_for_turn = true;
                    ESP_LOGI(TAG, "Local scene trigger detected from XiaoZhi emotion metadata: %s", emotion->valuestring);
                    Schedule([display, scene_payload = local_scene]() {
                        display->ShowGeneratedScene(scene_payload.c_str());
                    });
                }
            }
            // Optional server-side LLM extension. The model must explicitly classify
            // the reason before a generated scene is accepted; normal turns stay Cosmo-only.
            auto scene = cJSON_GetObjectItemCaseSensitive(root, "scene");
            auto trigger = cJSON_IsObject(scene) ? cJSON_GetObjectItemCaseSensitive(scene, "trigger") : nullptr;
            if (cJSON_IsString(trigger) &&
                (strcmp(trigger->valuestring, "explicit") == 0 ||
                 strcmp(trigger->valuestring, "game") == 0 ||
                 strcmp(trigger->valuestring, "strong_emotion") == 0)) {
                char* scene_json = cJSON_PrintUnformatted(scene);
                if (scene_json != nullptr) {
                    std::string scene_payload(scene_json);
                    cJSON_free(scene_json);
                    Schedule([display, scene_payload = std::move(scene_payload)]() {
                        display->ShowGeneratedScene(scene_payload.c_str());
                    });
                }
            }
#endif
        } else if (strcmp(type->valuestring, "mcp") == 0) {
            auto payload = cJSON_GetObjectItem(root, "payload");
            if (cJSON_IsObject(payload)) {
                McpServer::GetInstance().ParseMessage(payload);
            }
        } else if (strcmp(type->valuestring, "system") == 0) {
            auto command = cJSON_GetObjectItem(root, "command");
            if (cJSON_IsString(command)) {
                ESP_LOGI(TAG, "System command: %s", command->valuestring);
                if (strcmp(command->valuestring, "reboot") == 0) {
                    // Do a reboot if user requests a OTA update
                    Schedule([this]() { Reboot(); });
                } else {
                    ESP_LOGW(TAG, "Unknown system command: %s", command->valuestring);
                }
            }
        } else if (strcmp(type->valuestring, "alert") == 0) {
            auto status = cJSON_GetObjectItem(root, "status");
            auto message = cJSON_GetObjectItem(root, "message");
            auto emotion = cJSON_GetObjectItem(root, "emotion");
            if (cJSON_IsString(status) && cJSON_IsString(message) && cJSON_IsString(emotion)) {
                Alert(status->valuestring, message->valuestring, emotion->valuestring,
                      Lang::Sounds::OGG_VIBRATION);
            } else {
                ESP_LOGW(TAG, "Alert command requires status, message and emotion");
            }
#if CONFIG_RECEIVE_CUSTOM_MESSAGE
        } else if (strcmp(type->valuestring, "custom") == 0) {
            auto payload = cJSON_GetObjectItem(root, "payload");
            ESP_LOGI(TAG, "Received custom message: %s", cJSON_PrintUnformatted(root));
            if (cJSON_IsObject(payload)) {
                Schedule(
                    [this, display, payload_str = std::string(cJSON_PrintUnformatted(payload))]() {
                        display->SetChatMessage("system", payload_str.c_str());
                    });
            } else {
                ESP_LOGW(TAG, "Invalid custom message format: missing payload");
            }
#endif
        } else {
            ESP_LOGW(TAG, "Unknown message type: %s", type->valuestring);
        }
    });

    protocol_->Start();
}

void Application::ShowActivationCode(const std::string& code, const std::string& message) {
    struct digit_sound {
        char digit;
        const std::string_view& sound;
    };
    static const std::array<digit_sound, 10> digit_sounds{
        {digit_sound{'0', Lang::Sounds::OGG_0}, digit_sound{'1', Lang::Sounds::OGG_1},
         digit_sound{'2', Lang::Sounds::OGG_2}, digit_sound{'3', Lang::Sounds::OGG_3},
         digit_sound{'4', Lang::Sounds::OGG_4}, digit_sound{'5', Lang::Sounds::OGG_5},
         digit_sound{'6', Lang::Sounds::OGG_6}, digit_sound{'7', Lang::Sounds::OGG_7},
         digit_sound{'8', Lang::Sounds::OGG_8}, digit_sound{'9', Lang::Sounds::OGG_9}}};

    // This sentence uses 9KB of SRAM, so we need to wait for it to finish
    Alert(Lang::Strings::ACTIVATION, message.c_str(), "link", Lang::Sounds::OGG_ACTIVATION);

    for (const auto& digit : code) {
        auto it = std::find_if(digit_sounds.begin(), digit_sounds.end(),
                               [digit](const digit_sound& ds) { return ds.digit == digit; });
        if (it != digit_sounds.end()) {
            audio_service_.PlaySound(it->sound);
        }
    }
}

void Application::Alert(const char* status, const char* message, const char* emotion,
                        const std::string_view& sound) {
    ESP_LOGW(TAG, "Alert [%s] %s: %s", emotion, status, message);
    auto display = Board::GetInstance().GetDisplay();
    display->SetStatus(status);
    display->SetEmotion(emotion);
    display->SetChatMessage("system", message);
    if (!sound.empty()) {
        audio_service_.PlaySound(sound);
    }
}

void Application::DismissAlert() {
    last_error_message_.clear();
    if (GetDeviceState() == kDeviceStateIdle) {
        auto display = Board::GetInstance().GetDisplay();
        display->SetStatus(Lang::Strings::STANDBY);
        display->SetEmotion("neutral");
        display->SetChatMessage("system", "");
    }
}

void Application::ToggleChatState() { xEventGroupSetBits(event_group_, MAIN_EVENT_TOGGLE_CHAT); }

void Application::StartListening() { xEventGroupSetBits(event_group_, MAIN_EVENT_START_LISTENING); }

void Application::StopListening() { xEventGroupSetBits(event_group_, MAIN_EVENT_STOP_LISTENING); }

void Application::EnterRadioSilentIdle(bool assistant_started_radio) {
    Schedule([this, assistant_started_radio]() {
        radio_silent_mode_ = true;
        radio_voice_processing_grace_ = assistant_started_radio;
        if (radio_voice_grace_timer_ != nullptr) {
            esp_timer_stop(radio_voice_grace_timer_);
            if (assistant_started_radio) {
                esp_timer_start_once(radio_voice_grace_timer_, 3 * 1000 * 1000);
            }
        }

        audio_service_.ResetDecoder();
        const auto state = GetDeviceState();
        if (state == kDeviceStateSpeaking || state == kDeviceStateListening) {
            while (audio_service_.PopPacketFromSendQueue()) {
            }
            SetDeviceState(kDeviceStateIdle);
        }
        // Music playback is silent: disable the heavy voice pipeline and keep only
        // wake-word detection active. The wake word can still open a brief control turn.
        if (!assistant_started_radio) {
            audio_service_.EnableVoiceProcessing(false);
        }
        audio_service_.EnableWakeWordDetection(true);
    });
}

void Application::RadioVoiceGraceTimerCallback(void* arg) {
    auto* app = static_cast<Application*>(arg);
    if (app != nullptr) {
        app->Schedule([app]() { app->FinishRadioVoiceGrace(); });
    }
}

void Application::FinishRadioVoiceGrace() {
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
    if (!radio_voice_processing_grace_) return;
    if (!TaijiWebRadio::IsAnyRadioActive()) {
        radio_voice_processing_grace_ = false;
        radio_voice_session_seen_ = false;
        return;
    }
    const auto state = GetDeviceState();
    if (state != kDeviceStateIdle) {
        // Never turn off AFE while connecting, listening or speaking.
        if (radio_voice_grace_timer_ != nullptr) esp_timer_start_once(radio_voice_grace_timer_, 3 * 1000 * 1000);
        return;
    }
    if (!radio_voice_session_seen_) {
        // Wake/activation can spend several seconds in Idle before the cloud
        // session starts. Keep voice processing available for a 12-second
        // startup window instead of expiring the old 3-second timer too early.
        const int64_t elapsed = esp_timer_get_time() - radio_voice_activation_started_us_;
        if (elapsed < 12 * 1000 * 1000) {
            if (radio_voice_grace_timer_ != nullptr) esp_timer_start_once(radio_voice_grace_timer_, 1000 * 1000);
            return;
        }
    }
    radio_voice_processing_grace_ = false;
    radio_voice_session_seen_ = false;
    audio_service_.EnableVoiceProcessing(false);
    audio_service_.EnableWakeWordDetection(true);
    TaijiWebRadio::SetAssistantDuck(false);
#endif
}

void Application::ExitRadioSilentIdle() {
    Schedule([this]() {
        if (radio_voice_grace_timer_ != nullptr) {
            esp_timer_stop(radio_voice_grace_timer_);
        }
        radio_voice_processing_grace_ = false;
        if (!radio_silent_mode_) {
            return;
        }
        radio_silent_mode_ = false;
        if (GetDeviceState() == kDeviceStateIdle) {
            audio_service_.EnableVoiceProcessing(false);
            audio_service_.EnableWakeWordDetection(true);
        }
    });
}

void Application::ResetIdleDisplayTimer() {
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
    Schedule([this]() {
        idle_since_us_ = esp_timer_get_time();
        idle_display_off_ = false;
        auto& board = Board::GetInstance();
        if (auto display = board.GetDisplay()) display->SetPowerSaveMode(false);
        if (auto backlight = board.GetBacklight()) backlight->RestoreBrightness();
        board.SetPowerSaveLevel(PowerSaveLevel::PERFORMANCE);
        ESP_LOGI(TAG, "Idle display timer restarted after leaving music player");
    });
#endif
}

void Application::HandleToggleChatEvent() {
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
    // A tap/wake word during radio playback starts a short voice-control session;
    // the stream remains active but its PCM output is ducked.
    if (TaijiWebRadio::IsAnyRadioActive()) {
        TaijiWebRadio::SetAssistantDuck(true);
        radio_voice_processing_grace_ = true;
        radio_voice_session_seen_ = false;
        radio_voice_activation_started_us_ = esp_timer_get_time();
        if (radio_voice_grace_timer_ != nullptr) {
            esp_timer_stop(radio_voice_grace_timer_);
            // Give the assistant enough time to activate, hear and process the
            // first command. The 3-second quiet timeout starts after the turn.
            esp_timer_start_once(radio_voice_grace_timer_, 12 * 1000 * 1000);
        }
    }
#endif
    radio_silent_mode_ = false;
    auto state = GetDeviceState();

    if (state == kDeviceStateNotifying) {
        StopNotification();
        state = kDeviceStateIdle;
    }

    if (state == kDeviceStateActivating) {
        SetDeviceState(kDeviceStateIdle);
        return;
    } else if (state == kDeviceStateWifiConfiguring) {
        audio_service_.EnableAudioTesting(true);
        SetDeviceState(kDeviceStateAudioTesting);
        return;
    } else if (state == kDeviceStateAudioTesting) {
        audio_service_.EnableAudioTesting(false);
        SetDeviceState(kDeviceStateWifiConfiguring);
        return;
    }

    if (!protocol_) {
        ESP_LOGE(TAG, "Protocol not initialized");
        return;
    }

    if (state == kDeviceStateIdle) {
        ListeningMode mode = GetDefaultListeningMode();
        if (!protocol_->IsAudioChannelOpened()) {
            SetDeviceState(kDeviceStateConnecting);
            // Schedule to let the state change be processed first (UI update)
            Schedule([this, mode]() { ContinueOpenAudioChannel(mode); });
            return;
        }
        SetListeningMode(mode);
    } else if (state == kDeviceStateSpeaking) {
        AbortSpeaking(kAbortReasonNone);
    } else if (state == kDeviceStateListening) {
        protocol_->CloseAudioChannel();
    }
}

void Application::ContinueOpenAudioChannel(ListeningMode mode) {
    // Check state again in case it was changed during scheduling
    if (GetDeviceState() != kDeviceStateConnecting) {
        return;
    }

    // Switch to performance mode before connecting to reduce latency
    auto& board = Board::GetInstance();
    board.SetPowerSaveLevel(PowerSaveLevel::PERFORMANCE);

    if (!protocol_->IsAudioChannelOpened()) {
        if (!protocol_->OpenAudioChannel()) {
            // Return to idle so the device is not stuck in the connecting
            // state (not every failure path reports a network error)
            SetDeviceState(kDeviceStateIdle);
            return;
        }
    }

    SetListeningMode(mode);
}

void Application::HandleStartListeningEvent() {
    auto state = GetDeviceState();

    if (state == kDeviceStateNotifying) {
        StopNotification();
        state = kDeviceStateIdle;
    }

    if (state == kDeviceStateActivating) {
        SetDeviceState(kDeviceStateIdle);
        return;
    } else if (state == kDeviceStateWifiConfiguring) {
        audio_service_.EnableAudioTesting(true);
        SetDeviceState(kDeviceStateAudioTesting);
        return;
    }

    if (!protocol_) {
        ESP_LOGE(TAG, "Protocol not initialized");
        return;
    }

    if (state == kDeviceStateIdle) {
        if (!protocol_->IsAudioChannelOpened()) {
            SetDeviceState(kDeviceStateConnecting);
            // Schedule to let the state change be processed first (UI update)
            Schedule([this]() { ContinueOpenAudioChannel(kListeningModeManualStop); });
            return;
        }
        SetListeningMode(kListeningModeManualStop);
    } else if (state == kDeviceStateSpeaking) {
        AbortSpeaking(kAbortReasonNone);
        SetListeningMode(kListeningModeManualStop);
    }
}

void Application::HandleStopListeningEvent() {
    auto state = GetDeviceState();

    if (state == kDeviceStateNotifying) {
        StopNotification();
    } else if (state == kDeviceStateAudioTesting) {
        audio_service_.EnableAudioTesting(false);
        SetDeviceState(kDeviceStateWifiConfiguring);
        return;
    } else if (state == kDeviceStateListening) {
        if (protocol_) {
            protocol_->SendStopListening();
        }
        SetDeviceState(kDeviceStateIdle);
    }
}

void Application::HandleWakeWordDetectedEvent() {
    if (!protocol_) {
        return;
    }
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
    if (TaijiWebRadio::IsAnyRadioActive()) {
        // Duck the radio immediately on wake detection, before opening the cloud
        // session, so the single PDM microphone can hear the user's command.
        TaijiWebRadio::SetAssistantDuck(true);
        radio_voice_processing_grace_ = true;
        radio_voice_session_seen_ = false;
        radio_voice_activation_started_us_ = esp_timer_get_time();
        radio_silent_mode_ = false;
        if (radio_voice_grace_timer_ != nullptr) {
            esp_timer_stop(radio_voice_grace_timer_);
            esp_timer_start_once(radio_voice_grace_timer_, 12 * 1000 * 1000);
        }
    }
#endif

    auto state = GetDeviceState();
    auto wake_word = audio_service_.GetLastWakeWord();
    ESP_LOGI(TAG, "Wake word detected: %s (state: %d)", wake_word.c_str(), (int)state);

    if (state == kDeviceStateIdle) {
        BeginWakeWordInvoke(wake_word);
    } else if (state == kDeviceStateNotifying) {
        StopNotification();
        BeginWakeWordInvoke(wake_word);
    } else if (state == kDeviceStateSpeaking || state == kDeviceStateListening) {
        AbortSpeaking(kAbortReasonWakeWordDetected);
        // Clear send queue to avoid sending residues to server
        while (audio_service_.PopPacketFromSendQueue())
            ;

        if (state == kDeviceStateListening) {
            protocol_->SendStartListening(GetDefaultListeningMode());
            audio_service_.ResetDecoder();
            audio_service_.PlaySound(Lang::Sounds::OGG_POPUP);
            // Re-enable wake word detection as it was stopped by the detection itself
            audio_service_.EnableWakeWordDetection(true);
        } else {
            // Play popup sound and start listening again
            play_popup_on_listening_ = true;
            SetListeningMode(GetDefaultListeningMode());
        }
    } else if (state == kDeviceStateActivating) {
        // Restart the activation check if the wake word is detected during activation
        SetDeviceState(kDeviceStateIdle);
    }
}

void Application::BeginWakeWordInvoke(const std::string& wake_word) {
    // Must run in the main task with the device in idle state
    audio_service_.EncodeWakeWord();
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
    if (TaijiWebRadio::IsAnyRadioActive()) {
        // Duck radio immediately, but do not start the high-priority AFE/input
        // pipeline before the MQTT audio channel is open. On the Taiji board this
        // can starve the main/MQTT tasks and leave the state stuck at Connecting.
        // Voice processing is enabled by StartListeningAudio() after the server
        // channel is ready and the state has moved to Listening.
        TaijiWebRadio::SetAssistantDuck(true);
        audio_service_.EnableWakeWordDetection(true);
    }
#endif

    // Always pass through the connecting state, even if the audio channel is
    // already opened. ContinueWakeWordInvoke() rejects any other state, so
    // skipping this transition would silently drop the wake word invocation.
    if (!SetDeviceState(kDeviceStateConnecting)) {
        // Wake word detection was stopped by the detection itself; restore it
        // so the device does not become unresponsive to wake words.
        audio_service_.EnableWakeWordDetection(true);
        return;
    }

    if (!protocol_->IsAudioChannelOpened()) {
        // Schedule to let the state change be processed first (UI update),
        // then continue with OpenAudioChannel which may block for ~1 second
        Schedule([this, wake_word]() { ContinueWakeWordInvoke(wake_word); });
        return;
    }
    // Channel already opened, continue directly
    ContinueWakeWordInvoke(wake_word);
}

void Application::ContinueWakeWordInvoke(const std::string& wake_word) {
    // Check state again in case it was changed during scheduling
    if (GetDeviceState() != kDeviceStateConnecting) {
        return;
    }

    // Switch to performance mode before connecting to reduce latency
    auto& board = Board::GetInstance();
    board.SetPowerSaveLevel(PowerSaveLevel::PERFORMANCE);

    if (!protocol_->IsAudioChannelOpened()) {
        ESP_LOGI(TAG, "Opening audio channel for wake-word session");
        if (!protocol_->OpenAudioChannel()) {
            ESP_LOGE(TAG, "Could not open audio channel for wake-word session; returning to idle");
            // Return to idle so the device is not stuck in the connecting
            // state (not every failure path reports a network error), and
            // wake word detection is re-enabled by the idle state handler.
            SetDeviceState(kDeviceStateIdle);
            return;
        }
        ESP_LOGI(TAG, "Audio channel opened for wake-word session");
    } else {
        ESP_LOGI(TAG, "Reusing open audio channel for wake-word session");
    }

    ESP_LOGI(TAG, "Wake word detected: %s", wake_word.c_str());
#if CONFIG_SEND_WAKE_WORD_DATA
    // Encode and send the wake word data to the server
    while (auto packet = audio_service_.PopWakeWordPacket()) {
        protocol_->SendAudio(std::move(packet));
    }
    // Set the chat state to wake word detected
    protocol_->SendWakeWordDetected(wake_word);
    SetListeningMode(GetDefaultListeningMode());
#else
    // Set flag to play popup sound after state changes to listening
    // (PlaySound here would be cleared by ResetDecoder in EnableVoiceProcessing)
    play_popup_on_listening_ = true;
    SetListeningMode(GetDefaultListeningMode());
#endif
}

void Application::HandleStateChangedEvent() {
    DeviceState new_state = state_machine_.GetState();
    clock_ticks_ = 0;
    // Any state change invalidates a pending deferred listening start;
    // the Listening case below re-arms it when needed.
    pending_listening_start_ = false;

    auto& board = Board::GetInstance();
    auto display = board.GetDisplay();
    auto led = board.GetLed();
    led->OnStateChanged();

#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
    // Wi-Fi stays awake while the voice assistant is active and returns to
    // modem-sleep once the conversation is over. Radio playback has priority
    // and keeps WIFI_PS_NONE even while the application is idle.
    TaijiWebRadio::UpdateWifiPowerSave();
#endif

    switch (new_state) {
        case kDeviceStateUnknown:
        case kDeviceStateIdle: {
            // Keep a just-raised network error visible. SetDeviceState(idle)
            // queues STATE_CHANGED after Alert(), and the idle handler would
            // otherwise wipe the status, emotion, and chat message.
            if (last_error_message_.empty()) {
                display->SetStatus(Lang::Strings::STANDBY);
                display->ClearChatMessages();  // Clear messages first
                display->SetEmotion(
                    "neutral");  // Then set emotion (wechat mode checks child count)
            }
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
            const bool radio_active = TaijiWebRadio::IsAnyRadioActive();
            if (radio_active) {
                radio_silent_mode_ = true;
                if (!radio_voice_processing_grace_) {
                    audio_service_.EnableVoiceProcessing(false);
                }
                audio_service_.EnableWakeWordDetection(true);
            } else
#endif
            {
                audio_service_.EnableVoiceProcessing(false);
                audio_service_.EnableWakeWordDetection(!radio_silent_mode_);
            }
            break;
        }
        case kDeviceStateConnecting:
            display->SetStatus(Lang::Strings::CONNECTING);
            display->SetEmotion("neutral");
            display->SetChatMessage("system", "");
            break;
        case kDeviceStateListening:
            display->SetStatus(Lang::Strings::LISTENING);
            display->SetEmotion("neutral");

            // Make sure the audio processor is running
            if (play_popup_on_listening_ || !audio_service_.IsAudioProcessorRunning()) {
                // For auto mode, wait for the playback queue to drain before enabling
                // voice processing. This prevents audio truncation when STOP arrives
                // late due to network jitter. Instead of blocking the main loop here,
                // defer the start until MAIN_EVENT_PLAYBACK_DRAINED arrives.
                if (listening_mode_ == kListeningModeAutoStop && !audio_service_.IsPlaybackIdle()) {
                    pending_listening_start_ = true;
                } else {
                    StartListeningAudio();
                }
            } else {
                ConfigureWakeWordForListening();
            }
            break;
        case kDeviceStateSpeaking:
            display->SetStatus(Lang::Strings::SPEAKING);

            if (listening_mode_ != kListeningModeRealtime) {
                audio_service_.EnableVoiceProcessing(false);
                // Only AFE wake word can be detected in speaking mode
                audio_service_.EnableWakeWordDetection(audio_service_.IsAfeWakeWord());
            }
            audio_service_.ResetDecoder();
            break;
        case kDeviceStateNotifying:
            display->SetStatus(Lang::Strings::SPEAKING);
            audio_service_.EnableVoiceProcessing(false);
            audio_service_.EnableWakeWordDetection(audio_service_.IsAfeWakeWord());
            break;
        case kDeviceStateWifiConfiguring:
            audio_service_.EnableVoiceProcessing(false);
            audio_service_.EnableWakeWordDetection(false);
            break;
        default:
            // Do nothing
            break;
    }
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
    if (TaijiWebRadio::IsAnyRadioActive()) {
        if (new_state == kDeviceStateConnecting || new_state == kDeviceStateListening ||
            new_state == kDeviceStateSpeaking) {
            TaijiWebRadio::SetAssistantDuck(true);
            radio_voice_processing_grace_ = true;
            radio_voice_session_seen_ = true;
            if (radio_voice_grace_timer_ != nullptr) esp_timer_stop(radio_voice_grace_timer_);
        } else if (new_state == kDeviceStateIdle && radio_voice_processing_grace_) {
            if (radio_voice_grace_timer_ != nullptr) {
                esp_timer_stop(radio_voice_grace_timer_);
                esp_timer_start_once(radio_voice_grace_timer_, 3 * 1000 * 1000);
            }
        }
    }
#endif
}

void Application::StartListeningAudio() {
    // Runs in the main loop, either directly from HandleStateChangedEvent or
    // deferred via MAIN_EVENT_PLAYBACK_DRAINED once the playback queue drains.
    if (GetDeviceState() != kDeviceStateListening) {
        ESP_LOGW(TAG, "StartListeningAudio skipped: state is %d", (int)GetDeviceState());
        return;
    }

    ESP_LOGI(TAG, "Starting microphone capture, listening mode=%s",
             listening_mode_ == kListeningModeRealtime ? "realtime" :
             (listening_mode_ == kListeningModeAutoStop ? "auto_stop" : "manual_stop"));
    // Send the start listening command
    protocol_->SendStartListening(listening_mode_);
    audio_service_.EnableVoiceProcessing(true);

    ConfigureWakeWordForListening();

    // Play popup sound after ResetDecoder (in EnableVoiceProcessing) has been called
    if (play_popup_on_listening_) {
        play_popup_on_listening_ = false;
        audio_service_.PlaySound(Lang::Sounds::OGG_POPUP);
    }
}

void Application::ConfigureWakeWordForListening() {
#ifdef CONFIG_WAKE_WORD_DETECTION_IN_LISTENING
    // Enable wake word detection in listening mode (configured via Kconfig)
    audio_service_.EnableWakeWordDetection(audio_service_.IsAfeWakeWord());
#else
    // Disable wake word detection in listening mode
    audio_service_.EnableWakeWordDetection(false);
#endif
}

void Application::StartNotification(std::string audio_url, std::vector<NotifySubtitle> subtitles) {
    if (GetDeviceState() != kDeviceStateIdle || notify_player_.IsBusy()) {
        ESP_LOGW(TAG, "Ignoring notify message while device is busy");
        return;
    }

    auto& board = Board::GetInstance();
    board.SetPowerSaveLevel(PowerSaveLevel::PERFORMANCE);
    audio_service_.EnableVoiceProcessing(false);
    audio_service_.EnableWakeWordDetection(audio_service_.IsAfeWakeWord());
    audio_service_.ReleaseWakeWordResources();
    while (audio_service_.PopPacketFromSendQueue()) {
        // Discard microphone audio left over from a previous conversation.
    }

    if (!SetDeviceState(kDeviceStateNotifying)) {
        board.SetPowerSaveLevel(PowerSaveLevel::LOW_POWER);
        return;
    }

    audio_service_.ResetDecoder();
    uint32_t playback_id = ++notification_playback_id_;
    if (playback_id == 0) {
        playback_id = ++notification_playback_id_;
    }
    audio_service_.PlaySound(Lang::Sounds::OGG_POPUP);

    bool started = notify_player_.Start(
        std::move(audio_url), std::move(subtitles), playback_id,
        [this](uint32_t id, const std::string& text) {
            Schedule([this, id, text]() {
                if (GetDeviceState() == kDeviceStateNotifying && notification_playback_id_ == id) {
                    Board::GetInstance().GetDisplay()->SetChatMessage("assistant", text.c_str());
                }
            });
        },
        [this](uint32_t id, bool success) {
            Schedule([this, id, success]() { HandleNotificationFinished(id, success); });
        });

    if (!started) {
        ESP_LOGE(TAG, "Failed to start notification playback");
        StopNotification();
    }
}

void Application::StopNotification() {
    notify_player_.Stop();
    audio_service_.ResetDecoder();
    auto& board = Board::GetInstance();
    board.GetDisplay()->SetChatMessage("assistant", "");
    board.SetPowerSaveLevel(PowerSaveLevel::LOW_POWER);
    if (GetDeviceState() == kDeviceStateNotifying) {
        SetDeviceState(kDeviceStateIdle);
    }
}

void Application::HandleNotificationFinished(uint32_t playback_id, bool success) {
    if (GetDeviceState() != kDeviceStateNotifying || notification_playback_id_ != playback_id) {
        return;
    }
    ESP_LOGI(TAG, "Notification playback %lu %s", static_cast<unsigned long>(playback_id),
             success ? "completed" : "failed");
    StopNotification();
}

void Application::Schedule(std::function<void()>&& callback) {
    {
        std::lock_guard<std::mutex> lock(mutex_);
        main_tasks_.push_back(std::move(callback));
    }
    xEventGroupSetBits(event_group_, MAIN_EVENT_SCHEDULE);
}

void Application::AbortSpeaking(AbortReason reason) {
    ESP_LOGI(TAG, "Abort speaking");
    aborted_ = true;
    if (protocol_) {
        protocol_->SendAbortSpeaking(reason);
    }
}

void Application::SetListeningMode(ListeningMode mode) {
    listening_mode_ = mode;
    SetDeviceState(kDeviceStateListening);
}

ListeningMode Application::GetDefaultListeningMode() const {
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
    // During radio voice control, keep the conversation in realtime mode.
    // AutoStop is unsuitable here: after the assistant's greeting it can return
    // straight to Idle, leaving the user with no listening window for the command.
    if (TaijiWebRadio::IsAnyRadioActive() && radio_voice_processing_grace_) {
        ESP_LOGI(TAG, "Radio voice session: selecting REALTIME listening mode");
        return kListeningModeRealtime;
    }
#endif
    return aec_mode_ == kAecOff ? kListeningModeAutoStop : kListeningModeRealtime;
}

void Application::Reboot() {
    ESP_LOGI(TAG, "Rebooting...");
    if (GetDeviceState() == kDeviceStateNotifying) {
        StopNotification();
    }
    // Disconnect the audio channel
    if (protocol_ && protocol_->IsAudioChannelOpened()) {
        protocol_->CloseAudioChannel();
    }
    protocol_.reset();
    audio_service_.Stop();

    vTaskDelay(pdMS_TO_TICKS(1000));
    esp_restart();
}

bool Application::UpgradeFirmware(const std::string& url, const std::string& version) {
    auto& board = Board::GetInstance();
    auto display = board.GetDisplay();

    std::string upgrade_url = url;
    std::string version_info = version.empty() ? "(Manual upgrade)" : version;

    if (GetDeviceState() == kDeviceStateNotifying) {
        StopNotification();
    }

    // Close audio channel if it's open
    if (protocol_ && protocol_->IsAudioChannelOpened()) {
        ESP_LOGI(TAG, "Closing audio channel before firmware upgrade");
        protocol_->CloseAudioChannel();
    }
    ESP_LOGI(TAG, "Starting firmware upgrade from URL: %s", upgrade_url.c_str());

    Alert(Lang::Strings::OTA_UPGRADE, Lang::Strings::UPGRADING, "download",
          Lang::Sounds::OGG_UPGRADE);
    vTaskDelay(pdMS_TO_TICKS(3000));

    SetDeviceState(kDeviceStateUpgrading);

    std::string message = std::string(Lang::Strings::NEW_VERSION) + version_info;
    display->SetChatMessage("system", message.c_str());

    board.SetPowerSaveLevel(PowerSaveLevel::PERFORMANCE);
    audio_service_.Stop();
    vTaskDelay(pdMS_TO_TICKS(1000));

    bool upgrade_success = Ota::Upgrade(upgrade_url, [this, display](int progress, size_t speed) {
        char buffer[32];
        snprintf(buffer, sizeof(buffer), "%d%% %uKB/s", progress, speed / 1024);
        Schedule([display, message = std::string(buffer)]() {
            display->SetChatMessage("system", message.c_str());
        });
    });

    if (!upgrade_success) {
        // Upgrade failed, restart audio service and continue running
        ESP_LOGE(TAG,
                 "Firmware upgrade failed, restarting audio service and continuing operation...");
        audio_service_.Start();                              // Restart audio service
        board.SetPowerSaveLevel(PowerSaveLevel::LOW_POWER);  // Restore power save level
        Alert(Lang::Strings::ERROR, Lang::Strings::UPGRADE_FAILED, "cancel",
              Lang::Sounds::OGG_EXCLAMATION);
        vTaskDelay(pdMS_TO_TICKS(3000));
        return false;
    } else {
        // Upgrade success, reboot immediately
        ESP_LOGI(TAG, "Firmware upgrade successful, rebooting...");
        display->SetChatMessage("system", "Upgrade successful, rebooting...");
        vTaskDelay(pdMS_TO_TICKS(1000));  // Brief pause to show message
        Reboot();
        return true;
    }
}

void Application::WakeWordInvoke(const std::string& wake_word) {
    if (!protocol_) {
        return;
    }

    auto state = GetDeviceState();

    if (state == kDeviceStateIdle) {
        // May be called from outside the main task (e.g. board button
        // callbacks), so schedule the invocation instead of running it here
        Schedule([this, wake_word]() {
            if (GetDeviceState() == kDeviceStateIdle) {
                BeginWakeWordInvoke(wake_word);
            }
        });
    } else if (state == kDeviceStateNotifying) {
        Schedule([this, wake_word]() {
            if (GetDeviceState() == kDeviceStateNotifying) {
                StopNotification();
                BeginWakeWordInvoke(wake_word);
            }
        });
    } else if (state == kDeviceStateSpeaking) {
        Schedule([this]() { AbortSpeaking(kAbortReasonNone); });
    } else if (state == kDeviceStateListening) {
        Schedule([this]() {
            if (protocol_) {
                protocol_->CloseAudioChannel();
            }
        });
    }
}

// <ttuner83> Schedule a single in-RAM reminder without changing the normal sleep policy.
bool Application::SetVoiceReminder(int minutes, const std::string& message) {
    if (minutes < 1 || minutes > 1440 || message.empty() || voice_reminder_timer_ == nullptr) return false;
    {
        std::lock_guard<std::mutex> lock(reminder_mutex_);
        voice_reminder_text_ = message;
    }
    esp_timer_stop(voice_reminder_timer_);
    const esp_err_t err = esp_timer_start_once(voice_reminder_timer_, static_cast<uint64_t>(minutes) * 60ULL * 1000000ULL);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Cannot start voice reminder: %s", esp_err_to_name(err));
        return false;
    }
    ESP_LOGI(TAG, "One-shot voice reminder set for %d minutes", minutes);
    return true;
}

void Application::VoiceReminderTimerCallback(void* arg) {
    auto* app = static_cast<Application*>(arg);
    if (app) app->Schedule([app]() { app->FireVoiceReminder(); });
}

void Application::FireVoiceReminder() {
    std::string reminder;
    {
        std::lock_guard<std::mutex> lock(reminder_mutex_);
        reminder.swap(voice_reminder_text_); // one-shot: consume before delivery
    }
    if (reminder.empty()) return;

    auto& board = Board::GetInstance();
    // The reminder callback may run while the display is off and Wi-Fi is in
    // maximum modem sleep. Restore full performance and restart the idle
    // countdown before asking the assistant to speak. Keep an awake grace
    // period in case the server needs several seconds to start its TTS stream.
    const int64_t now_us = esp_timer_get_time();
    reminder_awake_until_us_ = now_us + 30LL * 1000000LL;
    idle_since_us_ = now_us;
    if (idle_display_off_) {
        idle_display_off_ = false;
        auto display = board.GetDisplay();
        if (display) display->SetPowerSaveMode(false);
        if (auto backlight = board.GetBacklight()) backlight->RestoreBrightness();
    }
    board.SetPowerSaveLevel(PowerSaveLevel::PERFORMANCE);
    const esp_err_t wifi_err = esp_wifi_set_ps(WIFI_PS_NONE);
    if (wifi_err != ESP_OK) {
        ESP_LOGW(TAG, "Reminder: could not restore Wi-Fi performance mode: %s", esp_err_to_name(wifi_err));
    }
    ESP_LOGI(TAG, "Reminder fired: display and Wi-Fi restored; sleep held for 30 seconds");

    // Reuse the short built-in success chime heard when Xiaozhi finishes
    // startup. Four copies take about 4.1 seconds in total.
    constexpr int kReminderSoundCopies = 4;
    constexpr int64_t kSuccessSoundDurationUs = 1026500;
    constexpr int64_t kReminderPlaybackDurationUs = kSuccessSoundDurationUs * kReminderSoundCopies;
    // Alternate normal/inverted LCD colors for a visible blinking effect.
    constexpr int64_t kFlashPeriodUs = 200000;

    auto codec = board.GetAudioCodec();
    if (codec != nullptr) {
        reminder_previous_volume_ = codec->output_volume();
        const int reminder_volume = std::min(100, (reminder_previous_volume_ * 130 + 50) / 100);
        codec->SetOutputVolume(reminder_volume);
        ESP_LOGI(TAG, "Reminder sound volume: %d -> %d (+30%%)", reminder_previous_volume_, reminder_volume);

        if (reminder_volume_restore_timer_ == nullptr) {
            const esp_timer_create_args_t timer_args = {
                .callback = &Application::ReminderVolumeRestoreCallback,
                .arg = this,
                .dispatch_method = ESP_TIMER_TASK,
                .name = "reminder_vol_restore",
                .skip_unhandled_events = true,
            };
            if (esp_timer_create(&timer_args, &reminder_volume_restore_timer_) != ESP_OK) {
                reminder_volume_restore_timer_ = nullptr;
            }
        }
    }

    // Blink the whole display by alternating the LCD hardware color inversion
    // state while the reminder chime plays. The normal panel state is true.
    auto display = board.GetDisplay();
    reminder_flash_ticks_ = 0;
    reminder_flash_inverted_ = true;
    if (display != nullptr) {
        if (reminder_flash_timer_ == nullptr) {
            const esp_timer_create_args_t flash_args = {
                .callback = &Application::ReminderFlashTimerCallback,
                .arg = this,
                .dispatch_method = ESP_TIMER_TASK,
                .name = "reminder_flash",
                .skip_unhandled_events = true,
            };
            if (esp_timer_create(&flash_args, &reminder_flash_timer_) != ESP_OK) {
                reminder_flash_timer_ = nullptr;
            }
        }
        if (reminder_flash_timer_ != nullptr) {
            esp_timer_stop(reminder_flash_timer_);
            esp_timer_start_periodic(reminder_flash_timer_, kFlashPeriodUs);
        }
    }

    for (int i = 0; i < kReminderSoundCopies; ++i) {
        audio_service_.PlaySound(Lang::Sounds::OGG_SUCCESS);
    }
    if (reminder_volume_restore_timer_ != nullptr) {
        esp_timer_stop(reminder_volume_restore_timer_);
        esp_timer_start_once(reminder_volume_restore_timer_, kReminderPlaybackDurationUs + 500000);
    } else if (codec != nullptr && reminder_previous_volume_ >= 0) {
        codec->SetOutputVolume(reminder_previous_volume_);
        reminder_previous_volume_ = -1;
    }

    Alert("Напоминание", reminder.c_str(), "neutral");
    ESP_LOGI(TAG, "Reminder fired; queued four success chimes with display blinking");
}

void Application::ReminderFlashTimerCallback(void* arg) {
    auto* app = static_cast<Application*>(arg);
    if (app == nullptr) return;

    auto display = Board::GetInstance().GetDisplay();
    if (display != nullptr) {
        app->reminder_flash_inverted_ = !app->reminder_flash_inverted_;
        display->SetColorInverted(app->reminder_flash_inverted_);
    }

    // Four success chimes are approximately 4.1 seconds total. Restore the
    // normal panel mode at the end; never leave the display flashing.
    if (++app->reminder_flash_ticks_ >= 23) {
        if (app->reminder_flash_timer_ != nullptr) {
            esp_timer_stop(app->reminder_flash_timer_);
        }
        if (display != nullptr) {
            // Taiji ST77916 starts in its normal (non-inverted) panel mode.
            display->SetColorInverted(false);
        }
        app->reminder_flash_inverted_ = false;
        app->reminder_flash_ticks_ = 0;
    }
}

void Application::ReminderVolumeRestoreCallback(void* arg) {
    auto* app = static_cast<Application*>(arg);
    if (app == nullptr || app->reminder_previous_volume_ < 0) return;
    auto codec = Board::GetInstance().GetAudioCodec();
    if (codec != nullptr) {
        codec->SetOutputVolume(app->reminder_previous_volume_);
        ESP_LOGI(TAG, "Reminder volume restored to %d", app->reminder_previous_volume_);
    }
    app->reminder_previous_volume_ = -1;
}

bool Application::CanEnterSleepMode() {
    // A reminder is a foreground event even though the device state is IDLE
    // until the server starts speaking. Do not let the idle power-save path
    // switch the display/Wi-Fi off during that hand-off.
    if (reminder_awake_until_us_ > 0) {
        if (esp_timer_get_time() < reminder_awake_until_us_) {
            return false;
        }
        reminder_awake_until_us_ = 0;
        idle_since_us_ = esp_timer_get_time();
        ESP_LOGI(TAG, "Reminder awake grace period ended; normal idle sleep resumed");
    }
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3 || CONFIG_BOARD_TYPE_ZHENGCHEN_1_54TFT_WIFI
    // Music/radio playback must not be interrupted by the generic sleep timer.
    // IsAnyRadioActive also covers the visible music-player session between tracks.
    if (TaijiWebRadio::IsAnyRadioActive()) {
        return false;
    }
#endif
    if (GetDeviceState() != kDeviceStateIdle) {
        return false;
    }

    if (protocol_ && protocol_->IsAudioChannelOpened()) {
        return false;
    }

    if (!audio_service_.IsIdle()) {
        return false;
    }

    // Now it is safe to enter sleep mode
    return true;
}

void Application::RegisterMcpBroadcastCallback(std::function<void(const std::string&)> callback) {
    mcp_broadcast_callback_ = std::move(callback);
}

void Application::SendMcpMessage(const std::string& payload) {
    // Always schedule to run in main task for thread safety
    Schedule([this, payload]() {
        if (protocol_) {
            protocol_->SendMcpMessage(payload);
        }
        if (mcp_broadcast_callback_) {
            mcp_broadcast_callback_(payload);
        }
    });
}

void Application::SetAecMode(AecMode mode) {
    aec_mode_ = mode;
    Schedule([this]() {
        auto& board = Board::GetInstance();
        auto display = board.GetDisplay();
        switch (aec_mode_) {
            case kAecOff:
                audio_service_.EnableDeviceAec(false);
                display->ShowNotification(Lang::Strings::RTC_MODE_OFF);
                break;
            case kAecOnServerSide:
                audio_service_.EnableDeviceAec(false);
                display->ShowNotification(Lang::Strings::RTC_MODE_ON);
                break;
            case kAecOnDeviceSide:
                audio_service_.EnableDeviceAec(true);
                display->ShowNotification(Lang::Strings::RTC_MODE_ON);
                break;
        }

        // If the AEC mode is changed, close the audio channel
        if (protocol_ && protocol_->IsAudioChannelOpened()) {
            protocol_->CloseAudioChannel();
        }
    });
}

void Application::PlaySound(const std::string_view& sound) { audio_service_.PlaySound(sound); }

void Application::ResetProtocol() {
    Schedule([this]() {
        if (GetDeviceState() == kDeviceStateNotifying) {
            StopNotification();
        }
        // Close audio channel if opened
        if (protocol_ && protocol_->IsAudioChannelOpened()) {
            protocol_->CloseAudioChannel();
        }
        // Reset protocol
        protocol_.reset();
    });
}

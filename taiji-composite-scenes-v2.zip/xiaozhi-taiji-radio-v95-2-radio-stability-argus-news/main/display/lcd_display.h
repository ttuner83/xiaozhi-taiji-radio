#ifndef LCD_DISPLAY_H
#define LCD_DISPLAY_H

#include "cozmo_eyes.h"
#include "gif/lvgl_gif.h"
#include "lvgl_display.h"

#include <esp_lcd_panel_io.h>
#include <esp_lcd_panel_ops.h>
#include <atomic>
#include <memory>
#include <string>
#include <vector>

#define PREVIEW_IMAGE_DURATION_MS 5000

class LcdDisplay : public LvglDisplay {
protected:
    esp_lcd_panel_io_handle_t panel_io_ = nullptr;
    esp_lcd_panel_handle_t panel_ = nullptr;

    lv_draw_buf_t draw_buf_;
    lv_obj_t* top_bar_ = nullptr;
    lv_obj_t* status_bar_ = nullptr;
    lv_obj_t* content_ = nullptr;
    lv_obj_t* container_ = nullptr;
    lv_obj_t* side_bar_ = nullptr;
    lv_obj_t* bottom_bar_ = nullptr;
    lv_obj_t* preview_image_ = nullptr;
    lv_obj_t* emoji_label_ = nullptr;
    lv_obj_t* emoji_image_ = nullptr;
    std::unique_ptr<LvglGif> gif_controller_ = nullptr;
    lv_obj_t* emoji_box_ = nullptr;
    lv_obj_t* chat_message_label_ = nullptr;
    esp_timer_handle_t preview_timer_ = nullptr;
    std::unique_ptr<LvglImage> preview_image_cached_ = nullptr;
    bool hide_subtitle_ = false;  // Control whether to hide chat messages/subtitles

    std::unique_ptr<CozmoEyes> cozmo_eyes_ = nullptr;
    lv_obj_t* eyes_image_ = nullptr;
    lv_image_dsc_t eyes_dsc_{};
    lv_timer_t* eyes_timer_ = nullptr;
    lv_obj_t* generated_scene_layer_ = nullptr;
    lv_timer_t* generated_scene_timer_ = nullptr;
    uint32_t generated_scene_started_ = 0;
    bool generated_scene_finish_requested_ = false;
    struct GeneratedSceneNode {
        lv_obj_t* object = nullptr;
        int base_x = 0;
        int base_y = 0;
        int amplitude = 0;
        uint32_t period_ms = 1200;
        bool horizontal = false;
    };
    std::vector<GeneratedSceneNode> generated_scene_nodes_;
    void UpdateGeneratedScene();
    void ClearGeneratedScene();
    bool radio_low_motion_mode_ = false;
    bool gif_was_playing_before_radio_ = false;
    lv_anim_t* paused_chat_animation_ = nullptr;

    void InitializeLcdThemes();
    void SetupEyes();
    void UpdateEyes();
    virtual bool Lock(int timeout_ms = 0) override;
    virtual void Unlock() override;

protected:
    // Add protected constructor
    LcdDisplay(esp_lcd_panel_io_handle_t panel_io, esp_lcd_panel_handle_t panel, int width,
               int height);

public:
    ~LcdDisplay();
    virtual void SetColorInverted(bool inverted) override;
    virtual void SetEmotion(const char* emotion) override;
    virtual void ShowGeneratedScene(const char* scene_json) override;
    virtual void FinishGeneratedScene() override;
    virtual void SetChatMessage(const char* role, const char* content) override;
    virtual void ClearChatMessages() override;
    virtual void SetPreviewImage(std::unique_ptr<LvglImage> image) override;
    virtual void SetupUI() override;
    // Add theme switching function
    virtual void SetTheme(Theme* theme) override;

    // Set whether to hide chat messages/subtitles
    virtual void SetHideSubtitle(bool hide) override;
    virtual void SetRadioLowMotionMode(bool enabled) override;
};

// SPI LCD display
class SpiLcdDisplay : public LcdDisplay {
public:
    SpiLcdDisplay(esp_lcd_panel_io_handle_t panel_io, esp_lcd_panel_handle_t panel, int width,
                  int height, int offset_x, int offset_y, bool mirror_x, bool mirror_y,
                  bool swap_xy);
};

// RGB LCD display
class RgbLcdDisplay : public LcdDisplay {
public:
    RgbLcdDisplay(esp_lcd_panel_io_handle_t panel_io, esp_lcd_panel_handle_t panel, int width,
                  int height, int offset_x, int offset_y, bool mirror_x, bool mirror_y,
                  bool swap_xy);
};

// MIPI LCD display
class MipiLcdDisplay : public LcdDisplay {
public:
    MipiLcdDisplay(esp_lcd_panel_io_handle_t panel_io, esp_lcd_panel_handle_t panel, int width,
                   int height, int offset_x, int offset_y, bool mirror_x, bool mirror_y,
                   bool swap_xy);
};

#endif  // LCD_DISPLAY_H

V95.13 corrective patch

Changes based on v95-10 source:
- Wikipedia HTTP client now attaches the ESP-IDF certificate bundle (`esp_crt_bundle_attach`) so HTTPS performs server verification instead of failing during TLS setup.
- The web settings card is valid HTML and is outside the JavaScript block. It contains the idle timeout in seconds, three RSS URL fields, and the drone-parser URL field. `/api/config` GET/POST stores the values persistently in the existing radio settings namespace.
- After the configured idle timeout (default 15 seconds), while the device remains idle and radio is not playing, the display backlight is turned off, the board enters LOW_POWER and Wi-Fi is asked to use MAX_MODEM. On the next non-idle device-state transition, brightness and display are restored and Wi-Fi performance is restored before the normal power-save policy is recalculated.

The three RSS URLs are consumed by the existing news MCP tool; when all three are empty, its built-in RIA/Lenta defaults remain in use. The drone-parser URL is consumed by the existing Argus query; when empty, the built-in Argus endpoint remains in use.

#ifndef TAIJI_WEB_RADIO_H
#define TAIJI_WEB_RADIO_H

#include <string>
#include <atomic>
#include <esp_timer.h>
#include <vector>
#include "lvgl.h"

#include "esp_http_server.h"
#include "features/music/esp32_radio.h"
#include <memory>
class Esp32Music;

class TaijiWebRadio {
public:
    TaijiWebRadio();
    ~TaijiWebRadio();

    void Start();
    void Stop();

    bool PlaySelected();
    // Enter radio playback from a swipe without starting an assistant session.
    void EnterSilentRadioModeNow();
    bool PlayStation(int station_number);
    // Match a spoken station name against the live web-interface station list.
    bool PlayStationByName(const std::string& spoken_name);
    bool NextStation();
    bool StopPlayback();

    // Synchronize Wi-Fi power-save mode with radio/voice-assistant activity.
    static void UpdateWifiPowerSave();
    static int GetIdleTimeoutSeconds();
    // Safe status query for Application, which cannot access board-specific methods on Board.
    static bool IsAnyRadioActive();
    // Stop the active Internet radio from a locally recognized voice command.
    static bool StopActiveRadioFromVoice();
    static void SetAssistantDuck(bool enabled);
    static bool IsAssistantDuckActive();

    bool IsRadioActive() const { return radio_.IsPlaying() || radio_.IsDownloading(); }
    // Manual CST816S touch handling (the board polls touch outside LVGL).
    void HandleTouchDown(int x, int y);
    bool HandleTouchTap(int x, int y);
    bool IsRadioUiVisible() const { return radio_ui_visible_; }
    void SetPageIndicator(int page);

private:
    struct Station {
        std::string name;
        std::string url;
        std::string type;
    };

    httpd_handle_t server_ = nullptr;
    std::vector<Station> stations_;
    Esp32Radio radio_;
    std::unique_ptr<Esp32Music> music_player_;
    int current_slot_ = -1;
    int64_t last_radio_action_us_ = 0;

    void LoadStations();
    void SaveStation(int slot, const Station& station);
    void ClearStation(int slot);

    static esp_err_t RootHandler(httpd_req_t* req);
    static esp_err_t StationsGetHandler(httpd_req_t* req);
    static esp_err_t StationsPostHandler(httpd_req_t* req);
    static esp_err_t PlayHandler(httpd_req_t* req);
    static esp_err_t StopHandler(httpd_req_t* req);
    static esp_err_t ConfigGetHandler(httpd_req_t* req);
    static esp_err_t ConfigPostHandler(httpd_req_t* req);

    esp_err_t HandleRoot(httpd_req_t* req);
    esp_err_t HandleStationsGet(httpd_req_t* req);
    esp_err_t HandleStationsPost(httpd_req_t* req);
    esp_err_t HandlePlay(httpd_req_t* req);
    esp_err_t HandleStop(httpd_req_t* req);
    esp_err_t HandleConfigGet(httpd_req_t* req);
    esp_err_t HandleConfigPost(httpd_req_t* req);

    void StartRadio(int slot);
    void StartRadioNow(int slot);
    static void StationSwitchTask(void* arg);
    std::atomic<int> pending_station_slot_{-1};
    std::atomic<bool> station_switch_task_running_{false};
    bool StopRadio();
    void EnsureRadioUi();
    void ShowRadioUi(bool show);
    void UpdateRadioStationLabel();
    static void RadioUiEvent(lv_event_t* event);
    lv_obj_t* page_indicator_root_ = nullptr;
    lv_obj_t* page_indicator_active_ = nullptr;
    lv_obj_t* radio_ui_root_ = nullptr;
    lv_obj_t* radio_station_label_ = nullptr;
    lv_obj_t* radio_volume_label_ = nullptr;
    // 1=previous, 2=power, 3=next, 4=volume up, 5=volume down.
    lv_obj_t* radio_buttons_[5] = {nullptr, nullptr, nullptr, nullptr, nullptr};
    lv_timer_t* radio_button_flash_timer_ = nullptr;
    bool radio_ui_visible_ = false;
    static void RadioButtonFlashTimerCallback(lv_timer_t* timer);
    void FlashRadioButton(int action);

    void StartSilentStandbyTimer();
    void CancelSilentStandbyTimer();
    static void SilentStandbyTimerCallback(void* arg);
    esp_timer_handle_t silent_standby_timer_ = nullptr;

    static TaijiWebRadio* instance_;
};


#endif

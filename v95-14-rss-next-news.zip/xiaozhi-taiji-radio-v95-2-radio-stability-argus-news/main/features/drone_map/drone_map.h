#pragma once
class ArgusVoiceQuery {
public:
    ArgusVoiceQuery();
    ~ArgusVoiceQuery();
private:
    void RegisterTool();
};

# Wikipedia reference tool — v95.12

Added MCP tool `self.wikipedia.search` for the Taiji Pi S3 board. It searches Russian Wikipedia through MediaWiki API (`list=search`), then requests the first article's plain-text introduction (`prop=extracts`, `exintro`, `explaintext`). The returned summary is passed back through the existing MCP result path for assistant speech.

Network replies are bounded to 12 KB and HTTP timeout is 9 seconds to limit memory use and blocking. This implementation was source-reviewed but not compiled or run on hardware in this environment.

Example: ask “Что такое фотосинтез?” or “Найди в Википедии историю радио”. The assistant should invoke `self.wikipedia.search` with the topic.

# v108 — rapid radio switching and minimal music player UI (based on v107)

- Physical station changes remain asynchronous. During shutdown of the old HTTP/audio stream, button presses overwrite the pending station request; after shutdown the switch worker re-reads the latest request and starts only that station.
- Reworked the 240x240 music-player screen: plain black background, cyan metadata/status/playlist, white current song in the upper third, compact list of up to five playlist entries, and minimal controls.
- Remaining playback time is not displayed because the current MP3 player interface does not expose a reliable duration/position value.
- Source archive only; ESP-IDF build and device validation have not been performed.

# v95-33 — music search and UI cleanup

Based on v95-32-idle-audio-sleep-guard.zip. Existing idle-audio sleep guard is preserved.

Changes:
- Allow artist-only requests (for example, “play any song by Nirvana”); when no title is provided, Meting results are selected by the requested artist.
- Search up to eight matching candidates and prefer a known file at least 1 MiB. If all reachable candidates are known to be under 1 MiB, do not start playback automatically; preserve the best short candidate for explicit user confirmation.
- Retry a Meting search once only when the API returns no response; valid empty results are not retried.
- Strengthen the music tool instructions: call the tool for every music request, wait for slow results, do not narrate search progress, stay silent on success, and say only “Нет такой” on ordinary failure.
- Clear stale pending-short-track state when stopping the player before a new search.
- Make radio and music UI visibility mutually exclusive and invalidate the active LVGL screen after visibility changes to reduce stale/overlapping pixels.

Validation: source-level checks and ZIP integrity only. ESP-IDF build and device playback/UI tests have not been run.

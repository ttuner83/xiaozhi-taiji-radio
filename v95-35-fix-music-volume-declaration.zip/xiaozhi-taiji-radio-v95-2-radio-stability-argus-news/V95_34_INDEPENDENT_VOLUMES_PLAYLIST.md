# v95-34 — independent volumes and sequential music playlist

Changes on top of v95-33:
- Added persistent software music-player volume, independent of the radio's own volume control.
- Added web UI fields for base and current assistant, radio, and music-player volumes. Current values are applied and persisted.
- Added MCP tools `self.music.set_volume`, `self.music.get_volume`, and `self.music.play_playlist`.
- Playlist tool accepts a JSON string array of `{song, artist}` objects. It searches/starts the first track, waits for natural playback completion, and only then searches the next item. Failed or known-short items are skipped while continuing the queue.
- Manual music search, explicit stop, or wake-word interruption cancels the playlist.
- Player-screen volume controls now adjust music volume rather than assistant volume.

Archive integrity was checked. No ESP-IDF build or device test was run in this environment.

Radio buffer changes
====================

- The stream/file audio queue now uses one contiguous 256 KiB PSRAM pool split into 64 reusable 4096-byte blocks.
- HTTP and SD readers copy incoming bytes into a free pool block instead of allocating/freeing a separate PSRAM chunk for every read.
- Playback returns blocks to the pool after copying their contents into the decoder input buffer.
- The pool is retained while changing stations/tracks and released when Stop is explicitly requested (or when the player is destroyed).
- Startup prebuffer remains 128 KiB. The decoder output scratch buffer now starts at 8192 bytes and grows only if the codec reports a larger required frame.
- The queue of block descriptors and PCM processing vectors still use the C++ standard library; this change specifically removes repeated large PSRAM allocations for stream chunks.

The source archive was checked structurally, but this environment does not have the project's ESP-IDF 6.0.2 build toolchain. Run the existing GitHub Actions workflow to verify compilation on the target toolchain.

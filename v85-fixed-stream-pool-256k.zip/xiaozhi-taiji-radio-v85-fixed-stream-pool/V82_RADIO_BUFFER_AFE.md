# v82 radio buffer and AFE changes

- Radio stream queue maximum increased to 256 KiB (PSRAM).
- Radio startup prebuffer increased to 128 KiB (PSRAM).
- When radio starts, application enters radio-silent idle immediately: voice processing and WakeNet/AFE are disabled so the microphone feed no longer fills the AFE ringbuffer in the background.
- Tapping the assistant area clears radio-silent mode so the assistant can be used while radio continues. If the assistant returns to idle while radio is still active, AFE/WakeNet are suppressed again.
- Stopping radio exits radio-silent mode and restores wake-word detection when the application is idle.
- Existing low-motion mode pauses hidden eye updates, GIF emotion animation, and scrolling assistant subtitle while the radio UI is visible.

The ZIP was checked for archive integrity and source-level consistency. A full ESP-IDF compile and on-device playback test have not been run here.

# v74 workflow fix

The GitHub Actions error `python: can't open file .../scripts/build.py: [Errno 2]` happens before compilation: the workflow is checking out a repository that does not have the source tree at its root. This patch makes `.github/workflows/build.yml` and its prepare/build jobs extract the project source ZIP when `scripts/build.py` is absent, then verify that `scripts/build.py` exists before continuing.

If the repository contains only a ZIP, keep that ZIP at the repository root. The workflow definition itself must already be committed under `.github/workflows/build.yml`; GitHub cannot execute a workflow that exists only inside a ZIP that has not been extracted/committed.

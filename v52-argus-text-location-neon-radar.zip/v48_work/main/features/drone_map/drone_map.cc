#include "drone_map.h"

#include "application.h"
#include "board.h"
#include "display/display.h"
#include "mcp_server.h"

#include <cJSON.h>
#include <esp_crt_bundle.h>
#include <esp_http_client.h>
#include <esp_heap_caps.h>
#include <esp_log.h>

#include <algorithm>
#include <array>
#include <cstring>
#include <cctype>
#include <string>
#include <ctime>
#include <vector>
#include <utility>
#include <cmath>

#include "generated_tiles.h"

#define TAG "DroneMap"

namespace {
constexpr const char* kArgusUrl = "https://argusmap.online/api/live";
constexpr int kSwipeThreshold = 70;
constexpr uint32_t kPollIntervalMs = 60000;
constexpr size_t kMaxResponseBytes = 256 * 1024;

struct MapPoint { const char* name; int x; int y; };
// Pixel anchors for map333.png (360x360). Points not labelled on the image are approximate.
constexpr MapPoint kMapPoints[] = {
    {"Армянск",72,111}, {"Красноперекопск",91,137}, {"Джанкой",151,148},
    {"Раздольное",48,155}, {"Раздольном",48,155}, {"Стерегущее",31,151}, {"Стерегущем",31,151},
    {"Гвардейское",116,207}, {"Гвардейском",116,207}, {"Гвардейского",116,207}, {"Гвардейскому",116,207},
    {"Черноморское",22,176}, {"Евпатория",73,201},
    {"Саки",96,207}, {"Симферополь",127,228}, {"Бахчисарай",95,244},
    {"Севастополь",73,262}, {"Ялта",128,278}, {"Алушта",151,265},
    {"Белогорск",178,222}, {"Старый Крым",207,220}, {"Судак",187,246},
    {"Коктебель",215,226}, {"Феодосия",235,210}, {"Чауда",222,246},
    {"Кировское",204,201}, {"Яркое Поле",213,198}, {"Ярком Поле",213,198}, {"Яркого Поля",213,198}, {"Владиславовка",224,204}, {"Владиславовке",224,204}, {"Владиславовки",224,204}, {"Щёлкино",263,157}, {"Ленино",261,190},
    {"Керчь",294,184}, {"Керченский пролив",319,201}, {"переправ",311,213},
    {"Арабатская стрелка",179,127}, {"Арабатской стрелки",179,127}, {"Сиваш",120,105},
    {"Азовское море",211,80}, {"Азовское море",278,72}, {"Азовское море",337,85},
    {"Тарханкут",20,190}, {"Ленинский район",254,214}, {"Феодосийский залив",247,196},
    {"порт",239,207}, {"Портовое",39,164}, {"Портовом",39,164},
    {"Armyansk",72,111}, {"Krasnoperekopsk",91,137}, {"Dzhankoy",151,148},
    {"Steregushchee",31,151}, {"Portovoe",39,164}, {"Gvardeyskoye",116,207},
    {"Razdolnoe",48,155}, {"Chornomorske",22,176}, {"Yevpatoriya",73,201},
    {"Saki",96,207}, {"Simferopol",127,228}, {"Bakhchisarai",95,244},
    {"Sevastopol",73,262}, {"Yalta",128,278}, {"Alushta",151,265},
    {"Belogorsk",178,222}, {"Stary Krym",207,220}, {"Sudak",187,246},
    {"Koktebel",215,226}, {"Feodosia",235,210}, {"Chauda",222,246},
    {"Kirovsky",204,201}, {"Kirovske",204,201}, {"Shcholkine",263,157},
    {"Lenino",261,190}, {"Kerch",294,184}, {"Kerch Strait",319,201},
    {"ferry",311,213}, {"Arabat Spit",179,127}, {"Sivash",120,105},
    {"Azov Sea",278,72}, {"Tarkhankut",20,190}, {"Leninsky",254,214},
    {"Feodosia port",239,207}, {"port of Feodosia",239,207}
};

struct ResponseBuffer {
    char* data = nullptr;
    size_t size = 0;
    size_t capacity = 0;
    bool overflow = false;
};

esp_err_t HttpEventHandler(esp_http_client_event_t* evt) {
    if (evt && evt->event_id == HTTP_EVENT_ON_DATA && evt->user_data && evt->data && evt->data_len > 0) {
        auto* response = static_cast<ResponseBuffer*>(evt->user_data);
        const size_t len = static_cast<size_t>(evt->data_len);
        if (response->data && response->size + len < response->capacity) {
            memcpy(response->data + response->size, evt->data, len);
            response->size += len;
            response->data[response->size] = '\0';
        } else {
            response->overflow = true;
        }
    }
    return ESP_OK;
}

std::string LowerUtf8(std::string value) {
    std::string out;
    out.reserve(value.size());
    for (size_t i = 0; i < value.size();) {
        const unsigned char c = static_cast<unsigned char>(value[i]);
        if (c < 0x80) {
            out.push_back(static_cast<char>(std::tolower(c)));
            ++i;
        } else if (i + 1 < value.size() && c == 0xD0) {
            const unsigned char d = static_cast<unsigned char>(value[i + 1]);
            if (d >= 0x90 && d <= 0x9F) { out.push_back(static_cast<char>(0xD0)); out.push_back(static_cast<char>(d + 0x20)); }
            else if (d >= 0xA0 && d <= 0xAF) { out.push_back(static_cast<char>(0xD1)); out.push_back(static_cast<char>(d - 0x20)); }
            else if (d == 0x81) { out.push_back(static_cast<char>(0xD1)); out.push_back(static_cast<char>(0x91)); }
            else { out.push_back(value[i]); out.push_back(value[i + 1]); }
            i += 2;
        } else {
            out.push_back(value[i++]);
        }
    }
    return out;
}

bool ContainsNoCase(const std::string& text, const char* phrase) {
    if (!phrase || !*phrase) return false;
    return LowerUtf8(text).find(LowerUtf8(phrase)) != std::string::npos;
}

// Reduce Russian words to a conservative stem so that city names match common
// grammatical cases (e.g. Feodosia/Feodosii, Kerch/Kerchi, Arabatskoy strelki).
// This is intentionally token-based: it does not match arbitrary substrings.
std::string RussianStem(std::string word) {
    static const char* suffixes[] = {
        "иями", "ями", "ами", "иями", "иями", "ского", "цкого", "ному", "нему",
        "ыми", "ими", "ого", "его", "ому", "ему", "ией", "ией", "иях", "иях",
        "иям", "ием", "ией", "ская", "цкая", "ской", "цкой", "ские", "цкие",
        "иями", "ями", "ами", "ией", "ия", "ии", "ие", "ей", "ой", "ый", "ий",
        "ая", "яя", "ое", "ее", "ом", "ем", "ам", "ям", "ах", "ях", "ы", "и",
        "а", "я", "ь", "й", "е", "у", "ю"
    };
    for (const char* suffix : suffixes) {
        const size_t n = strlen(suffix);
        if (word.size() > n + 2 && word.compare(word.size() - n, n, suffix) == 0) {
            word.resize(word.size() - n);
            break;
        }
    }
    return word;
}

struct WordToken { std::string word; size_t pos; };
std::vector<WordToken> TokenizeWords(const std::string& text) {
    std::vector<WordToken> out;
    size_t i = 0;
    while (i < text.size()) {
        const unsigned char c = static_cast<unsigned char>(text[i]);
        const bool word_char = (c >= 128) || std::isalnum(c);
        if (!word_char) { ++i; continue; }
        const size_t start = i;
        while (i < text.size()) {
            const unsigned char d = static_cast<unsigned char>(text[i]);
            if (!(d >= 128 || std::isalnum(d))) break;
            ++i;
        }
        out.push_back({text.substr(start, i - start), start});
    }
    return out;
}

size_t FindLocationPosition(const std::string& lowered_text, const char* raw_name) {
    if (!raw_name || !*raw_name) return std::string::npos;
    const std::string lowered_name = LowerUtf8(raw_name);
    // Latin transliterations are matched as complete phrases, case-insensitively.
    bool has_cyrillic = false;
    for (unsigned char c : lowered_name) if (c >= 0xD0) { has_cyrillic = true; break; }
    if (!has_cyrillic) return lowered_text.find(lowered_name);

    const auto text_words = TokenizeWords(lowered_text);
    const auto name_words = TokenizeWords(lowered_name);
    if (name_words.empty()) return std::string::npos;
    std::vector<std::string> roots;
    roots.reserve(name_words.size());
    for (const auto& word : name_words) roots.push_back(RussianStem(word.word));

    size_t best = std::string::npos;
    for (size_t i = 0; i < text_words.size(); ++i) {
        if (RussianStem(text_words[i].word) != roots[0]) continue;
        size_t cursor = i + 1;
        bool matched = true;
        for (size_t n = 1; n < roots.size(); ++n) {
            // Multi-word place names may have a short connective word between parts.
            size_t found = cursor;
            while (found < text_words.size() && found - cursor <= 2 && RussianStem(text_words[found].word) != roots[n]) ++found;
            if (found >= text_words.size() || found - cursor > 2) { matched = false; break; }
            cursor = found + 1;
        }
        if (matched && (best == std::string::npos || text_words[i].pos < best)) best = text_words[i].pos;
    }
    return best;
}

void AppendJsonStrings(const cJSON* item, std::string& out) {
    if (!item) return;
    if (cJSON_IsString(item) && item->valuestring) {
        if (!out.empty()) out.push_back(' ');
        out += item->valuestring;
        return;
    }
    if (cJSON_IsArray(item) || cJSON_IsObject(item)) {
        for (const cJSON* child = item->child; child; child = child->next) AppendJsonStrings(child, out);
    }
}
}

DroneMap::DroneMap() { RegisterTool(); }
DroneMap::~DroneMap() { poll_running_ = false; }

void DroneMap::EnsureUi() {
    if (root_) return;
    auto display = Board::GetInstance().GetDisplay();
    if (!display || !display->SupportsGuiOperations()) return;
    DisplayLockGuard lock(display);
    if (!lock) return;

    root_ = lv_obj_create(lv_screen_active());
    lv_obj_set_size(root_, 360, 360);
    lv_obj_set_pos(root_, 0, 0);
    lv_obj_set_style_radius(root_, 0, LV_PART_MAIN);
    lv_obj_set_style_border_width(root_, 0, LV_PART_MAIN);
    lv_obj_set_style_pad_all(root_, 0, LV_PART_MAIN);
    lv_obj_set_style_bg_color(root_, lv_color_make(0, 8, 22), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(root_, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_clear_flag(root_, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_add_flag(root_, LV_OBJ_FLAG_HIDDEN);

    map_image_ = lv_image_create(root_);
    lv_image_set_src(map_image_, &drone_map_image);
    lv_obj_set_size(map_image_, 360, 360);
    lv_obj_set_pos(map_image_, 0, 0);

    markers_layer_ = lv_obj_create(root_);
    lv_obj_set_size(markers_layer_, 360, 360);
    lv_obj_set_pos(markers_layer_, 0, 0);
    lv_obj_set_style_radius(markers_layer_, 0, LV_PART_MAIN);
    lv_obj_set_style_border_width(markers_layer_, 0, LV_PART_MAIN);
    lv_obj_set_style_pad_all(markers_layer_, 0, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(markers_layer_, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_clear_flag(markers_layer_, LV_OBJ_FLAG_SCROLLABLE);

    // Thick clockwise radar sweep; update only the endpoint to keep CPU and memory overhead low.
    sweep_line_ = lv_line_create(root_);
    static lv_point_precise_t sweep_points[2];
    sweep_points[0].x = 180; sweep_points[0].y = 180;
    sweep_points[1].x = 180; sweep_points[1].y = 8;
    lv_line_set_points(sweep_line_, sweep_points, 2);
    lv_obj_set_style_line_width(sweep_line_, 6, LV_PART_MAIN);
    lv_obj_set_style_line_color(sweep_line_, lv_color_make(70, 255, 95), LV_PART_MAIN);
    lv_obj_set_style_line_opa(sweep_line_, LV_OPA_80, LV_PART_MAIN);
    lv_obj_set_style_line_rounded(sweep_line_, true, LV_PART_MAIN);
    sweep_timer_ = lv_timer_create([](lv_timer_t* timer) {
        auto* self = static_cast<DroneMap*>(lv_timer_get_user_data(timer));
        if (!self || !self->sweep_line_ || !self->visible_) return;
        self->sweep_angle_ = (self->sweep_angle_ + 3) % 360;
        const double radians = (self->sweep_angle_ - 90) * 3.14159265358979323846 / 180.0;
        static lv_point_precise_t points[2];
        points[0].x = 180; points[0].y = 180;
        points[1].x = static_cast<lv_coord_t>(180 + 171 * std::cos(radians));
        points[1].y = static_cast<lv_coord_t>(180 + 171 * std::sin(radians));
        lv_line_set_points(self->sweep_line_, points, 2);
    }, 50, this);
}

void DroneMap::RedrawMarkers() {
    if (!markers_layer_) return;
    auto display = Board::GetInstance().GetDisplay();
    DisplayLockGuard lock(display);
    if (!lock) return;
    lv_obj_clean(markers_layer_);

    std::vector<Event> snapshot;
    { std::lock_guard<std::mutex> guard(events_mutex_); for (const auto& kv : events_) snapshot.push_back(kv.second); }
    for (const auto& e : snapshot) {
        const int x = e.x, y = e.y;
        if (x < 0 || x >= 360 || y < 0 || y >= 360) continue;
        // Neon halo + bright core makes markers readable over the map artwork.
        lv_obj_t* halo = lv_obj_create(markers_layer_);
        lv_obj_set_size(halo, e.threat_type == "region" ? 21 : 17, e.threat_type == "region" ? 21 : 17);
        lv_obj_set_pos(halo, x - (e.threat_type == "region" ? 10 : 8), y - (e.threat_type == "region" ? 10 : 8));
        lv_obj_set_style_radius(halo, LV_RADIUS_CIRCLE, LV_PART_MAIN);
        lv_obj_set_style_border_width(halo, 0, LV_PART_MAIN);
        lv_obj_set_style_bg_color(halo, lv_color_make(255, 30, 50), LV_PART_MAIN);
        lv_obj_set_style_bg_opa(halo, LV_OPA_30, LV_PART_MAIN);
        lv_obj_t* dot = lv_obj_create(markers_layer_);
        lv_obj_set_size(dot, e.threat_type == "region" ? 12 : 9, e.threat_type == "region" ? 12 : 9);
        lv_obj_set_pos(dot, x - (e.threat_type == "region" ? 6 : 4), y - (e.threat_type == "region" ? 6 : 4));
        lv_obj_set_style_radius(dot, LV_RADIUS_CIRCLE, LV_PART_MAIN);
        lv_obj_set_style_border_width(dot, 2, LV_PART_MAIN);
        lv_obj_set_style_border_color(dot, lv_color_white(), LV_PART_MAIN);
        lv_obj_set_style_bg_opa(dot, LV_OPA_COVER, LV_PART_MAIN);
        lv_color_t marker_color = lv_color_make(255, 150, 0); // other/unknown
        if (e.threat_type == "region") marker_color = lv_color_make(255, 45, 45);
        else if (e.threat_type == "uav") marker_color = lv_color_make(255, 55, 55);
        else if (e.threat_type == "missile") marker_color = lv_color_make(255, 45, 210);
        else if (e.threat_type == "fpv") marker_color = lv_color_make(255, 235, 35);
        lv_obj_set_style_bg_color(dot, marker_color, LV_PART_MAIN);
        if (e.threat_type == "region") {
            lv_obj_t* label = lv_label_create(markers_layer_);
            lv_label_set_text(label, "!");
            lv_obj_set_style_text_color(label, lv_color_white(), LV_PART_MAIN);
            lv_obj_set_style_text_font(label, LV_FONT_DEFAULT, LV_PART_MAIN);
            lv_obj_set_pos(label, x - 3, y - 7);
        }
    }
}

void DroneMap::FetchArgus() {
    ResponseBuffer response;
    response.capacity = kMaxResponseBytes;
    response.data = static_cast<char*>(heap_caps_malloc(response.capacity, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
    if (!response.data) {
        ESP_LOGW(TAG, "Argus PSRAM buffer allocation failed");
        return;
    }
    response.data[0] = '\0';

    esp_http_client_config_t config = {};
    config.url = kArgusUrl;
    config.timeout_ms = 15000;
    config.crt_bundle_attach = esp_crt_bundle_attach;
    config.event_handler = HttpEventHandler;
    config.user_data = &response;
    config.buffer_size = 4096;
    config.buffer_size_tx = 1024;
    esp_http_client_handle_t client = esp_http_client_init(&config);
    if (!client) {
        heap_caps_free(response.data);
        ESP_LOGW(TAG, "Argus HTTP client init failed");
        return;
    }
    esp_http_client_set_method(client, HTTP_METHOD_GET);
    esp_http_client_set_header(client, "Accept", "application/json");
    esp_http_client_set_header(client, "User-Agent", "TaijiPi-ESP32/2.5.0");
    esp_err_t result = esp_http_client_perform(client);
    const int status = esp_http_client_get_status_code(client);
    const int64_t content_length = esp_http_client_get_content_length(client);
    esp_http_client_cleanup(client);

    if (result != ESP_OK || status != 200 || response.size == 0 || response.overflow) {
        ESP_LOGW(TAG, "Argus GET failed: err=%s status=%d bytes=%u expected=%lld overflow=%d",
                 esp_err_to_name(result), status, static_cast<unsigned>(response.size),
                 static_cast<long long>(content_length), response.overflow ? 1 : 0);
        heap_caps_free(response.data);
        return;
    }

    // Scan every JSON object in the document, not only alerts.regions[].
    // Argus also publishes individual AI events (type="point") in other arrays.
    // Parse each closed object that looks like an event; avoid building a tree for
    // the full 100+ KB payload to keep ESP32 heap use bounded.
    std::map<std::string, Event> fresh;
    int objects_seen = 0, events_seen = 0, markers_added = 0;
    std::vector<const char*> object_starts;
    bool in_string = false, escaped = false;
    for (const char* q = response.data; *q; ++q) {
        const char c = *q;
        if (in_string) {
            if (escaped) escaped = false;
            else if (c == '\\') escaped = true;
            else if (c == '"') in_string = false;
            continue;
        }
        if (c == '"') in_string = true;
        else if (c == '{') object_starts.push_back(q);
        else if (c == '}' && !object_starts.empty()) {
            const char* object_start = object_starts.back();
            object_starts.pop_back();
            const size_t object_len = static_cast<size_t>(q - object_start + 1);
            // Do not require any particular identifier: Argus can change id/iso formats
            // or omit them entirely. Accept records based on descriptive/event fields.
            if (object_len < 40 || object_len > 65536) continue;
            std::string raw(object_start, object_len);
            if (raw.find("\"label\"") == std::string::npos) continue;
            const bool has_event_field = raw.find("\"status\"") != std::string::npos ||
                raw.find("\"type\"") != std::string::npos ||
                raw.find("\"threatCategory\"") != std::string::npos ||
                raw.find("\"threatType\"") != std::string::npos ||
                raw.find("\"sourceKey\"") != std::string::npos ||
                raw.find("\"linkedTrackIds\"") != std::string::npos ||
                raw.find("\"evidence\"") != std::string::npos;
            if (!has_event_field) continue;
            cJSON* item = cJSON_ParseWithLength(object_start, object_len);
            if (!item) continue;
            ++objects_seen;
            cJSON* id_item = cJSON_GetObjectItemCaseSensitive(item, "id");
            cJSON* label_item = cJSON_GetObjectItemCaseSensitive(item, "label");
            cJSON* geo_name_item = cJSON_GetObjectItemCaseSensitive(item, "geoName");
            cJSON* evidence_item = cJSON_GetObjectItemCaseSensitive(item, "evidence");
            cJSON* source_key_item = cJSON_GetObjectItemCaseSensitive(item, "sourceKey");
            cJSON* status_item = cJSON_GetObjectItemCaseSensitive(item, "status");
            cJSON* type_item = cJSON_GetObjectItemCaseSensitive(item, "type");
            cJSON* threat_item = cJSON_GetObjectItemCaseSensitive(item, "threatType");
            cJSON* category_item = cJSON_GetObjectItemCaseSensitive(item, "threatCategory");
            cJSON* expiry_item = cJSON_GetObjectItemCaseSensitive(item, "expiresAt");
            if (!cJSON_IsString(label_item) || !label_item->valuestring || !*label_item->valuestring) {
                cJSON_Delete(item); continue;
            }
            // Regional air alerts and explicit point/events are both valid. Other
            // nested records are ignored unless they carry an event type or alert status.
            const bool regional = cJSON_IsString(status_item) && status_item->valuestring &&
                strcmp(status_item->valuestring, "air_alert") == 0;
            const bool point_event = cJSON_IsString(type_item) &&
                (strcmp(type_item->valuestring, "point") == 0 || strcmp(type_item->valuestring, "event") == 0);
            if (!regional && !point_event) { cJSON_Delete(item); continue; }
            if (cJSON_IsString(expiry_item) && strlen(expiry_item->valuestring) >= 20) {
                const time_t now = time(nullptr);
                if (now > 1700000000) {
                    struct tm utc_now = {}; gmtime_r(&now, &utc_now);
                    char now_iso[24] = {}; strftime(now_iso, sizeof(now_iso), "%Y-%m-%dT%H:%M:%SZ", &utc_now);
                    if (strncmp(expiry_item->valuestring, now_iso, 19) <= 0) { cJSON_Delete(item); continue; }
                }
            }
            ++events_seen;
            std::string location_text;
            AppendJsonStrings(item, location_text);
            // Identifiers are deliberately not used for matching or geographic placement.
            // They are optional diagnostics only; use the descriptive text as a stable fallback.
            std::string id = label_item->valuestring;
            if (cJSON_IsString(evidence_item) && evidence_item->valuestring) id += ":" + std::string(evidence_item->valuestring);
            else if (cJSON_IsString(source_key_item) && source_key_item->valuestring) id += ":" + std::string(source_key_item->valuestring);
            (void)id_item;
            std::string threat = "other";
            const char* threat_value = cJSON_IsString(threat_item) ? threat_item->valuestring :
                (cJSON_IsString(category_item) ? category_item->valuestring : "");
            const std::string threat_lower = LowerUtf8(threat_value ? threat_value : "");
            if (threat_lower.find("fpv") != std::string::npos) threat = "fpv";
            else if (threat_lower.find("missile") != std::string::npos || threat_lower.find("rocket") != std::string::npos || threat_lower.find("рак") != std::string::npos) threat = "missile";
            else if (threat_lower.find("uav") != std::string::npos || threat_lower.find("bpla") != std::string::npos || threat_lower.find("drone") != std::string::npos || threat_lower.find("бпла") != std::string::npos) threat = "uav";
            else if (regional) threat = "region";

            // First use all settlement names found in label/evidence/metadata.
            std::vector<std::pair<size_t, const MapPoint*>> matches;
            const std::string lowered = LowerUtf8(location_text);
            for (const auto& point : kMapPoints) {
                if (strcmp(point.name, "порт") == 0 || strcmp(point.name, "ferry") == 0 ||
                    strcmp(point.name, "переправ") == 0 || strcmp(point.name, "Kerch Strait") == 0 ||
                    strcmp(point.name, "Керченский пролив") == 0 || strcmp(point.name, "Сиваш") == 0 ||
                    strcmp(point.name, "Sivash") == 0 || strcmp(point.name, "Азовское море") == 0 ||
                    strcmp(point.name, "Azov Sea") == 0 || strcmp(point.name, "Тарханкут") == 0 ||
                    strcmp(point.name, "Tarkhankut") == 0 || strcmp(point.name, "Ленинский район") == 0 ||
                    strcmp(point.name, "Leninsky") == 0 || strcmp(point.name, "Феодосийский залив") == 0 ||
                    strcmp(point.name, "Feodosia port") == 0 || strcmp(point.name, "port of Feodosia") == 0) continue;
                size_t pos = FindLocationPosition(lowered, point.name);
                if (pos != std::string::npos) matches.push_back({pos, &point});
            }
            std::sort(matches.begin(), matches.end(), [](const auto& a, const auto& b) {
                if (a.first != b.first) return a.first < b.first;
                return strlen(a.second->name) > strlen(b.second->name);
            });
            std::vector<std::pair<int,int>> used;
            bool placed_this_event = false;
            for (const auto& match : matches) {
                const MapPoint* point = match.second;
                bool duplicate = false;
                for (const auto& xy : used) if (xy.first == point->x && xy.second == point->y) { duplicate = true; break; }
                if (duplicate) continue;
                used.push_back({point->x, point->y});
                Event e; e.id = id + ":" + std::to_string(point->x) + ":" + std::to_string(point->y);
                e.x = point->x; e.y = point->y; e.threat_type = threat; e.status = "active";
                fresh[e.id] = e; ++markers_added; placed_this_event = true;
            }
            // Events may have coordinates but no settlement name in their text.
            // Approximate the point on the existing map using known Kerch/Feodosia anchors.
            if (used.empty()) {
                cJSON* points = cJSON_GetObjectItemCaseSensitive(item, "points");
                if (cJSON_IsArray(points)) {
                    for (cJSON* pt = points->child; pt; pt = pt->next) {
                        cJSON* lat = cJSON_GetObjectItemCaseSensitive(pt, "lat");
                        cJSON* lng = cJSON_GetObjectItemCaseSensitive(pt, "lng");
                        if (!cJSON_IsNumber(lat) || !cJSON_IsNumber(lng)) continue;
                        int x = -1, y = -1;
                        // Anchored approximation for eastern Crimea and Kerch approach.
                        if (lat->valuedouble >= 44.8 && lat->valuedouble <= 45.5 && lng->valuedouble >= 35.8 && lng->valuedouble <= 36.8) {
                            x = 294 + static_cast<int>((lng->valuedouble - 36.1) * 48.0);
                            y = 184 - static_cast<int>((lat->valuedouble - 45.35) * 65.0);
                        }
                        if (x >= 0 && x < 360 && y >= 0 && y < 360) {
                            Event e; e.id = id + ":coord:" + std::to_string(x) + ":" + std::to_string(y);
                            e.x = x; e.y = y; e.threat_type = threat; e.status = "active";
                            fresh[e.id] = e; ++markers_added; placed_this_event = true;
                        }
                    }
                }
            }
            // If location is the Crimea region but has no named settlement, retain a fallback.
            // If a regional alert has no named settlement match, use the region's
            // descriptive name/evidence as a fallback. Never key this decision on id/iso.
            const std::string label_text = label_item->valuestring ? label_item->valuestring : "";
            const std::string geo_text = cJSON_IsString(geo_name_item) && geo_name_item->valuestring ? geo_name_item->valuestring : "";
            const std::string evidence_text = cJSON_IsString(evidence_item) && evidence_item->valuestring ? evidence_item->valuestring : "";
            const bool crimea_region = ContainsNoCase(label_text, "Crimea") || ContainsNoCase(label_text, "Крым") ||
                ContainsNoCase(geo_text, "Crimea") || ContainsNoCase(geo_text, "Крым") ||
                ContainsNoCase(evidence_text, "Крым") || ContainsNoCase(evidence_text, "Crimea");
            if (!placed_this_event && regional && crimea_region) {
                Event e; e.id = label_text + ":regional-fallback:127:228"; e.x = 127; e.y = 228;
                e.threat_type = threat; e.status = "active"; fresh[e.id] = e; ++markers_added;
            }
            cJSON_Delete(item);
        }
    }
    ESP_LOGI(TAG, "Argus events scanned=%d accepted=%d markers=%d", objects_seen, events_seen, markers_added);
    heap_caps_free(response.data);

    // A valid empty regions array means no active regional alerts: clear markers.
    { std::lock_guard<std::mutex> guard(events_mutex_); events_.swap(fresh); }
    if (visible_) RedrawMarkers();
}

void DroneMap::PollTask(void* arg) {
    auto* self = static_cast<DroneMap*>(arg);
    // The polling task exists only while the map is visible. This releases its
    // 8 KB task stack when the user returns to the assistant.
    while (self && self->poll_running_ && self->visible_) {
        for (uint32_t elapsed = 0; elapsed < kPollIntervalMs && self->poll_running_ && self->visible_; elapsed += 250) {
            vTaskDelay(pdMS_TO_TICKS(250));
        }
        if (self->poll_running_ && self->visible_) self->FetchArgus();
    }
    if (self) {
        self->poll_running_ = false;
        self->poll_task_ = nullptr;
    }
    vTaskDelete(nullptr);
}

bool DroneMap::Show() {
    EnsureUi();
    if (!root_) return false;
    visible_ = true;
    { DisplayLockGuard lock(Board::GetInstance().GetDisplay()); if (!lock) return false; lv_obj_remove_flag(root_, LV_OBJ_FLAG_HIDDEN); }
    RedrawMarkers();
    poll_running_ = true;
    if (!poll_task_) {
        if (xTaskCreate(PollTask, "argus_map", 8192, this, 3, &poll_task_) != pdPASS) poll_task_ = nullptr;
    }
    FetchArgus();
    return true;
}

void DroneMap::Hide() {
    visible_ = false;
    poll_running_ = false;

    // Stop the radar timer while holding the same LVGL display lock used by
    // the GUI task. RedrawMarkers() must never delete the sweep line: it lives
    // directly under root_, outside the marker layer that is cleared/redrawn.
    auto display = Board::GetInstance().GetDisplay();
    if (display) {
        DisplayLockGuard lock(display);
        if (lock) {
            if (sweep_timer_) { lv_timer_delete(sweep_timer_); sweep_timer_ = nullptr; }
            if (root_) lv_obj_delete(root_);
            root_ = nullptr;
            map_image_ = nullptr;
            markers_layer_ = nullptr;
            sweep_line_ = nullptr;
        }
    } else {
        sweep_timer_ = nullptr;
        root_ = nullptr;
        map_image_ = nullptr;
        markers_layer_ = nullptr;
        sweep_line_ = nullptr;
    }
    {
        std::lock_guard<std::mutex> guard(events_mutex_);
        events_.clear();
    }
}

bool DroneMap::TouchDown(int x, int y) { touch_down_ = true; touch_start_x_ = x; touch_start_y_ = y; return visible_; }
bool DroneMap::TouchMove(int, int) { return touch_down_ && visible_; }
bool DroneMap::TouchUp(int x, int y) {
    if (!touch_down_) return false;
    touch_down_ = false;
    const int dx = x - touch_start_x_, dy = y - touch_start_y_;
    if (!visible_) {
        if (dx < -kSwipeThreshold && std::abs(dx) > std::abs(dy)) { Show(); return true; }
        return false;
    }
    if (touch_start_x_ < 80 && dx > kSwipeThreshold && std::abs(dx) > std::abs(dy)) { Hide(); return true; }
    return true;
}

void DroneMap::RegisterTool() {
    auto& mcp = McpServer::GetInstance();
    mcp.AddTool("self.drone_map.show",
        "Show the Crimea live regional alert map. Use for requests such as: 'включи карту дронов', 'покажи карту дронов'.",
        PropertyList(), [this](const PropertyList&) -> ReturnValue { return Show(); });
    mcp.AddTool("self.drone_map.hide",
        "Hide the drone map and return to the voice assistant. Use for requests such as: 'выключи карту дронов', 'закрой карту дронов', 'верни помощника'.",
        PropertyList(), [this](const PropertyList&) -> ReturnValue { Hide(); return true; });
}

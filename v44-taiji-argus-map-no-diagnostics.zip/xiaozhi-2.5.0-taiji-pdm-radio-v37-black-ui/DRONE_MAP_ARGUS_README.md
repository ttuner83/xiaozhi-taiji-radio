# Argus regional map integration (V44 draft)

Based on the supplied `v43b-detector-aero-ws-buffer-no-debug.zip`.

## Changes
- Replaced the Detector-AERO WebSocket client with HTTPS polling of `https://argusmap.online/api/live` once per minute while the map is visible.
- Parses `alerts.regions[]`; only entries with `status == "air_alert"` are displayed; expired entries are skipped when the device clock is synchronized.
- Uses `evidence` text to place red alert markers on matching Crimea place/region/sea anchors. English aliases are included for places referenced in Argus evidence. If the Crimea region has no matched place, a fallback marker is placed near eastern Crimea.
- Removed map-specific diagnostic/handshake/payload-preview logs.
- Replaced the zero-filled placeholder image data with `map333.png` converted to 360x360 RGB565 for LVGL.
- Added the approximate pixel-anchor table and a numbered preview.

## Important limitations
- Pixel anchors for locations not labelled on the source image are approximate. They are intended for regional alert visualization, not navigation or exact object geolocation.
- This archive was checked for ZIP integrity and source-level consistency, but a full ESP-IDF compile was not run in this environment because `idf.py` / the ESP32 toolchain are not installed. The GitHub Actions build is still required to confirm compilation on ESP-IDF 6.0.2.

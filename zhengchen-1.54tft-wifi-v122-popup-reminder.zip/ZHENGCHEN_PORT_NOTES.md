# Zhengchen 1.54 TFT Wi-Fi port from v95-32

This source package keeps the Zhengchen 1.54 TFT Wi-Fi board configuration and ports the v95-32 application features to that board:
- configurable idle display-off timeout and Wi-Fi maximum power saving after assistant audio is fully drained;
- local web radio settings page with up to three RSS URLs and an Argus parser URL;
- music playback MCP tools and radio/music streaming support;
- Russian Wikipedia search MCP tool;
- RSS news MCP tool with persisted seen-item history and fallback feeds;
- Argus active-location voice query.

Build target: `zhengchen/1.54tft-wifi`.

Important: the inherited v95-32 Argus implementation provides a voice query of active locations; this package does not claim that the full custom animated `map333` radar screen from earlier experiments has been ported to this non-touch Zhengchen board. The board's radio/music screen is also not touch-operated because this Zhengchen board adaptation has no CST816S touch polling integration.

The source was merged and structurally checked in this environment, but a full ESP-IDF build and physical hardware test have not been performed here. Use GitHub Actions to compile it and inspect the build log before flashing.

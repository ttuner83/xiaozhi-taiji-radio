#include "audio_codec.h"
#include "board.h"
#include "settings.h"

#include <esp_log.h>
#include <cstring>
#include <driver/i2s_common.h>

#define TAG "AudioCodec"

AudioCodec::AudioCodec() {
}

AudioCodec::~AudioCodec() {
}

void AudioCodec::OutputData(std::vector<int16_t>& data) {
    Write(data.data(), data.size());
}

void AudioCodec::OutputDataRaw(std::vector<int16_t>& data) {
    Write(data.data(), data.size());
}

bool AudioCodec::InputData(std::vector<int16_t>& data) {
    int samples = Read(data.data(), data.size());
    if (samples > 0) {
        return true;
    }
    return false;
}

void AudioCodec::Start() {
    Settings settings("audio", false);
    Settings migration_settings("audio", true);
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3
    const bool default_volume_applied = settings.GetInt("vdef30t_v3", 0) != 0;
    if (!default_volume_applied) {
        output_volume_ = 30;
        migration_settings.SetInt("output_volume", output_volume_);
        migration_settings.SetInt("vdef30t_v3", 1);
        ESP_LOGI(TAG, "Applied Taiji default output volume: 30");
    } else {
        output_volume_ = settings.GetInt("output_volume", output_volume_);
    }
#else
    const bool default_volume_applied = settings.GetInt("vol_def35_v2", 0) != 0;
    if (!default_volume_applied) {
        output_volume_ = 35;
        migration_settings.SetInt("output_volume", output_volume_);
        migration_settings.SetInt("vol_def35_v2", 1);
        ESP_LOGI(TAG, "Applied new default output volume: 35");
    } else {
        output_volume_ = settings.GetInt("output_volume", output_volume_);
    }
#endif
    if (output_volume_ < 0) {
#if CONFIG_BOARD_TYPE_TAIJI_PI_S3
        ESP_LOGW(TAG, "Output volume value (%d) is invalid, setting to default (30)", output_volume_);
        output_volume_ = 30;
#else
        ESP_LOGW(TAG, "Output volume value (%d) is invalid, setting to default (35)", output_volume_);
        output_volume_ = 35;
#endif
    }
    if (output_volume_ > 100) {
        output_volume_ = 100;
    }

    ESP_LOGI(TAG, "Audio codec started");
}

void AudioCodec::SetOutputVolume(int volume) {
    output_volume_ = volume;
    ESP_LOGI(TAG, "Set output volume to %d", output_volume_);
    
    Settings settings("audio", true);
    settings.SetInt("output_volume", output_volume_);
}

void AudioCodec::SetInputGain(float gain) {
    input_gain_ = gain;
    ESP_LOGI(TAG, "Set input gain to %.1f", input_gain_);
}

void AudioCodec::EnableInput(bool enable) {
    if (enable == input_enabled_) {
        return;
    }
    input_enabled_ = enable;
    ESP_LOGI(TAG, "Set input enable to %s", enable ? "true" : "false");
}

void AudioCodec::EnableOutput(bool enable) {
    if (enable == output_enabled_) {
        return;
    }
    output_enabled_ = enable;
    ESP_LOGI(TAG, "Set output enable to %s", enable ? "true" : "false");
}

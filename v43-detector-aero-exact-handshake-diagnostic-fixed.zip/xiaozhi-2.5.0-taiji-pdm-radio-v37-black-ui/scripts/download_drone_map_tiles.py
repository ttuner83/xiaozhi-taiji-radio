#!/usr/bin/env python3
"""Build the fixed offline Feodosia map used by DroneMap.

The ESP32 never downloads map tiles. GitHub Actions downloads a small 4x4
OpenTopoMap tile set, crops a ~400x400 km square centered on Feodosia and
resamples it once to exactly 360x360 pixels. The resulting PNG is embedded
into generated_tiles.h and flashed as part of the application.
"""
import io
import pathlib
import struct
import time
import urllib.request
from PIL import Image

OUT = pathlib.Path("main/features/drone_map/generated_tiles.h")
ZOOM = 8
CENTER_LAT = 45.0319
CENTER_LON = 35.3824
MIN_X, MAX_X = 151, 154
MIN_Y, MAX_Y = 90, 93
TILE = 256
TARGET = 360
# Ground coverage is approximately 400x400 km (about 200 km radius).
MAP_WORLD_SIZE = 925.6
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36"
BASE_URLS = [
    "https://tile.opentopomap.org/{z}/{x}/{y}.png",
    "https://a.tile.opentopomap.org/{z}/{x}/{y}.png",
    "https://b.tile.opentopomap.org/{z}/{x}/{y}.png",
    "https://c.tile.opentopomap.org/{z}/{x}/{y}.png",
]


def world_xy(lat, lon):
    import math
    n = 2 ** ZOOM
    x = (lon + 180.0) / 360.0 * n * TILE
    r = math.radians(lat)
    y = (1.0 - math.asinh(math.tan(r)) / math.pi) / 2.0 * n * TILE
    return x, y


def download_tile(x, y):
    last = None
    for base in BASE_URLS:
        url = base.format(z=ZOOM, x=x, y=y)
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8", "Accept-Language": "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7"})
            with urllib.request.urlopen(req, timeout=30) as r:
                data = r.read()
            im = Image.open(io.BytesIO(data)).convert("RGB")
            if im.size != (TILE, TILE):
                raise RuntimeError(f"unexpected tile size: {im.size}")
            print("Downloaded", url, flush=True)
            return im
        except Exception as exc:
            last = exc
            print("Failed", url, exc, flush=True)
    raise RuntimeError(f"Unable to download tile {x}/{y}: {last}")


center_x, center_y = world_xy(CENTER_LAT, CENTER_LON)
origin_x = MIN_X * TILE
origin_y = MIN_Y * TILE
local_cx = center_x - origin_x
local_cy = center_y - origin_y
left = int(round(local_cx - MAP_WORLD_SIZE / 2))
top = int(round(local_cy - MAP_WORLD_SIZE / 2))
right = left + int(round(MAP_WORLD_SIZE))
bottom = top + int(round(MAP_WORLD_SIZE))

mosaic = Image.new("RGB", ((MAX_X - MIN_X + 1) * TILE, (MAX_Y - MIN_Y + 1) * TILE))
for y in range(MIN_Y, MAX_Y + 1):
    for x in range(MIN_X, MAX_X + 1):
        mosaic.paste(download_tile(x, y), ((x - MIN_X) * TILE, (y - MIN_Y) * TILE))
        time.sleep(0.2)

crop = mosaic.crop((left, top, right, bottom))
image = crop.resize((TARGET, TARGET), Image.Resampling.LANCZOS)
image = image.convert("RGB")
buf = io.BytesIO()
image.save(buf, format="PNG", optimize=True, compress_level=9)
data = buf.getvalue()

# These are global Web-Mercator pixel coordinates of the fixed image's top-left
# and its source size, used to place live Detector-AERO markers correctly.
world_left = origin_x + left
world_top = origin_y + top
world_size = right - left

# Store the final 360x360 image as uncompressed RGB565.  This is a native
# LVGL variable-image format, so the ESP32 does not need a PNG decoder or
# a second large decode buffer at runtime.
rgb = image.load()
raw = bytearray()
for yy in range(TARGET):
    for xx in range(TARGET):
        r, g, b = rgb[xx, yy]
        value = ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3)
        raw.extend(struct.pack("<H", value))

with OUT.open("w", encoding="utf-8") as f:
    f.write("// Auto-generated during GitHub Actions build. Do not edit.\n")
    f.write("#pragma once\n#include <cstdint>\n#include <cstddef>\n#include <lvgl.h>\n\n")
    f.write(f"static constexpr double drone_map_world_left = {world_left:.6f};\n")
    f.write(f"static constexpr double drone_map_world_top = {world_top:.6f};\n")
    f.write(f"static constexpr double drone_map_world_size = {world_size:.6f};\n")
    f.write(f"static constexpr size_t drone_map_rgb565_size = {len(raw)};\n")
    f.write("static const uint8_t drone_map_rgb565[] = {\n")
    for i in range(0, len(raw), 16):
        f.write("  " + ", ".join(f"0x{b:02x}" for b in raw[i:i+16]) + ",\n")
    f.write("};\n\n")
    f.write("static const lv_image_dsc_t drone_map_image = {\n")
    f.write("  .header = {\n")
    f.write("    .magic = LV_IMAGE_HEADER_MAGIC,\n")
    f.write("    .cf = LV_COLOR_FORMAT_RGB565,\n")
    f.write("    .flags = 0,\n")
    f.write(f"    .w = {TARGET}, .h = {TARGET}, .stride = {TARGET * 2}, .reserved_2 = 0\n")
    f.write("  },\n")
    f.write("  .data_size = drone_map_rgb565_size,\n")
    f.write("  .data = drone_map_rgb565,\n")
    f.write("  .reserved = nullptr\n")
    f.write("};\n")
print(f"Wrote {OUT}: {len(data)} bytes, 360x360, ~400x400 km coverage", flush=True)

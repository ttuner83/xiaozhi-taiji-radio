#include "drone_map.h"

#include "application.h"
#include "board.h"
#include "display/display.h"
#include "mcp_server.h"

#include <cJSON.h>
#include <esp_crt_bundle.h>
#include <esp_http_client.h>
#include <esp_heap_caps.h>
#include <esp_log.h>

#include <algorithm>
#include <array>
#include <cstring>
#include <cctype>
#include <string>
#include <ctime>
#include <vector>
#include <utility>

#include "generated_tiles.h"

#define TAG "DroneMap"

namespace {
constexpr const char* kArgusUrl = "https://argusmap.online/api/live";
constexpr int kSwipeThreshold = 70;
constexpr uint32_t kPollIntervalMs = 60000;
constexpr size_t kMaxResponseBytes = 256 * 1024;

struct MapPoint { const char* name; int x; int y; };
// Pixel anchors for map333.png (360x360). Points not labelled on the image are approximate.
constexpr MapPoint kMapPoints[] = {
    {"Армянск",72,111}, {"Красноперекопск",91,137}, {"Джанкой",151,148},
    {"Раздольное",48,155}, {"Раздольном",48,155}, {"Стерегущее",31,151}, {"Стерегущем",31,151}, {"Черноморское",22,176}, {"Евпатория",73,201},
    {"Саки",96,207}, {"Симферополь",127,228}, {"Бахчисарай",95,244},
    {"Севастополь",73,262}, {"Ялта",128,278}, {"Алушта",151,265},
    {"Белогорск",178,222}, {"Старый Крым",207,220}, {"Судак",187,246},
    {"Коктебель",215,226}, {"Феодосия",235,210}, {"Чауда",222,246},
    {"Кировское",204,201}, {"Щёлкино",263,157}, {"Ленино",261,190},
    {"Керчь",294,184}, {"Керченский пролив",319,201}, {"переправ",311,213},
    {"Арабатская стрелка",179,127}, {"Арабатской стрелки",179,127}, {"Сиваш",120,105},
    {"Азовское море",211,80}, {"Азовское море",278,72}, {"Азовское море",337,85},
    {"Тарханкут",20,190}, {"Ленинский район",254,214}, {"Феодосийский залив",247,196},
    {"порт",239,207}, {"Портовое",39,164}, {"Портовом",39,164},
    {"Armyansk",72,111}, {"Krasnoperekopsk",91,137}, {"Dzhankoy",151,148},
    {"Steregushchee",31,151}, {"Portovoe",39,164},
    {"Razdolnoe",48,155}, {"Chornomorske",22,176}, {"Yevpatoriya",73,201},
    {"Saki",96,207}, {"Simferopol",127,228}, {"Bakhchisarai",95,244},
    {"Sevastopol",73,262}, {"Yalta",128,278}, {"Alushta",151,265},
    {"Belogorsk",178,222}, {"Stary Krym",207,220}, {"Sudak",187,246},
    {"Koktebel",215,226}, {"Feodosia",235,210}, {"Chauda",222,246},
    {"Kirovsky",204,201}, {"Kirovske",204,201}, {"Shcholkine",263,157},
    {"Lenino",261,190}, {"Kerch",294,184}, {"Kerch Strait",319,201},
    {"ferry",311,213}, {"Arabat Spit",179,127}, {"Sivash",120,105},
    {"Azov Sea",278,72}, {"Tarkhankut",20,190}, {"Leninsky",254,214},
    {"Feodosia port",239,207}, {"port of Feodosia",239,207}
};

struct ResponseBuffer {
    char* data = nullptr;
    size_t size = 0;
    size_t capacity = 0;
    bool overflow = false;
};

esp_err_t HttpEventHandler(esp_http_client_event_t* evt) {
    if (evt && evt->event_id == HTTP_EVENT_ON_DATA && evt->user_data && evt->data && evt->data_len > 0) {
        auto* response = static_cast<ResponseBuffer*>(evt->user_data);
        const size_t len = static_cast<size_t>(evt->data_len);
        if (response->data && response->size + len < response->capacity) {
            memcpy(response->data + response->size, evt->data, len);
            response->size += len;
            response->data[response->size] = '\0';
        } else {
            response->overflow = true;
        }
    }
    return ESP_OK;
}

// Find the alerts.regions array without constructing a cJSON tree for the entire
// 110+ KB document. Each region object is parsed separately, keeping parser RAM low.
const char* FindRegionsArray(const char* json) {
    if (!json) return nullptr;
    const char* alerts = strstr(json, "\"alerts\"");
    if (!alerts) return nullptr;
    const char* regions = strstr(alerts, "\"regions\"");
    if (!regions) return nullptr;
    const char* colon = strchr(regions, ':');
    if (!colon) return nullptr;
    const char* array = strchr(colon + 1, '[');
    return array;
}

const char* FindMatchingArrayEnd(const char* start) {
    if (!start || *start != '[') return nullptr;
    int depth = 0;
    bool in_string = false, escaped = false;
    for (const char* p = start; *p; ++p) {
        const char c = *p;
        if (in_string) {
            if (escaped) escaped = false;
            else if (c == '\\') escaped = true;
            else if (c == '"') in_string = false;
            continue;
        }
        if (c == '"') in_string = true;
        else if (c == '[') ++depth;
        else if (c == ']' && --depth == 0) return p;
    }
    return nullptr;
}

std::string LowerUtf8(std::string value) {
    std::string out;
    out.reserve(value.size());
    for (size_t i = 0; i < value.size();) {
        const unsigned char c = static_cast<unsigned char>(value[i]);
        if (c < 0x80) {
            out.push_back(static_cast<char>(std::tolower(c)));
            ++i;
        } else if (i + 1 < value.size() && c == 0xD0) {
            const unsigned char d = static_cast<unsigned char>(value[i + 1]);
            if (d >= 0x90 && d <= 0x9F) { out.push_back(static_cast<char>(0xD0)); out.push_back(static_cast<char>(d + 0x20)); }
            else if (d >= 0xA0 && d <= 0xAF) { out.push_back(static_cast<char>(0xD1)); out.push_back(static_cast<char>(d - 0x20)); }
            else if (d == 0x81) { out.push_back(static_cast<char>(0xD1)); out.push_back(static_cast<char>(0x91)); }
            else { out.push_back(value[i]); out.push_back(value[i + 1]); }
            i += 2;
        } else {
            out.push_back(value[i++]);
        }
    }
    return out;
}

bool ContainsNoCase(const std::string& text, const char* phrase) {
    if (!phrase || !*phrase) return false;
    return LowerUtf8(text).find(LowerUtf8(phrase)) != std::string::npos;
}

// Reduce Russian words to a conservative stem so that city names match common
// grammatical cases (e.g. Feodosia/Feodosii, Kerch/Kerchi, Arabatskoy strelki).
// This is intentionally token-based: it does not match arbitrary substrings.
std::string RussianStem(std::string word) {
    static const char* suffixes[] = {
        "иями", "ями", "ами", "иями", "иями", "ского", "цкого", "ному", "нему",
        "ыми", "ими", "ого", "его", "ому", "ему", "ией", "ией", "иях", "иях",
        "иям", "ием", "ией", "ская", "цкая", "ской", "цкой", "ские", "цкие",
        "иями", "ями", "ами", "ией", "ия", "ии", "ие", "ей", "ой", "ый", "ий",
        "ая", "яя", "ое", "ее", "ом", "ем", "ам", "ям", "ах", "ях", "ы", "и",
        "а", "я", "ь", "й", "е", "у", "ю"
    };
    for (const char* suffix : suffixes) {
        const size_t n = strlen(suffix);
        if (word.size() > n + 2 && word.compare(word.size() - n, n, suffix) == 0) {
            word.resize(word.size() - n);
            break;
        }
    }
    return word;
}

struct WordToken { std::string word; size_t pos; };
std::vector<WordToken> TokenizeWords(const std::string& text) {
    std::vector<WordToken> out;
    size_t i = 0;
    while (i < text.size()) {
        const unsigned char c = static_cast<unsigned char>(text[i]);
        const bool word_char = (c >= 128) || std::isalnum(c);
        if (!word_char) { ++i; continue; }
        const size_t start = i;
        while (i < text.size()) {
            const unsigned char d = static_cast<unsigned char>(text[i]);
            if (!(d >= 128 || std::isalnum(d))) break;
            ++i;
        }
        out.push_back({text.substr(start, i - start), start});
    }
    return out;
}

size_t FindLocationPosition(const std::string& lowered_text, const char* raw_name) {
    if (!raw_name || !*raw_name) return std::string::npos;
    const std::string lowered_name = LowerUtf8(raw_name);
    // Latin transliterations are matched as complete phrases, case-insensitively.
    bool has_cyrillic = false;
    for (unsigned char c : lowered_name) if (c >= 0xD0) { has_cyrillic = true; break; }
    if (!has_cyrillic) return lowered_text.find(lowered_name);

    const auto text_words = TokenizeWords(lowered_text);
    const auto name_words = TokenizeWords(lowered_name);
    if (name_words.empty()) return std::string::npos;
    std::vector<std::string> roots;
    roots.reserve(name_words.size());
    for (const auto& word : name_words) roots.push_back(RussianStem(word.word));

    size_t best = std::string::npos;
    for (size_t i = 0; i < text_words.size(); ++i) {
        if (RussianStem(text_words[i].word) != roots[0]) continue;
        size_t cursor = i + 1;
        bool matched = true;
        for (size_t n = 1; n < roots.size(); ++n) {
            // Multi-word place names may have a short connective word between parts.
            size_t found = cursor;
            while (found < text_words.size() && found - cursor <= 2 && RussianStem(text_words[found].word) != roots[n]) ++found;
            if (found >= text_words.size() || found - cursor > 2) { matched = false; break; }
            cursor = found + 1;
        }
        if (matched && (best == std::string::npos || text_words[i].pos < best)) best = text_words[i].pos;
    }
    return best;
}

void AppendJsonStrings(const cJSON* item, std::string& out) {
    if (!item) return;
    if (cJSON_IsString(item) && item->valuestring) {
        if (!out.empty()) out.push_back(' ');
        out += item->valuestring;
        return;
    }
    if (cJSON_IsArray(item) || cJSON_IsObject(item)) {
        for (const cJSON* child = item->child; child; child = child->next) AppendJsonStrings(child, out);
    }
}
}

DroneMap::DroneMap() { RegisterTool(); }
DroneMap::~DroneMap() { poll_running_ = false; }

void DroneMap::EnsureUi() {
    if (root_) return;
    auto display = Board::GetInstance().GetDisplay();
    if (!display || !display->SupportsGuiOperations()) return;
    DisplayLockGuard lock(display);
    if (!lock) return;

    root_ = lv_obj_create(lv_screen_active());
    lv_obj_set_size(root_, 360, 360);
    lv_obj_set_pos(root_, 0, 0);
    lv_obj_set_style_radius(root_, 0, LV_PART_MAIN);
    lv_obj_set_style_border_width(root_, 0, LV_PART_MAIN);
    lv_obj_set_style_pad_all(root_, 0, LV_PART_MAIN);
    lv_obj_set_style_bg_color(root_, lv_color_black(), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(root_, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_clear_flag(root_, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_add_flag(root_, LV_OBJ_FLAG_HIDDEN);

    map_image_ = lv_image_create(root_);
    lv_image_set_src(map_image_, &drone_map_image);
    lv_obj_set_size(map_image_, 360, 360);
    lv_obj_set_pos(map_image_, 0, 0);

    markers_layer_ = lv_obj_create(root_);
    lv_obj_set_size(markers_layer_, 360, 360);
    lv_obj_set_pos(markers_layer_, 0, 0);
    lv_obj_set_style_radius(markers_layer_, 0, LV_PART_MAIN);
    lv_obj_set_style_border_width(markers_layer_, 0, LV_PART_MAIN);
    lv_obj_set_style_pad_all(markers_layer_, 0, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(markers_layer_, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_clear_flag(markers_layer_, LV_OBJ_FLAG_SCROLLABLE);
}

void DroneMap::RedrawMarkers() {
    if (!markers_layer_) return;
    auto display = Board::GetInstance().GetDisplay();
    DisplayLockGuard lock(display);
    if (!lock) return;
    lv_obj_clean(markers_layer_);

    std::vector<Event> snapshot;
    { std::lock_guard<std::mutex> guard(events_mutex_); for (const auto& kv : events_) snapshot.push_back(kv.second); }
    for (const auto& e : snapshot) {
        const int x = e.x, y = e.y;
        if (x < 0 || x >= 360 || y < 0 || y >= 360) continue;
        lv_obj_t* dot = lv_obj_create(markers_layer_);
        lv_obj_set_size(dot, e.threat_type == "region" ? 13 : 10, e.threat_type == "region" ? 13 : 10);
        lv_obj_set_pos(dot, x - 6, y - 6);
        lv_obj_set_style_radius(dot, LV_RADIUS_CIRCLE, LV_PART_MAIN);
        lv_obj_set_style_border_width(dot, 1, LV_PART_MAIN);
        lv_obj_set_style_border_color(dot, lv_color_white(), LV_PART_MAIN);
        lv_obj_set_style_bg_opa(dot, LV_OPA_COVER, LV_PART_MAIN);
        lv_obj_set_style_bg_color(dot, e.threat_type == "region" ? lv_color_make(225, 25, 35) : lv_color_make(255, 135, 0), LV_PART_MAIN);
        if (e.threat_type == "region") {
            lv_obj_t* label = lv_label_create(markers_layer_);
            lv_label_set_text(label, "!");
            lv_obj_set_style_text_color(label, lv_color_white(), LV_PART_MAIN);
            lv_obj_set_style_text_font(label, LV_FONT_DEFAULT, LV_PART_MAIN);
            lv_obj_set_pos(label, x - 3, y - 7);
        }
    }
}

void DroneMap::FetchArgus() {
    ResponseBuffer response;
    response.capacity = kMaxResponseBytes;
    response.data = static_cast<char*>(heap_caps_malloc(response.capacity, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
    if (!response.data) {
        ESP_LOGW(TAG, "Argus PSRAM buffer allocation failed");
        return;
    }
    response.data[0] = '\0';

    esp_http_client_config_t config = {};
    config.url = kArgusUrl;
    config.timeout_ms = 15000;
    config.crt_bundle_attach = esp_crt_bundle_attach;
    config.event_handler = HttpEventHandler;
    config.user_data = &response;
    config.buffer_size = 4096;
    config.buffer_size_tx = 1024;
    esp_http_client_handle_t client = esp_http_client_init(&config);
    if (!client) {
        heap_caps_free(response.data);
        ESP_LOGW(TAG, "Argus HTTP client init failed");
        return;
    }
    esp_http_client_set_method(client, HTTP_METHOD_GET);
    esp_http_client_set_header(client, "Accept", "application/json");
    esp_http_client_set_header(client, "User-Agent", "TaijiPi-ESP32/2.5.0");
    esp_err_t result = esp_http_client_perform(client);
    const int status = esp_http_client_get_status_code(client);
    const int64_t content_length = esp_http_client_get_content_length(client);
    esp_http_client_cleanup(client);

    if (result != ESP_OK || status != 200 || response.size == 0 || response.overflow) {
        ESP_LOGW(TAG, "Argus GET failed: err=%s status=%d bytes=%u expected=%lld overflow=%d",
                 esp_err_to_name(result), status, static_cast<unsigned>(response.size),
                 static_cast<long long>(content_length), response.overflow ? 1 : 0);
        heap_caps_free(response.data);
        return;
    }

    const char* array = FindRegionsArray(response.data);
    const char* array_end = FindMatchingArrayEnd(array);
    if (!array || !array_end) {
        ESP_LOGW(TAG, "Argus JSON missing alerts.regions (bytes=%u)", static_cast<unsigned>(response.size));
        heap_caps_free(response.data);
        return;
    }

    std::map<std::string, Event> fresh;
    int region_count = 0;
    int air_alert_count = 0;
    const char* p = array + 1;
    while (p < array_end) {
        while (p < array_end && (*p == ',' || *p == ' ' || *p == '\r' || *p == '\n' || *p == '\t')) ++p;
        if (p >= array_end || *p != '{') { if (p < array_end) ++p; continue; }
        const char* object_start = p;
        int depth = 0;
        bool in_string = false, escaped = false;
        for (; p < array_end; ++p) {
            const char c = *p;
            if (in_string) {
                if (escaped) escaped = false;
                else if (c == '\\') escaped = true;
                else if (c == '"') in_string = false;
                continue;
            }
            if (c == '"') in_string = true;
            else if (c == '{') ++depth;
            else if (c == '}' && --depth == 0) { ++p; break; }
        }
        if (depth != 0) break;
        cJSON* region = cJSON_ParseWithLength(object_start, static_cast<size_t>(p - object_start));
        if (!region) continue;
        ++region_count;
        cJSON* status_item = cJSON_GetObjectItemCaseSensitive(region, "status");
        cJSON* label_item = cJSON_GetObjectItemCaseSensitive(region, "label");
        cJSON* iso_item = cJSON_GetObjectItemCaseSensitive(region, "iso");
        cJSON* expiry_item = cJSON_GetObjectItemCaseSensitive(region, "expiresAt");
        if (!cJSON_IsString(status_item) || !cJSON_IsString(label_item) || strcmp(status_item->valuestring, "air_alert") != 0) {
            cJSON_Delete(region);
            continue;
        }
        ++air_alert_count;
        if (cJSON_IsString(expiry_item) && strlen(expiry_item->valuestring) >= 20) {
            const time_t now = time(nullptr);
            if (now > 1700000000) {
                struct tm utc_now = {};
                gmtime_r(&now, &utc_now);
                char now_iso[24] = {};
                strftime(now_iso, sizeof(now_iso), "%Y-%m-%dT%H:%M:%SZ", &utc_now);
                if (strncmp(expiry_item->valuestring, now_iso, 20) <= 0) { cJSON_Delete(region); continue; }
            }
        }
        // Preserve the original region parser, but collect every decoded string from
        // this alert (evidence may be a string, array, or nested object).
        std::string location_text;
        AppendJsonStrings(region, location_text);
        std::string id = cJSON_IsString(iso_item) ? iso_item->valuestring : label_item->valuestring;

        // Match every named location in the order it appears in the alert text.
        // Each distinct map coordinate gets its own event ID, so markers coexist.
        std::vector<std::pair<size_t, const MapPoint*>> matches;
        const std::string lowered_location_text = LowerUtf8(location_text);
        for (const auto& point : kMapPoints) {
            // Avoid treating generic "port" mentions as a settlement name.
            if (strcmp(point.name, "порт") == 0 || strcmp(point.name, "ferry") == 0 ||
                strcmp(point.name, "переправ") == 0 || strcmp(point.name, "Kerch Strait") == 0 ||
                strcmp(point.name, "Керченский пролив") == 0 || strcmp(point.name, "Сиваш") == 0 ||
                strcmp(point.name, "Sivash") == 0 || strcmp(point.name, "Азовское море") == 0 ||
                strcmp(point.name, "Azov Sea") == 0 || strcmp(point.name, "Тарханкут") == 0 ||
                strcmp(point.name, "Tarkhankut") == 0 || strcmp(point.name, "Ленинский район") == 0 ||
                strcmp(point.name, "Leninsky") == 0 || strcmp(point.name, "Феодосийский залив") == 0 ||
                strcmp(point.name, "Feodosia port") == 0 || strcmp(point.name, "port of Feodosia") == 0) continue;
            size_t pos = FindLocationPosition(lowered_location_text, point.name);
            if (pos != std::string::npos) matches.push_back({pos, &point});
        }
        std::sort(matches.begin(), matches.end(), [](const auto& a, const auto& b) {
            if (a.first != b.first) return a.first < b.first;
            return strlen(a.second->name) > strlen(b.second->name);
        });

        bool placed = false;
        std::vector<std::pair<int, int>> used_coordinates;
        for (const auto& match : matches) {
            const MapPoint* point = match.second;
            bool duplicate = false;
            for (const auto& xy : used_coordinates) if (xy.first == point->x && xy.second == point->y) { duplicate = true; break; }
            if (duplicate) continue;
            used_coordinates.push_back({point->x, point->y});
            Event e; e.id = id + ":" + std::to_string(point->x) + ":" + std::to_string(point->y);
            e.x = point->x; e.y = point->y; e.threat_type = "region"; e.status = "active";
            fresh[e.id] = e;
            placed = true;
            // Short Latin-only log; avoid extra serial output.
            bool logged = false;
            for (const auto& alias : kMapPoints) {
                if (alias.x != point->x || alias.y != point->y) continue;
                bool latin = true;
                for (const unsigned char* q = reinterpret_cast<const unsigned char*>(alias.name); *q; ++q) if (*q >= 128) { latin = false; break; }
                if (latin) { ESP_LOGI(TAG, "Argus map: %s", alias.name); logged = true; break; }
            }
            if (!logged) ESP_LOGI(TAG, "Argus map: Crimea");
        }
        if (!placed && (id == "UA-43" || ContainsNoCase(label_item->valuestring, "Crimea") || ContainsNoCase(label_item->valuestring, "Крым"))) {
            Event e; e.id = id + ":127:228"; e.x = 127; e.y = 228; e.threat_type = "region"; e.status = "active";
            fresh[e.id] = e;
            ESP_LOGI(TAG, "Argus map: Simferopol");
        }
        cJSON_Delete(region);
    }
    heap_caps_free(response.data);

    // A valid empty regions array means no active regional alerts: clear markers.
    { std::lock_guard<std::mutex> guard(events_mutex_); events_.swap(fresh); }
    if (visible_) RedrawMarkers();
    (void)region_count;
    (void)air_alert_count;
}

void DroneMap::PollTask(void* arg) {
    auto* self = static_cast<DroneMap*>(arg);
    // The polling task exists only while the map is visible. This releases its
    // 8 KB task stack when the user returns to the assistant.
    while (self && self->poll_running_ && self->visible_) {
        for (uint32_t elapsed = 0; elapsed < kPollIntervalMs && self->poll_running_ && self->visible_; elapsed += 250) {
            vTaskDelay(pdMS_TO_TICKS(250));
        }
        if (self->poll_running_ && self->visible_) self->FetchArgus();
    }
    if (self) {
        self->poll_running_ = false;
        self->poll_task_ = nullptr;
    }
    vTaskDelete(nullptr);
}

bool DroneMap::Show() {
    EnsureUi();
    if (!root_) return false;
    visible_ = true;
    { DisplayLockGuard lock(Board::GetInstance().GetDisplay()); if (!lock) return false; lv_obj_remove_flag(root_, LV_OBJ_FLAG_HIDDEN); }
    RedrawMarkers();
    poll_running_ = true;
    if (!poll_task_) {
        if (xTaskCreate(PollTask, "argus_map", 8192, this, 3, &poll_task_) != pdPASS) poll_task_ = nullptr;
    }
    FetchArgus();
    return true;
}

void DroneMap::Hide() {
    visible_ = false;
    poll_running_ = false;

    // Drop cached markers and the map's LVGL object tree when leaving the map.
    // The image itself is compiled into flash; it will be recreated on next Show().
    auto display = Board::GetInstance().GetDisplay();
    if (root_ && display) {
        DisplayLockGuard lock(display);
        if (lock) {
            lv_obj_delete(root_);
            root_ = nullptr;
            map_image_ = nullptr;
            markers_layer_ = nullptr;
        }
    }
    {
        std::lock_guard<std::mutex> guard(events_mutex_);
        events_.clear();
    }
}

bool DroneMap::TouchDown(int x, int y) { touch_down_ = true; touch_start_x_ = x; touch_start_y_ = y; return visible_; }
bool DroneMap::TouchMove(int, int) { return touch_down_ && visible_; }
bool DroneMap::TouchUp(int x, int y) {
    if (!touch_down_) return false;
    touch_down_ = false;
    const int dx = x - touch_start_x_, dy = y - touch_start_y_;
    if (!visible_) {
        if (dx < -kSwipeThreshold && std::abs(dx) > std::abs(dy)) { Show(); return true; }
        return false;
    }
    if (touch_start_x_ < 80 && dx > kSwipeThreshold && std::abs(dx) > std::abs(dy)) { Hide(); return true; }
    return true;
}

void DroneMap::RegisterTool() {
    auto& mcp = McpServer::GetInstance();
    mcp.AddTool("self.drone_map.show",
        "Show the Crimea live regional alert map. Use for requests such as: 'включи карту дронов', 'покажи карту дронов'.",
        PropertyList(), [this](const PropertyList&) -> ReturnValue { return Show(); });
}

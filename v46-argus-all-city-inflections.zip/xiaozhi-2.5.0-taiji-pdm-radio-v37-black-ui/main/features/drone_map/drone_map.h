#pragma once

#include <atomic>
#include <map>
#include <mutex>
#include <string>
#include <vector>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <lvgl.h>

class DroneMap {
public:
    DroneMap();
    ~DroneMap();
    bool Show();
    void Hide();
    bool IsVisible() const { return visible_; }
    bool TouchDown(int x, int y);
    bool TouchMove(int x, int y);
    bool TouchUp(int x, int y);
private:
    struct Event { std::string id; std::string threat_type; std::string status; int x = 0; int y = 0; };
    lv_obj_t* root_ = nullptr;
    lv_obj_t* map_image_ = nullptr;
    lv_obj_t* markers_layer_ = nullptr;
    std::map<std::string, Event> events_;
    mutable std::mutex events_mutex_;
    std::atomic<bool> visible_{false};
    bool touch_down_ = false;
    std::atomic<bool> poll_running_{false};
    int touch_start_x_ = 0;
    int touch_start_y_ = 0;
    TaskHandle_t poll_task_ = nullptr;
    void EnsureUi();
    void RedrawMarkers();
    void FetchArgus();
    void RegisterTool();
    static void PollTask(void* arg);
};

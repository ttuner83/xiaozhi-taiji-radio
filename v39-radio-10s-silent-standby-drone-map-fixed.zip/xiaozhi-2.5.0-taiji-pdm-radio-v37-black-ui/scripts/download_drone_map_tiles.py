#!/usr/bin/env python3
import pathlib
import time
import urllib.request

OUT = pathlib.Path("main/features/drone_map/generated_tiles.h")
BASE = "https://a.tile.opentopomap.org/8/{x}/{y}.png"
UA = "xiaozhi-taiji-drone-map/1.0"

with OUT.open("w", encoding="utf-8") as f:
    f.write("// Auto-generated during GitHub Actions build. Do not edit.\n#pragma once\n#include <cstdint>\n#include <cstddef>\n\n")
    for y in range(90, 94):
        for x in range(151, 155):
            url = BASE.format(x=x, y=y)
            req = urllib.request.Request(url, headers={"User-Agent": UA})
            print("Downloading", url, flush=True)
            with urllib.request.urlopen(req, timeout=30) as r:
                data = r.read()
            if not data.startswith(b"\x89PNG\r\n\x1a\n"):
                raise RuntimeError(f"Not a PNG: {url}")
            f.write(f"static const uint8_t drone_tile_{x}_{y}[] = {{\n")
            for i in range(0, len(data), 16):
                f.write("  " + ", ".join(f"0x{b:02x}" for b in data[i:i+16]) + ",\n")
            f.write("};\n\n")
            time.sleep(0.15)
print("Wrote", OUT)

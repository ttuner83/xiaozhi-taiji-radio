#include "taiji_web_radio.h"

#include "application.h"
#include "board.h"
#include "settings.h"
#include "mcp_server.h"

#include <algorithm>
#include <cstring>
#include <cstdlib>

#include <cJSON.h>
#include <esp_wifi.h>
#include <esp_log.h>

#define TAG "TaijiWebRadio"
#define MAX_STATIONS 8
// Keep Wi-Fi awake while either the radio or the voice assistant is active.
// In idle state, return to modem-sleep so the device can wait for the wake word
// with lower Wi-Fi power consumption.
void TaijiWebRadio::UpdateWifiPowerSave() {
    const bool radio_active = instance_ != nullptr && instance_->IsRadioActive();
    const auto state = Application::GetInstance().GetDeviceState();
    // Only the idle state is allowed to use Wi-Fi modem-sleep. All other
    // application states keep Wi-Fi awake because they may involve network
    // activity or audio playback/recording.
    const bool assistant_active = state != kDeviceStateIdle;

    const wifi_ps_type_t target = (radio_active || assistant_active)
        ? WIFI_PS_NONE
        : WIFI_PS_MIN_MODEM;

    static wifi_ps_type_t last_mode = WIFI_PS_MAX_MODEM;
    if (target != last_mode) {
        esp_err_t err = esp_wifi_set_ps(target);
        if (err == ESP_OK) {
            last_mode = target;
            ESP_LOGI(TAG, "Wi-Fi power save: %s",
                     target == WIFI_PS_NONE ? "NONE" : "MIN_MODEM");
        } else {
            ESP_LOGW(TAG, "Failed to set Wi-Fi power save mode %d: %s",
                     (int)target, esp_err_to_name(err));
        }
    }
}

TaijiWebRadio* TaijiWebRadio::instance_ = nullptr;

bool TaijiWebRadio::IsActive() {
    return instance_ != nullptr && instance_->IsRadioActive();
}

static const char kHtml[] = R"HTML(
<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Taiji Pi Radio</title>
<style>
body{font-family:Arial,sans-serif;max-width:760px;margin:20px auto;padding:0 12px;background:#f4f4f4;color:#222}
h2{margin-bottom:8px}.card{background:#fff;padding:14px;margin:10px 0;border-radius:10px}
input,select,button{font-size:16px;padding:9px;margin:4px 0;box-sizing:border-box}
input{width:100%}button{cursor:pointer}.row{display:flex;gap:8px;flex-wrap:wrap}.row button{flex:1}
small{color:#666;word-break:break-all}.playing{font-weight:bold}
</style></head><body>
<h2>Taiji Pi S3 — Internet Radio</h2>
<div class="card"><div id="list">Загрузка...</div></div>
<div class="card"><b>Добавить / изменить станцию</b>
<input id="slot" type="number" min="0" max="7" value="0" placeholder="Номер 0..7">
<input id="name" placeholder="Название станции">
<input id="url" placeholder="http://... или https://...">
<select id="type"><option value="mp3">MP3</option><option value="aac">AAC</option><option value="ogg">OGG/Opus</option><option value="wav">WAV</option></select>
<div class="row"><button onclick="save()">Сохранить</button><button onclick="stop()">Стоп</button></div>
</div>
<script>
async function load(){
 let r=await fetch('/api/radios'); let a=await r.json();
 let h='';
 a.forEach((x,i)=>{if(!x.url)return;
 h+=`<div class="card"><b>${i}: ${esc(x.name||'Без названия')}</b><br><small>${esc(x.url)} [${esc(x.type||'mp3')}]</small>
 <div class="row"><button onclick="play(${i})">▶ Играть</button><button onclick="edit(${i})">Изменить</button><button onclick="del(${i})">Удалить</button></div></div>`});
 document.getElementById('list').innerHTML=h||'Станций пока нет';
}
function esc(s){return String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]))}
async function save(){
 let o={slot:+slot.value,name:name.value,url:url.value,type:type.value};
 await fetch('/api/radios',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(o)});
 load();
}
async function play(i){await fetch('/api/play?slot='+i);load()}
async function stop(){await fetch('/api/stop')}
async function del(i){await fetch('/api/radios',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({slot:i,delete:true})});load()}
async function edit(i){
 let a=await (await fetch('/api/radios')).json(),x=a[i];
 slot.value=i;name.value=x.name||'';url.value=x.url||'';type.value=x.type||'mp3';
}
load();
</script></body></html>
)HTML";

static bool ReadBody(httpd_req_t* req, std::string& body) {
    if (req->content_len <= 0 || req->content_len > 4096) {
        return false;
    }
    body.resize(req->content_len);
    size_t received = 0;
    while (received < body.size()) {
        int ret = httpd_req_recv(req, body.data() + received, body.size() - received);
        if (ret <= 0) {
            return false;
        }
        received += ret;
    }
    return true;
}

TaijiWebRadio::TaijiWebRadio() {
    instance_ = this;
    radio_.Initialize();
    LoadStations();

    auto& mcp = McpServer::GetInstance();
    mcp.AddTool("self.radio.play",
        "Start the selected saved Internet radio station. Use for requests such as: 'Включи радио', 'Запусти радио'.",
        PropertyList(),
        [this](const PropertyList&) -> ReturnValue { return PlaySelected(); });
    mcp.AddTool("self.radio.play_station",
        "Start a saved Internet radio station by number. The user-visible station numbers start at 1. Use for requests such as: 'Включи станцию 4', 'Запусти станцию номер 4'.",
        PropertyList({Property("station", kPropertyTypeInteger, 1, 1, MAX_STATIONS)}),
        [this](const PropertyList& properties) -> ReturnValue {
            return PlayStation(properties["station"].value<int>());
        });
    mcp.AddTool("self.radio.next",
        "Switch to the next configured Internet radio station and start it. Use for requests such as: 'Следующая радиостанция', 'Переключи радио'.",
        PropertyList(),
        [this](const PropertyList&) -> ReturnValue { return NextStation(); });
    mcp.AddTool("self.radio.stop",
        "Stop Internet radio playback. Use for requests such as: 'Выключи радио', 'Останови радио'.",
        PropertyList(),
        [this](const PropertyList&) -> ReturnValue { return StopPlayback(); });
    mcp.AddTool("self.radio.get_volume",
        "Get ONLY the independent Internet radio volume (0-100%). This is separate from self.audio_speaker.set_volume. Use for radio volume requests such as 'громкость радио', 'радио громче' or 'радио тише'.",
        PropertyList(),
        [this](const PropertyList&) -> ReturnValue { return radio_.GetVolume(); });
    mcp.AddTool("self.radio.set_volume",
        "Set ONLY the independent Internet radio volume from 0 to 100%. NEVER use self.audio_speaker.set_volume for this. Use this tool when the user says 'громкость радио 30%', 'радио 30%', 'громкость радио', 'сделай радио тише' or 'сделай радио громче'. This must not change the voice assistant volume.",
        PropertyList({Property("volume", kPropertyTypeInteger, 20, 0, 100)}),
        [this](const PropertyList& properties) -> ReturnValue {
            radio_.SetVolume(properties["volume"].value<int>());
            return true;
        });
}

TaijiWebRadio::~TaijiWebRadio() {
    Stop();
    if (instance_ == this) {
        instance_ = nullptr;
    }
}

void TaijiWebRadio::LoadStations() {
    stations_.clear();
    stations_.resize(MAX_STATIONS);
    Settings settings("radio", false);
    struct Preset { const char* name; const char* url; const char* type; };
    static const Preset presets[MAX_STATIONS] = {
        {"Европа Плюс", "http://emgregion.hostingradio.ru:8064/moscow.europaplus.mp3", "mp3"},
        {"Рок Классик", "https://strm112.1.fm/rockclassics_mobile_mp3", "mp3"},
        {"Кассета Диско", "https://casseta-disco.ru:1090/stream", "mp3"},
        {"Рок Атака", "https://listen7.myradio24.com/rockataka", "mp3"},
        {"Максимус Рок", "https://maximusrockfm.stream.laut.fm/maximusrockfm", "mp3"},
        {"Рок Арсенал", "https://online.rockarsenal.ru/rockwotalk?5423", "mp3"},
        {"Наше Рок", "https://nashe1.hostingradio.ru/nasheclassic.mp3", "mp3"},
        {"Мелодия", "http://stream128.melodiafm.spb.ru:8000/melodia128", "mp3"},
    };
    for (int i = 0; i < MAX_STATIONS; ++i) {
        std::string key = "r" + std::to_string(i);
        std::string value = settings.GetString(key, "");
        if (value.empty()) {
            stations_[i].name = presets[i].name;
            stations_[i].url = presets[i].url;
            stations_[i].type = presets[i].type;
            continue;
        }
        cJSON* obj = cJSON_Parse(value.c_str());
        if (!obj) {
            continue;
        }
        auto get = [&](const char* key) -> std::string {
            cJSON* item = cJSON_GetObjectItemCaseSensitive(obj, key);
            return cJSON_IsString(item) ? item->valuestring : "";
        };
        stations_[i].name = get("name");
        if (stations_[i].name.empty()) {
            stations_[i].name = settings.GetString("n" + std::to_string(i), "");
        }
        stations_[i].url = get("url");
        stations_[i].type = get("type");
        if (stations_[i].type.empty()) {
            stations_[i].type = "mp3";
        }
        cJSON_Delete(obj);
    }

    // Migrate only the old built-in defaults saved by earlier firmware.
    // User-customized stations are left untouched.
    struct Migration { int slot; const char* old_name; const char* old_url; const char* new_name; const char* new_url; };
    static const Migration migrations[] = {
        {0, "Мелодия", "http://stream128.melodiafm.spb.ru:8000/melodia128", "Европа Плюс", "http://emgregion.hostingradio.ru:8064/moscow.europaplus.mp3"},
        {1, "Европа Плюс", "http://emgregion.hostingradio.ru:8064/moscow.europaplus.mp3", "Рок Классик", "https://strm112.1.fm/rockclassics_mobile_mp3"},
        {2, "Радио Рекорд", "http://online.radiorecord.ru:8102/sd90_128", "Кассета Диско", "https://casseta-disco.ru:1090/stream"},
        {6, "Мелодия", "http://stream128.melodiafm.spb.ru:8000/melodia128", "Наше Рок", "https://nashe1.hostingradio.ru/nasheclassic.mp3"},
        {7, "Наше Рок", "https://nashe1.hostingradio.ru/nasheclassic.mp3", "Мелодия", "http://stream128.melodiafm.spb.ru:8000/melodia128"},
    };
    for (const auto& m : migrations) {
        if (stations_[m.slot].name == m.old_name && stations_[m.slot].url == m.old_url) {
            Station station;
            station.name = m.new_name;
            station.url = m.new_url;
            station.type = "mp3";
            SaveStation(m.slot, station);
        }
    }
}

void TaijiWebRadio::SaveStation(int slot, const Station& station) {
    if (slot < 0 || slot >= MAX_STATIONS) {
        return;
    }
    cJSON* obj = cJSON_CreateObject();
    cJSON_AddStringToObject(obj, "name", station.name.c_str());
    cJSON_AddStringToObject(obj, "url", station.url.c_str());
    cJSON_AddStringToObject(obj, "type", station.type.c_str());
    char* text = cJSON_PrintUnformatted(obj);
    Settings settings("radio", true);
    settings.SetString("r" + std::to_string(slot), text ? text : "");
    settings.SetString("n" + std::to_string(slot), station.name);
    if (text) {
        cJSON_free(text);
    }
    cJSON_Delete(obj);
    stations_[slot] = station;
}

void TaijiWebRadio::ClearStation(int slot) {
    if (slot < 0 || slot >= MAX_STATIONS) {
        return;
    }
    Settings settings("radio", true);
    settings.EraseKey("r" + std::to_string(slot));
    settings.EraseKey("n" + std::to_string(slot));
    stations_[slot] = Station{};
}

void TaijiWebRadio::Start() {
    if (server_) {
        return;
    }

    httpd_config_t config = HTTPD_DEFAULT_CONFIG();
    config.server_port = 80;
    config.max_uri_handlers = 12;
    config.stack_size = 8192;

    if (httpd_start(&server_, &config) != ESP_OK) {
        server_ = nullptr;
        ESP_LOGE(TAG, "Failed to start HTTP server");
        return;
    }

    httpd_uri_t root = {.uri = "/", .method = HTTP_GET, .handler = RootHandler, .user_ctx = this};
    httpd_uri_t get = {.uri = "/api/radios", .method = HTTP_GET, .handler = StationsGetHandler, .user_ctx = this};
    httpd_uri_t post = {.uri = "/api/radios", .method = HTTP_POST, .handler = StationsPostHandler, .user_ctx = this};
    httpd_uri_t play = {.uri = "/api/play", .method = HTTP_GET, .handler = PlayHandler, .user_ctx = this};
    httpd_uri_t stop = {.uri = "/api/stop", .method = HTTP_GET, .handler = StopHandler, .user_ctx = this};

    httpd_register_uri_handler(server_, &root);
    httpd_register_uri_handler(server_, &get);
    httpd_register_uri_handler(server_, &post);
    httpd_register_uri_handler(server_, &play);
    httpd_register_uri_handler(server_, &stop);

    ESP_LOGI(TAG, "Local radio server started");
}

bool TaijiWebRadio::PlaySelected() {
    int slot = current_slot_;
    if (slot < 0 || slot >= MAX_STATIONS || stations_[slot].url.empty()) {
        slot = -1;
        for (int i = 0; i < MAX_STATIONS; ++i) {
            if (!stations_[i].url.empty()) {
                slot = i;
                break;
            }
        }
    }
    if (slot < 0) {
        return false;
    }
    StartRadio(slot);
    return true;
}

bool TaijiWebRadio::PlayStation(int station_number) {
    const int slot = station_number - 1;
    if (station_number < 1 || station_number > MAX_STATIONS ||
        stations_[slot].url.empty()) {
        ESP_LOGW(TAG, "Station number %d is not configured", station_number);
        return false;
    }
    StartRadio(slot);
    return current_slot_ == slot && (radio_.IsPlaying() || radio_.IsDownloading());
}

bool TaijiWebRadio::NextStation() {
    int start = current_slot_;
    if (start < 0 || start >= MAX_STATIONS) {
        start = -1;
    }
    for (int n = 1; n <= MAX_STATIONS; ++n) {
        int slot = (start + n) % MAX_STATIONS;
        if (!stations_[slot].url.empty()) {
            StartRadio(slot);
            return true;
        }
    }
    return false;
}

bool TaijiWebRadio::StopPlayback() {
    StopRadio();
    return true;
}

void TaijiWebRadio::Stop() {
    StopRadio();
    if (server_) {
        httpd_stop(server_);
        server_ = nullptr;
    }
}

esp_err_t TaijiWebRadio::RootHandler(httpd_req_t* req) {
    return static_cast<TaijiWebRadio*>(req->user_ctx)->HandleRoot(req);
}
esp_err_t TaijiWebRadio::StationsGetHandler(httpd_req_t* req) {
    return static_cast<TaijiWebRadio*>(req->user_ctx)->HandleStationsGet(req);
}
esp_err_t TaijiWebRadio::StationsPostHandler(httpd_req_t* req) {
    return static_cast<TaijiWebRadio*>(req->user_ctx)->HandleStationsPost(req);
}
esp_err_t TaijiWebRadio::PlayHandler(httpd_req_t* req) {
    return static_cast<TaijiWebRadio*>(req->user_ctx)->HandlePlay(req);
}
esp_err_t TaijiWebRadio::StopHandler(httpd_req_t* req) {
    return static_cast<TaijiWebRadio*>(req->user_ctx)->HandleStop(req);
}

esp_err_t TaijiWebRadio::HandleRoot(httpd_req_t* req) {
    httpd_resp_set_type(req, "text/html; charset=utf-8");
    return httpd_resp_send(req, kHtml, HTTPD_RESP_USE_STRLEN);
}

esp_err_t TaijiWebRadio::HandleStationsGet(httpd_req_t* req) {
    cJSON* array = cJSON_CreateArray();
    for (int i = 0; i < MAX_STATIONS; ++i) {
        cJSON* obj = cJSON_CreateObject();
        cJSON_AddNumberToObject(obj, "slot", i);
        cJSON_AddStringToObject(obj, "name", stations_[i].name.c_str());
        cJSON_AddStringToObject(obj, "url", stations_[i].url.c_str());
        cJSON_AddStringToObject(obj, "type", stations_[i].type.c_str());
        cJSON_AddBoolToObject(obj, "playing", current_slot_ == i && radio_.IsPlaying());
        cJSON_AddItemToArray(array, obj);
    }
    char* text = cJSON_PrintUnformatted(array);
    cJSON_Delete(array);
    httpd_resp_set_type(req, "application/json");
    esp_err_t ret = httpd_resp_send(req, text ? text : "[]", HTTPD_RESP_USE_STRLEN);
    if (text) {
        cJSON_free(text);
    }
    return ret;
}

esp_err_t TaijiWebRadio::HandleStationsPost(httpd_req_t* req) {
    std::string body;
    if (!ReadBody(req, body)) {
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Invalid body");
        return ESP_OK;
    }
    cJSON* obj = cJSON_Parse(body.c_str());
    if (!obj) {
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Invalid JSON");
        return ESP_OK;
    }

    cJSON* slot_item = cJSON_GetObjectItem(obj, "slot");
    int slot = cJSON_IsNumber(slot_item) ? slot_item->valueint : -1;
    cJSON* del = cJSON_GetObjectItem(obj, "delete");
    if (cJSON_IsTrue(del)) {
        StopRadio();
        ClearStation(slot);
    } else {
        cJSON* name = cJSON_GetObjectItem(obj, "name");
        cJSON* url = cJSON_GetObjectItem(obj, "url");
        cJSON* type = cJSON_GetObjectItem(obj, "type");
        if (slot < 0 || slot >= MAX_STATIONS || !cJSON_IsString(url)) {
            cJSON_Delete(obj);
            httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Invalid station");
            return ESP_OK;
        }
        Station station;
        station.name = cJSON_IsString(name) ? name->valuestring : "";
        station.url = url->valuestring;
        station.type = cJSON_IsString(type) ? type->valuestring : "mp3";
        if (station.url.size() > 400 || station.name.size() > 80) {
            cJSON_Delete(obj);
            httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Too long");
            return ESP_OK;
        }
        if (station.type != "mp3" && station.type != "aac" &&
            station.type != "ogg" && station.type != "wav") {
            station.type = "mp3";
        }
        SaveStation(slot, station);
    }
    cJSON_Delete(obj);
    httpd_resp_set_type(req, "application/json");
    return httpd_resp_sendstr(req, "{\"ok\":true}");
}

esp_err_t TaijiWebRadio::HandlePlay(httpd_req_t* req) {
    char query[64];
    char value[16];
    if (httpd_req_get_url_query_str(req, query, sizeof(query)) != ESP_OK ||
        httpd_query_key_value(query, "slot", value, sizeof(value)) != ESP_OK) {
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "slot required");
        return ESP_OK;
    }
    int slot = atoi(value);
    if (slot < 0 || slot >= MAX_STATIONS || stations_[slot].url.empty()) {
        httpd_resp_send_err(req, HTTPD_404_NOT_FOUND, "Station not found");
        return ESP_OK;
    }
    StartRadio(slot);
    return httpd_resp_sendstr(req, "{\"ok\":true}");
}

esp_err_t TaijiWebRadio::HandleStop(httpd_req_t* req) {
    StopRadio();
    return httpd_resp_sendstr(req, "{\"ok\":true}");
}

void TaijiWebRadio::StartRadio(int slot) {
    if (slot < 0 || slot >= MAX_STATIONS || stations_[slot].url.empty()) {
        return;
    }

    // Spotpear-style backend: PlayUrl() serializes lifecycle operations with a
    // control mutex and joins the old download/playback threads before a new
    // stream is started. Station numbers and the web UI remain our own layer.
    if (!radio_.PlayUrl(stations_[slot].url, stations_[slot].name)) {
        ESP_LOGE(TAG, "Failed to start station %d: %s", slot + 1, stations_[slot].url.c_str());
        current_slot_ = -1;
        UpdateWifiPowerSave();
        return;
    }

    current_slot_ = slot;
    ESP_LOGI(TAG, "Starting station %d: %s", slot + 1, stations_[slot].url.c_str());
    UpdateWifiPowerSave();
}

bool TaijiWebRadio::StopRadio() {
    const bool active = radio_.IsPlaying() || radio_.IsDownloading();
    if (active) {
        ESP_LOGI(TAG, "Stopping radio through Spotpear-style backend");
    }
    const bool stopped = radio_.Stop();
    current_slot_ = -1;
    UpdateWifiPowerSave();
    return stopped;
}

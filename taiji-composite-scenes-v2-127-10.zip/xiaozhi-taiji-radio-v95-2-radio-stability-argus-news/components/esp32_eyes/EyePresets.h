/***************************************************
Copyright (c) 2023 Alastair Aitchison, Playful Technology, 2020 Luis Llamas (www.luisllamas.es)

This program is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by
the Free Software Foundation, either version 3 of the License, or (at your option) any later version. 

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License along with this program.  If not, see <http://www.gnu.org/licenses 
****************************************************/

/**
 * EyePresets.h
 * EMO-inspired eye geometry: wide soft-cornered eyes and more legible eyelid silhouettes.
 */

#ifndef _EYEPRESETS_h
#define _EYEPRESETS_h

#include <Arduino.h>
#include "EyeConfig.h"

static const EyeConfig Preset_Normal = {
	.OffsetX = 0,
	.OffsetY = 0,
	.Height = 40,
	.Width = 44,
	.Slope_Top = 0,
	.Slope_Bottom = 0,
	.Radius_Top = 13,
	.Radius_Bottom = 13,
	.Inverse_Radius_Top = 0,
	.Inverse_Radius_Bottom = 0,
	.Inverse_Offset_Top = 0,
	.Inverse_Offset_Bottom = 0
};

static const EyeConfig Preset_Happy = {
	.OffsetX = 0,
	.OffsetY = 0,
	.Height = 18,
	.Width = 44,
	.Slope_Top = 0,
	.Slope_Bottom = 0,
	.Radius_Top = 12,
	.Radius_Bottom = 10,
	.Inverse_Radius_Top = 0,
	.Inverse_Radius_Bottom = 0,
	.Inverse_Offset_Top = 0,
	.Inverse_Offset_Bottom = 0
};

static const EyeConfig Preset_Glee = {
	.OffsetX = 0,
	.OffsetY = 0,
	.Height = 14,
	.Width = 44,
	.Slope_Top = 0,
	.Slope_Bottom = 0,
	.Radius_Top = 10,
	.Radius_Bottom = 8,
	.Inverse_Radius_Top = 0,
	.Inverse_Radius_Bottom = 5,
	.Inverse_Offset_Top = 0,
	.Inverse_Offset_Bottom = 0
};

static const EyeConfig Preset_Sad = {
	.OffsetX = 0,
	.OffsetY = 0,
	.Height = 24,
	.Width = 44,
	.Slope_Top = -0.35,
	.Slope_Bottom = 0,
	.Radius_Top = 5,
	.Radius_Bottom = 13,
	.Inverse_Radius_Top = 0,
	.Inverse_Radius_Bottom = 0,
	.Inverse_Offset_Top = 0,
	.Inverse_Offset_Bottom = 0
};

static const EyeConfig Preset_Worried = {
	.OffsetX = 0,
	.OffsetY = 0,
	.Height = 32,
	.Width = 44,
	.Slope_Top = -0.15,
	.Slope_Bottom = 0,
	.Radius_Top = 11,
	.Radius_Bottom = 13,
	.Inverse_Radius_Top = 0,
	.Inverse_Radius_Bottom = 0,
	.Inverse_Offset_Top = 0,
	.Inverse_Offset_Bottom = 0
};

static const EyeConfig Preset_Worried_Alt = {
	.OffsetX = 0,
	.OffsetY = 0,
	.Height = 36,
	.Width = 44,
	.Slope_Top = -0.2,
	.Slope_Bottom = 0,
	.Radius_Top = 11,
	.Radius_Bottom = 13,
	.Inverse_Radius_Top = 0,
	.Inverse_Radius_Bottom = 0,
	.Inverse_Offset_Top = 0,
	.Inverse_Offset_Bottom = 0
};

static const EyeConfig Preset_Focused = {
	.OffsetX = 0,
	.OffsetY = 0,
	.Height = 22,
	.Width = 44,
	.Slope_Top = 0.22,
	.Slope_Bottom = 0,
	.Radius_Top = 8,
	.Radius_Bottom = 8,
	.Inverse_Radius_Top = 0,
	.Inverse_Radius_Bottom = 0,
	.Inverse_Offset_Top = 0,
	.Inverse_Offset_Bottom = 0
};

static const EyeConfig Preset_Annoyed = {
	.OffsetX = 0,
	.OffsetY = 0,
	.Height = 17,
	.Width = 44,
	.Slope_Top = 0,
	.Slope_Bottom = 0,
	.Radius_Top = 4,
	.Radius_Bottom = 12,
	.Inverse_Radius_Top = 0,
	.Inverse_Radius_Bottom = 0,
	.Inverse_Offset_Top = 0,
	.Inverse_Offset_Bottom = 0
};

static const EyeConfig Preset_Annoyed_Alt = {
	.OffsetX = 0,
	.OffsetY = 0,
	.Height = 12,
	.Width = 44,
	.Slope_Top = 0,
	.Slope_Bottom = 0,
	.Radius_Top = 4,
	.Radius_Bottom = 9,
	.Inverse_Radius_Top = 0,
	.Inverse_Radius_Bottom = 0,
	.Inverse_Offset_Top = 0,
	.Inverse_Offset_Bottom = 0
};

static const EyeConfig Preset_Surprised = {
	.OffsetX = -2,
	.OffsetY = 0,
	.Height = 44,
	.Width = 46,
	.Slope_Top = 0,
	.Slope_Bottom = 0,
	.Radius_Top = 18,
	.Radius_Bottom = 18,
	.Inverse_Radius_Top = 0,
	.Inverse_Radius_Bottom = 0,
	.Inverse_Offset_Top = 0,
	.Inverse_Offset_Bottom = 0
};

static const EyeConfig Preset_Skeptic = {
	.OffsetX = 0,
	.OffsetY = 0,
	.Height = 38,
	.Width = 44,
	.Slope_Top = 0,
	.Slope_Bottom = 0,
	.Radius_Top = 13,
	.Radius_Bottom = 13,
	.Inverse_Radius_Top = 0,
	.Inverse_Radius_Bottom = 0,
	.Inverse_Offset_Top = 0,
	.Inverse_Offset_Bottom = 0
};

static const EyeConfig Preset_Skeptic_Alt = {
	.OffsetX = 0,
	.OffsetY = -6,
	.Height = 28,
	.Width = 44,
	.Slope_Top = 0.32,
	.Slope_Bottom = 0,
	.Radius_Top = 5,
	.Radius_Bottom = 12,
	.Inverse_Radius_Top = 0,
	.Inverse_Radius_Bottom = 0,
	.Inverse_Offset_Top = 0,
	.Inverse_Offset_Bottom = 0
};

static const EyeConfig Preset_Frustrated = {
	.OffsetX = 3,
	.OffsetY = -5,
	.Height = 16,
	.Width = 44,
	.Slope_Top = 0,
	.Slope_Bottom = 0,
	.Radius_Top = 4,
	.Radius_Bottom = 12,
	.Inverse_Radius_Top = 0,
	.Inverse_Radius_Bottom = 0,
	.Inverse_Offset_Top = 0,
	.Inverse_Offset_Bottom = 0
};

static const EyeConfig Preset_Unimpressed = {
	.OffsetX = 3,
	.OffsetY = 0,
	.Height = 18,
	.Width = 44,
	.Slope_Top = 0,
	.Slope_Bottom = 0,
	.Radius_Top = 5,
	.Radius_Bottom = 12,
	.Inverse_Radius_Top = 0,
	.Inverse_Radius_Bottom = 0,
	.Inverse_Offset_Top = 0,
	.Inverse_Offset_Bottom = 0
};

static const EyeConfig Preset_Unimpressed_Alt = {
	.OffsetX = 3,
	.OffsetY = -3,
	.Height = 24,
	.Width = 44,
	.Slope_Top = 0,
	.Slope_Bottom = 0,
	.Radius_Top = 5,
	.Radius_Bottom = 15,
	.Inverse_Radius_Top = 0,
	.Inverse_Radius_Bottom = 0,
	.Inverse_Offset_Top = 0,
	.Inverse_Offset_Bottom = 0
};

static const EyeConfig Preset_Sleepy = {
	.OffsetX = 0,
	.OffsetY = -2,
	.Height = 20,
	.Width = 44,
	.Slope_Top = -0.25,
	.Slope_Bottom = -0.25,
	.Radius_Top = 8,
	.Radius_Bottom = 8,
	.Inverse_Radius_Top = 0,
	.Inverse_Radius_Bottom = 0,
	.Inverse_Offset_Top = 0,
	.Inverse_Offset_Bottom = 0
};

static const EyeConfig Preset_Sleepy_Alt = {
	.OffsetX = 0,
	.OffsetY = -2,
	.Height = 13,
	.Width = 44,
	.Slope_Top = -0.25,
	.Slope_Bottom = -0.25,
	.Radius_Top = 7,
	.Radius_Bottom = 7,
	.Inverse_Radius_Top = 0,
	.Inverse_Radius_Bottom = 0,
	.Inverse_Offset_Top = 0,
	.Inverse_Offset_Bottom = 0
};

static const EyeConfig Preset_Suspicious = {
	.OffsetX = 0,
	.OffsetY = 0,
	.Height = 26,
	.Width = 44,
	.Slope_Top = 0,
	.Slope_Bottom = 0,
	.Radius_Top = 12,
	.Radius_Bottom = 6,
	.Inverse_Radius_Top = 0,
	.Inverse_Radius_Bottom = 0,
	.Inverse_Offset_Top = 0,
	.Inverse_Offset_Bottom = 0
};

static const EyeConfig Preset_Suspicious_Alt = {
	.OffsetX = 0,
	.OffsetY = -3,
	.Height = 20,
	.Width = 44,
	.Slope_Top = 0.2,
	.Slope_Bottom = 0,
	.Radius_Top = 10,
	.Radius_Bottom = 5,
	.Inverse_Radius_Top = 0,
	.Inverse_Radius_Bottom = 0,
	.Inverse_Offset_Top = 0,
	.Inverse_Offset_Bottom = 0
};

static const EyeConfig Preset_Squint = {
	.OffsetX = -10,
	.OffsetY = -3,
	.Height = 36,
	.Width = 38,
	.Slope_Top = 0,
	.Slope_Bottom = 0,
	.Radius_Top = 12,
	.Radius_Bottom = 12,
	.Inverse_Radius_Top = 0,
	.Inverse_Radius_Bottom = 0,
	.Inverse_Offset_Top = 0,
	.Inverse_Offset_Bottom = 0
};

static const EyeConfig Preset_Squint_Alt = {
	.OffsetX = 5,
	.OffsetY = 0,
	.Height = 25,
	.Width = 25,
	.Slope_Top = 0,
	.Slope_Bottom = 0,
	.Radius_Top = 8,
	.Radius_Bottom = 8,
	.Inverse_Radius_Top = 0,
	.Inverse_Radius_Bottom = 0,
	.Inverse_Offset_Top = 0,
	.Inverse_Offset_Bottom = 0
};

static const EyeConfig Preset_Angry = {
	.OffsetX = -3,
	.OffsetY = 0,
	.Height = 24,
	.Width = 44,
	.Slope_Top = 0.34,
	.Slope_Bottom = 0,
	.Radius_Top = 4,
	.Radius_Bottom = 13,
	.Inverse_Radius_Top = 0,
	.Inverse_Radius_Bottom = 0,
	.Inverse_Offset_Top = 0,
	.Inverse_Offset_Bottom = 0
};

static const EyeConfig Preset_Furious = {
	.OffsetX = -2,
	.OffsetY = 0,
	.Height = 32,
	.Width = 44,
	.Slope_Top = 0.42,
	.Slope_Bottom = 0,
	.Radius_Top = 4,
	.Radius_Bottom = 11,
	.Inverse_Radius_Top = 0,
	.Inverse_Radius_Bottom = 0,
	.Inverse_Offset_Top = 0,
	.Inverse_Offset_Bottom = 0
};

static const EyeConfig Preset_Scared = {
	.OffsetX = -3,
	.OffsetY = 0,
	.Height = 42,
	.Width = 44,
	.Slope_Top = -0.1,
	.Slope_Bottom = 0,
	.Radius_Top = 15,
	.Radius_Bottom = 11,
	.Inverse_Radius_Top = 0,
	.Inverse_Radius_Bottom = 0,
	.Inverse_Offset_Top = 0,
	.Inverse_Offset_Bottom = 0
};

static const EyeConfig Preset_Awe = {
	.OffsetX = 2,
	.OffsetY = 0,
	.Height = 38,
	.Width = 46,
	.Slope_Top = -0.1,
	.Slope_Bottom = 0.1,
	.Radius_Top = 14,
	.Radius_Bottom = 14,
	.Inverse_Radius_Top = 0,
	.Inverse_Radius_Bottom = 0,
	.Inverse_Offset_Top = 0,
	.Inverse_Offset_Bottom = 0
};

#endif
#ifndef TAIJI_WEB_RADIO_H
#define TAIJI_WEB_RADIO_H

#include <string>
#include <vector>

#include "esp_http_server.h"
#include "features/music/esp32_radio.h"

class TaijiWebRadio {
public:
    TaijiWebRadio();
    ~TaijiWebRadio();

    void Start();
    void Stop();

    bool PlaySelected();
    bool PlayStation(int station_number);
    bool NextStation();
    bool StopPlayback();

    // Synchronize Wi-Fi power-save mode with radio/voice-assistant activity.
    static void UpdateWifiPowerSave();

    bool IsRadioActive() const { return radio_.IsPlaying() || radio_.IsDownloading(); }

private:
    struct Station {
        std::string name;
        std::string url;
        std::string type;
    };

    httpd_handle_t server_ = nullptr;
    std::vector<Station> stations_;
    Esp32Radio radio_;
    int current_slot_ = -1;

    void LoadStations();
    void SaveStation(int slot, const Station& station);
    void ClearStation(int slot);

    static esp_err_t RootHandler(httpd_req_t* req);
    static esp_err_t StationsGetHandler(httpd_req_t* req);
    static esp_err_t StationsPostHandler(httpd_req_t* req);
    static esp_err_t PlayHandler(httpd_req_t* req);
    static esp_err_t StopHandler(httpd_req_t* req);

    esp_err_t HandleRoot(httpd_req_t* req);
    esp_err_t HandleStationsGet(httpd_req_t* req);
    esp_err_t HandleStationsPost(httpd_req_t* req);
    esp_err_t HandlePlay(httpd_req_t* req);
    esp_err_t HandleStop(httpd_req_t* req);

    void StartRadio(int slot);
    bool StopRadio();


    static TaijiWebRadio* instance_;
};

#endif

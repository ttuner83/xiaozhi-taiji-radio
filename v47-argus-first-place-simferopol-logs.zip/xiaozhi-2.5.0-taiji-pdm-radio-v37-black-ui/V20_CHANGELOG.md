# V20

Based on V19.

Changes:
- Keeps V19 Wi-Fi power-save logic: WIFI_PS_NONE while radio/assistant is active, modem sleep in idle.
- Keeps radio task priorities: radio_stream=3, radio_net=3.
- Keeps RADIO_PREBUFFER_SIZE=24 KB and existing radio buffer settings.
- Fixes radio station-switch teardown race: radio_net no longer self-deletes while the owner may already be freeing the shared PSRAM stream buffer. The network task signals completion, suspends, and is explicitly deleted by the radio task before stream-buffer cleanup.
- Keeps PDM/display/audio architecture unchanged.

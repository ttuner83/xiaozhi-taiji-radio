#include "cozmo_eyes.h"

#include "Face.h"
#include "eye_fb.h"

#include "esp_heap_caps.h"

namespace {

// Maps XiaoZhi emotion names onto esp32-eyes expressions.
const char* MapEmotion(const std::string& emotion) {
    if (emotion == "neutral" || emotion == "normal" || emotion == "relaxed") {
        return "normal";
    }
    if (emotion == "happy" || emotion == "loving" || emotion == "delicious") {
        return "happy";
    }
    if (emotion == "laughing" || emotion == "funny" || emotion == "kissy" || emotion == "silly") {
        return "glee";
    }
    if (emotion == "sad" || emotion == "crying") {
        return "sad";
    }
    if (emotion == "angry") {
        return "angry";
    }
    if (emotion == "embarrassed") {
        return "worried";
    }
    if (emotion == "surprised" || emotion == "shocked") {
        return "surprised";
    }
    if (emotion == "thinking" || emotion == "confident") {
        return "focused";
    }
    if (emotion == "winking") {
        return "squint";
    }
    if (emotion == "cool" || emotion == "confused") {
        return "skeptic";
    }
    if (emotion == "sleepy") {
        return "sleepy";
    }
    return nullptr;
}

void ApplyExpression(Face* face, const std::string& expression) {
    if (expression == "angry") {
        face->Expression.GoTo_Angry();
    } else if (expression == "glee") {
        face->Expression.GoTo_Glee();
    } else if (expression == "happy") {
        face->Expression.GoTo_Happy();
    } else if (expression == "sad") {
        face->Expression.GoTo_Sad();
    } else if (expression == "worried") {
        face->Expression.GoTo_Worried();
    } else if (expression == "focused") {
        face->Expression.GoTo_Focused();
    } else if (expression == "annoyed") {
        face->Expression.GoTo_Annoyed();
    } else if (expression == "surprised") {
        face->Expression.GoTo_Surprised();
    } else if (expression == "skeptic") {
        face->Expression.GoTo_Skeptic();
    } else if (expression == "frustrated") {
        face->Expression.GoTo_Frustrated();
    } else if (expression == "unimpressed") {
        face->Expression.GoTo_Unimpressed();
    } else if (expression == "sleepy") {
        face->Expression.GoTo_Sleepy();
    } else if (expression == "suspicious") {
        face->Expression.GoTo_Suspicious();
    } else if (expression == "squint") {
        face->Expression.GoTo_Squint();
    } else if (expression == "furious") {
        face->Expression.GoTo_Furious();
    } else if (expression == "scared") {
        face->Expression.GoTo_Scared();
    } else if (expression == "awe") {
        face->Expression.GoTo_Awe();
    } else {
        face->Expression.GoTo_Normal();
    }
}

}  // namespace

CozmoEyes::CozmoEyes(int virtual_w, int virtual_h, int eye_size, int scale) {
    width_ = virtual_w * scale;
    height_ = virtual_h * scale;

    size_t bytes = static_cast<size_t>(width_) * height_ * sizeof(uint16_t);
    fb_ = static_cast<uint16_t*>(heap_caps_malloc(bytes, MALLOC_CAP_SPIRAM));
    if (fb_ == nullptr) {
        fb_ = static_cast<uint16_t*>(malloc(bytes));
    }
    g_fb.Configure(fb_, width_, height_, scale);

    face_ = std::make_unique<Face>(virtual_w, virtual_h, eye_size);
    // Keep the emotion selected by the application instead of switching randomly.
    face_->RandomBehavior = false;
    // Natural autonomous behaviour.
    face_->RandomLook = true;
    face_->RandomBlink = true;
    face_->Expression.GoTo_Normal();
}

CozmoEyes::~CozmoEyes() {
    face_.reset();
    if (fb_ != nullptr) {
        free(fb_);
    }
}

void CozmoEyes::SetColors(uint16_t bg, uint16_t ink) {
    std::lock_guard<std::mutex> lk(mutex_);
    g_fb.bg = bg;
    g_fb.ink = ink;
}

void CozmoEyes::SetEmotion(const std::string& emotion) {
    std::lock_guard<std::mutex> lk(mutex_);
    current_emotion_ = emotion;
}

void CozmoEyes::Update() {
    if (face_ == nullptr || fb_ == nullptr) {
        return;
    }

    // Hold the lock for the whole frame so SetEmotion/SetColors
    // (called from other tasks) never race the render.
    std::lock_guard<std::mutex> lk(mutex_);

    if (current_emotion_ != last_applied_) {
        const char* expr = MapEmotion(current_emotion_);
        ApplyExpression(face_.get(), expr != nullptr ? expr : "normal");
        last_applied_ = current_emotion_;
    }

    face_->Update();
}

bool CozmoEyes::IsMapped(const std::string& emotion) {
    return MapEmotion(emotion) != nullptr;
}

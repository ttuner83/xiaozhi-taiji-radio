#ifndef COMMON_h
#define COMMON_h

#include "Arduino.h"
#include "eye_fb.h"

extern EyeFB g_fb;

#endif

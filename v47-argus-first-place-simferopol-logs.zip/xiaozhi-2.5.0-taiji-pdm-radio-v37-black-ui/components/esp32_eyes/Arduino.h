#ifndef ESP32_EYES_ARDUINO_SHIM_h
#define ESP32_EYES_ARDUINO_SHIM_h

// Minimal Arduino-compatible shim for the esp32-eyes library.
// Provides only the Arduino API surface used by the library under ESP-IDF.

#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <algorithm>

#include "esp_timer.h"
#include "esp_random.h"

static inline unsigned long millis() {
    return (unsigned long)(esp_timer_get_time() / 1000);
}

// Arduino random(min, max) returns a value in the range [min, max)
static inline long random(long howsmall, long howbig) {
    if (howbig <= howsmall) {
        return howsmall;
    }
    uint32_t range = (uint32_t)(howbig - howsmall);
    return howsmall + (long)(esp_random() % range);
}

using std::min;
using std::max;

#endif

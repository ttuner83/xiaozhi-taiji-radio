#include "eye_fb.h"

EyeFB g_fb;

void EyeFB::Configure(uint16_t* buf, int w, int h, int scale) {
    buf_ = buf;
    w_ = w;
    h_ = h;
    scale_ = scale > 0 ? scale : 1;
    color_ = true;
}

void EyeFB::clear() {
    if (buf_ == nullptr) {
        return;
    }
    uint16_t c = bg;
    for (int i = 0; i < w_ * h_; i++) {
        buf_[i] = c;
    }
}

void EyeFB::setDrawColor(int color) {
    color_ = (color != 0);
}

void EyeFB::fillPixel(int x, int y) {
    if (x < 0 || x >= w_ || y < 0 || y >= h_) {
        return;
    }
    buf_[y * w_ + x] = color_ ? ink : bg;
}

void EyeFB::fillRow(int y, int x0, int x1) {
    if (y < 0 || y >= h_) {
        return;
    }
    if (x0 < 0) {
        x0 = 0;
    }
    if (x1 > w_) {
        x1 = w_;
    }
    if (x0 >= x1) {
        return;
    }
    uint16_t c = color_ ? ink : bg;
    uint16_t* p = buf_ + y * w_ + x0;
    for (int x = x0; x < x1; x++) {
        *p++ = c;
    }
}

void EyeFB::drawHLine(int x, int y, int len) {
    if (buf_ == nullptr || len <= 0) {
        return;
    }
    fillRow(y * scale_, x * scale_, (x + len) * scale_);
}

void EyeFB::drawBox(int x, int y, int w, int h) {
    if (buf_ == nullptr || w <= 0 || h <= 0) {
        return;
    }
    int64_t x0 = static_cast<int64_t>(x) * scale_;
    int64_t y0 = static_cast<int64_t>(y) * scale_;
    int64_t x1 = (static_cast<int64_t>(x) + w) * scale_;
    int64_t y1 = (static_cast<int64_t>(y) + h) * scale_;

    if (x0 < 0) x0 = 0;
    if (y0 < 0) y0 = 0;
    if (x1 > w_) x1 = w_;
    if (y1 > h_) y1 = h_;
    if (x0 >= x1 || y0 >= y1) {
        return;
    }
    for (int64_t yy = y0; yy < y1; yy++) {
        fillRow(static_cast<int>(yy), static_cast<int>(x0), static_cast<int>(x1));
    }
}

// Sign of edge (a->b) relative to point p
static inline int32_t EdgeSign(int32_t ax, int32_t ay, int32_t bx, int32_t by, int32_t px, int32_t py) {
    return (ax - px) * (by - py) - (bx - px) * (ay - py);
}

void EyeFB::drawTriangle(int x0, int y0, int x1, int y1, int x2, int y2) {
    if (buf_ == nullptr) {
        return;
    }
    int32_t v0x = x0 * scale_, v0y = y0 * scale_;
    int32_t v1x = x1 * scale_, v1y = y1 * scale_;
    int32_t v2x = x2 * scale_, v2y = y2 * scale_;

    int minx = v0x, maxx = v0x;
    int miny = v0y, maxy = v0y;
    if (v1x < minx) minx = v1x;
    if (v1x > maxx) maxx = v1x;
    if (v2x < minx) minx = v2x;
    if (v2x > maxx) maxx = v2x;
    if (v1y < miny) miny = v1y;
    if (v1y > maxy) maxy = v1y;
    if (v2y < miny) miny = v2y;
    if (v2y > maxy) maxy = v2y;

    if (minx < 0) minx = 0;
    if (miny < 0) miny = 0;
    if (maxx >= w_) maxx = w_ - 1;
    if (maxy >= h_) maxy = h_ - 1;

    for (int y = miny; y <= maxy; y++) {
        for (int x = minx; x <= maxx; x++) {
            int32_t s0 = EdgeSign(v0x, v0y, v1x, v1y, x, y);
            int32_t s1 = EdgeSign(v1x, v1y, v2x, v2y, x, y);
            int32_t s2 = EdgeSign(v2x, v2y, v0x, v0y, x, y);
            if ((s0 >= 0 && s1 >= 0 && s2 >= 0) || (s0 <= 0 && s1 <= 0 && s2 <= 0)) {
                fillPixel(x, y);
            }
        }
    }
}

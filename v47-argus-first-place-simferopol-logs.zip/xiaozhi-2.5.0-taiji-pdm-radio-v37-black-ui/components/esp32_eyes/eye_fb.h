#ifndef EYE_FB_h
#define EYE_FB_h

#include <cstdint>

// Framebuffer renderer used by the esp32-eyes library instead of u8g2.
// Draws the monochrome eye geometry into an RGB565 buffer at a fixed
// upscale factor. draw color 1 == ink, color 0 == background.
class EyeFB {
public:
    void Configure(uint16_t* buf, int w, int h, int scale);

    void clear();
    void setDrawColor(int color);
    void drawHLine(int x, int y, int len);
    void drawBox(int x, int y, int w, int h);
    void drawTriangle(int x0, int y0, int x1, int y1, int x2, int y2);

    // RGB565 colors
    uint16_t bg = 0xFFFF;
    uint16_t ink = 0x0000;

private:
    void fillRow(int y, int x0, int x1);
    void fillPixel(int x, int y);

    uint16_t* buf_ = nullptr;
    int w_ = 0;
    int h_ = 0;
    int scale_ = 1;
    bool color_ = true;
};

extern EyeFB g_fb;

#endif

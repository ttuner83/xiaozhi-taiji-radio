#ifndef COZMO_EYES_h
#define COZMO_EYES_h

#include <cstdint>
#include <memory>
#include <string>
#include <mutex>

class Face;

// Thin wrapper around the esp32-eyes Face that renders into an RGB565
// framebuffer for LVGL. Emotion names follow the XiaoZhi convention
// (neutral, happy, sad, ...) and are mapped internally to esp32-eyes
// expressions.
class CozmoEyes {
public:
    CozmoEyes(int virtual_w, int virtual_h, int eye_size, int scale);
    ~CozmoEyes();

    // Thread-safe: stores the requested emotion, applied on the next Update().
    void SetEmotion(const std::string& emotion);
    // Advance the animation and redraw the framebuffer. Call from the LVGL task.
    void Update();
    void SetColors(uint16_t bg, uint16_t ink);

    uint16_t* Buffer() { return fb_; }
    int BufferWidth() const { return width_; }
    int BufferHeight() const { return height_; }

    // True if the XiaoZhi emotion name has an esp32-eyes expression.
    static bool IsMapped(const std::string& emotion);

private:
    uint16_t* fb_ = nullptr;
    int width_ = 0;
    int height_ = 0;
    std::unique_ptr<Face> face_;
    std::mutex mutex_;
    std::string current_emotion_;
    std::string last_applied_;
};

#endif

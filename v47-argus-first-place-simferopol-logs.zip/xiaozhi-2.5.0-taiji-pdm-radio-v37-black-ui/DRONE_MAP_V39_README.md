# V39 + Drone Map

Base: `v39-taiji-radio-20-default-stations-7-8-swapped-fixed`.

Added:
- OpenTopoMap raster background, zoom 8, 4x4 tiles around Feodosia.
- Tiles are downloaded by GitHub Actions at build time and embedded into the firmware.
- Live WSS: `wss://detector-aero.ru/api/pub/v1/stream`.
- `event_new`, `event_update`, `event_removed`; inactive updates are removed.
- Markers: UAV red dot, rocket orange dot, FPV black X; close markers cluster into a count.
- Left swipe from XiaoZhi opens the map.
- Right swipe starting near the left edge returns to XiaoZhi.
- Map drag pans inside the preloaded area.
- Voice tool for `включи карту дронов` / `покажи карту дронов`.
- The V39 10-second silent radio standby behavior is retained: it enters Idle without sending STOP_LISTENING or closing the assistant audio channel.

The supplied GitHub Actions workflow downloads the 16 map tiles before the ESP-IDF build, so the firmware does not need to request map tiles at runtime.

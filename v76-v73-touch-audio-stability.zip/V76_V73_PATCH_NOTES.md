# v76 — точечные изменения поверх v73

Основа — v73 deferred-page-indicator. Workflow не переписывался и не изменялся.

Изменения:
- Touch polling и действия интерфейса вынесены из общего esp_timer callback в FreeRTOS task; частота опроса 50 Гц (20 мс), стек 4096, приоритет 3, Core 0.
- Audio output task закреплена за Core 1, приоритет повышен с 4 до 6. Audio input task не менялась.
- В sdkconfig.defaults.esp32s3 добавлен CONFIG_I2S_ISR_IRAM_SAFE=y.

Полная сборка ESP-IDF и проверка на устройстве не выполнялись. Архив проверен на целостность и наличие ключевых файлов.

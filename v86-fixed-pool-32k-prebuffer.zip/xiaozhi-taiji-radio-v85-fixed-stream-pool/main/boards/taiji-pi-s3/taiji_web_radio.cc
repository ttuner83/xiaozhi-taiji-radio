#include "taiji_web_radio.h"
#include "radio_face_image.h"

#include "application.h"
#include "board.h"
#include "settings.h"
#include "mcp_server.h"
#include "display/display.h"

#include <algorithm>
#include <cstring>
#include <cstdlib>

#include <cJSON.h>
#include <esp_wifi.h>
#include <esp_log.h>
#include <wifi_manager.h>

#define TAG "TaijiWebRadio"
#define MAX_STATIONS 8
// Keep Wi-Fi awake while either the radio or the voice assistant is active.
// In idle state, return to modem-sleep so the device can wait for the wake word
// with lower Wi-Fi power consumption.
void TaijiWebRadio::UpdateWifiPowerSave() {
    const bool radio_active = instance_ != nullptr && instance_->IsRadioActive();
    const auto state = Application::GetInstance().GetDeviceState();
    // Only the idle state is allowed to use Wi-Fi modem-sleep. All other
    // application states keep Wi-Fi awake because they may involve network
    // activity or audio playback/recording.
    const bool assistant_active = state != kDeviceStateIdle;

    const wifi_ps_type_t target = (radio_active || assistant_active)
        ? WIFI_PS_NONE
        : WIFI_PS_MIN_MODEM;

    static wifi_ps_type_t last_mode = WIFI_PS_MAX_MODEM;
    if (target != last_mode) {
        esp_err_t err = esp_wifi_set_ps(target);
        if (err == ESP_OK) {
            last_mode = target;
            ESP_LOGI(TAG, "Wi-Fi power save: %s",
                     target == WIFI_PS_NONE ? "NONE" : "MIN_MODEM");
        } else {
            ESP_LOGW(TAG, "Failed to set Wi-Fi power save mode %d: %s",
                     (int)target, esp_err_to_name(err));
        }
    }
}

TaijiWebRadio* TaijiWebRadio::instance_ = nullptr;

bool TaijiWebRadio::IsAnyRadioActive() {
    return instance_ != nullptr && instance_->IsRadioActive();
}

static const char kHtml[] = R"HTML(
<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Taiji Pi Radio</title>
<style>
body{font-family:Arial,sans-serif;max-width:760px;margin:20px auto;padding:0 12px;background:#f4f4f4;color:#222}
h2{margin-bottom:8px}.card{background:#fff;padding:14px;margin:10px 0;border-radius:10px}
input,select,button{font-size:16px;padding:9px;margin:4px 0;box-sizing:border-box}
input{width:100%}button{cursor:pointer}.row{display:flex;gap:8px;flex-wrap:wrap}.row button{flex:1}
small{color:#666;word-break:break-all}.playing{font-weight:bold}
</style></head><body>
<h2>Taiji Pi S3 — Internet Radio</h2>
<div class="card"><div id="list">Загрузка...</div></div>
<div class="card"><b>Добавить / изменить станцию</b>
<input id="slot" type="number" min="0" max="7" value="0" placeholder="Номер 0..7">
<input id="name" placeholder="Название станции">
<input id="url" placeholder="http://... или https://...">
<select id="type"><option value="mp3">MP3</option><option value="aac">AAC</option><option value="ogg">OGG/Opus</option><option value="wav">WAV</option></select>
<div class="row"><button onclick="save()">Сохранить</button><button onclick="stop()">Стоп</button></div>
</div>
<script>
async function load(){
 let r=await fetch('/api/radios'); let a=await r.json();
 let h='';
 a.forEach((x,i)=>{if(!x.url)return;
 h+=`<div class="card"><b>${i}: ${esc(x.name||'Без названия')}</b><br><small>${esc(x.url)} [${esc(x.type||'mp3')}]</small>
 <div class="row"><button onclick="play(${i})">▶ Играть</button><button onclick="edit(${i})">Изменить</button><button onclick="del(${i})">Удалить</button></div></div>`});
 document.getElementById('list').innerHTML=h||'Станций пока нет';
}
function esc(s){return String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]))}
async function save(){
 let o={slot:+slot.value,name:name.value,url:url.value,type:type.value};
 await fetch('/api/radios',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(o)});
 load();
}
async function play(i){await fetch('/api/play?slot='+i);load()}
async function stop(){await fetch('/api/stop')}
async function del(i){await fetch('/api/radios',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({slot:i,delete:true})});load()}
async function edit(i){
 let a=await (await fetch('/api/radios')).json(),x=a[i];
 slot.value=i;name.value=x.name||'';url.value=x.url||'';type.value=x.type||'mp3';
}
load();
</script></body></html>
)HTML";

static bool ReadBody(httpd_req_t* req, std::string& body) {
    if (req->content_len <= 0 || req->content_len > 4096) {
        return false;
    }
    body.resize(req->content_len);
    size_t received = 0;
    while (received < body.size()) {
        int ret = httpd_req_recv(req, body.data() + received, body.size() - received);
        if (ret <= 0) {
            return false;
        }
        received += ret;
    }
    return true;
}

TaijiWebRadio::TaijiWebRadio() {
    instance_ = this;
    radio_.Initialize();
    LoadStations();

    auto& mcp = McpServer::GetInstance();
    mcp.AddTool("self.network.get_ip",
        "Report the current local Wi-Fi IP address and web radio interface URL. Use for requests such as: 'Скажи свой IP', 'Какой у тебя IP-адрес?', 'Назови адрес веб-интерфейса в локальной сети'.",
        PropertyList(),
        [](const PropertyList&) -> ReturnValue {
            auto& wifi = WifiManager::GetInstance();
            std::string ip = wifi.GetIpAddress();
            if (ip.empty()) return std::string("Wi-Fi не подключён, локальный IP пока неизвестен.");
            return std::string("Локальный IP устройства: ") + ip + ". Веб-интерфейс радио: http://" + ip + "/";
        });
    mcp.AddTool("self.radio.play",
        "Start the selected saved Internet radio station. Use for requests such as: 'Включи радио', 'Запусти радио'.",
        PropertyList(),
        [this](const PropertyList&) -> ReturnValue { return PlaySelected(); });
    mcp.AddTool("self.radio.play_station",
        "Start a saved Internet radio station by number. The user-visible station numbers start at 1. Use for requests such as: 'Включи станцию 4', 'Запусти станцию номер 4'.",
        PropertyList({Property("station", kPropertyTypeInteger, 1, 1, MAX_STATIONS)}),
        [this](const PropertyList& properties) -> ReturnValue {
            return PlayStation(properties["station"].value<int>());
        });
    mcp.AddTool("self.radio.next",
        "Switch to the next configured Internet radio station and start it. Use for requests such as: 'Следующая радиостанция', 'Переключи радио'.",
        PropertyList(),
        [this](const PropertyList&) -> ReturnValue { return NextStation(); });
    mcp.AddTool("self.radio.stop",
        "Stop Internet radio playback. Use for requests such as: 'Выключи радио', 'Останови радио'.",
        PropertyList(),
        [this](const PropertyList&) -> ReturnValue { return StopPlayback(); });
    mcp.AddTool("self.radio.get_volume",
        "Get ONLY the independent Internet radio volume (0-100%). This is separate from self.audio_speaker.set_volume. Use for radio volume requests such as 'громкость радио', 'радио громче' or 'радио тише'.",
        PropertyList(),
        [this](const PropertyList&) -> ReturnValue { return radio_.GetVolume(); });
    mcp.AddTool("self.radio.set_volume",
        "Set ONLY the independent Internet radio volume from 0 to 100%. NEVER use self.audio_speaker.set_volume for this. Use this tool when the user says 'громкость радио 30%', 'радио 30%', 'громкость радио', 'сделай радио тише' or 'сделай радио громче'. This must not change the voice assistant volume.",
        PropertyList({Property("volume", kPropertyTypeInteger, 20, 0, 100)}),
        [this](const PropertyList& properties) -> ReturnValue {
            radio_.SetVolume(properties["volume"].value<int>());
            return true;
        });
}

TaijiWebRadio::~TaijiWebRadio() {
    Stop();
    if (silent_standby_timer_) {
        esp_timer_delete(silent_standby_timer_);
        silent_standby_timer_ = nullptr;
    }
    if (radio_button_flash_timer_) { lv_timer_delete(radio_button_flash_timer_); radio_button_flash_timer_ = nullptr; }
    if (instance_ == this) {
        instance_ = nullptr;
    }
}

void TaijiWebRadio::LoadStations() {
    stations_.clear();
    stations_.resize(MAX_STATIONS);
    Settings settings("radio", false);
    struct Preset { const char* name; const char* url; const char* type; };
    static const Preset presets[MAX_STATIONS] = {
        {"Европа Плюс", "http://emgregion.hostingradio.ru:8064/moscow.europaplus.mp3", "mp3"},
        {"Рок Классик", "https://strm112.1.fm/rockclassics_mobile_mp3", "mp3"},
        {"Кассета Диско", "https://casseta-disco.ru:1090/stream", "mp3"},
        {"Рок Атака", "https://listen7.myradio24.com/rockataka", "mp3"},
        {"Максимус Рок", "https://maximusrockfm.stream.laut.fm/maximusrockfm", "mp3"},
        {"Рок Арсенал", "https://online.rockarsenal.ru/rockwotalk?5423", "mp3"},
        {"Наше Рок", "https://nashe1.hostingradio.ru/nasheclassic.mp3", "mp3"},
        {"Мелодия", "http://stream128.melodiafm.spb.ru:8000/melodia128", "mp3"},
    };
    for (int i = 0; i < MAX_STATIONS; ++i) {
        std::string key = "r" + std::to_string(i);
        std::string value = settings.GetString(key, "");
        if (value.empty()) {
            stations_[i].name = presets[i].name;
            stations_[i].url = presets[i].url;
            stations_[i].type = presets[i].type;
            continue;
        }
        cJSON* obj = cJSON_Parse(value.c_str());
        if (!obj) {
            continue;
        }
        auto get = [&](const char* key) -> std::string {
            cJSON* item = cJSON_GetObjectItemCaseSensitive(obj, key);
            return cJSON_IsString(item) ? item->valuestring : "";
        };
        stations_[i].name = get("name");
        if (stations_[i].name.empty()) {
            stations_[i].name = settings.GetString("n" + std::to_string(i), "");
        }
        stations_[i].url = get("url");
        stations_[i].type = get("type");
        if (stations_[i].type.empty()) {
            stations_[i].type = "mp3";
        }
        cJSON_Delete(obj);
    }

    // Migrate only the old built-in defaults saved by earlier firmware.
    // User-customized stations are left untouched.
    struct Migration { int slot; const char* old_name; const char* old_url; const char* new_name; const char* new_url; };
    static const Migration migrations[] = {
        {0, "Мелодия", "http://stream128.melodiafm.spb.ru:8000/melodia128", "Европа Плюс", "http://emgregion.hostingradio.ru:8064/moscow.europaplus.mp3"},
        {1, "Европа Плюс", "http://emgregion.hostingradio.ru:8064/moscow.europaplus.mp3", "Рок Классик", "https://strm112.1.fm/rockclassics_mobile_mp3"},
        {2, "Радио Рекорд", "http://online.radiorecord.ru:8102/sd90_128", "Кассета Диско", "https://casseta-disco.ru:1090/stream"},
        {6, "Мелодия", "http://stream128.melodiafm.spb.ru:8000/melodia128", "Наше Рок", "https://nashe1.hostingradio.ru/nasheclassic.mp3"},
        {7, "Наше Рок", "https://nashe1.hostingradio.ru/nasheclassic.mp3", "Мелодия", "http://stream128.melodiafm.spb.ru:8000/melodia128"},
    };
    for (const auto& m : migrations) {
        if (stations_[m.slot].name == m.old_name && stations_[m.slot].url == m.old_url) {
            Station station;
            station.name = m.new_name;
            station.url = m.new_url;
            station.type = "mp3";
            SaveStation(m.slot, station);
        }
    }
}

void TaijiWebRadio::SaveStation(int slot, const Station& station) {
    if (slot < 0 || slot >= MAX_STATIONS) {
        return;
    }
    cJSON* obj = cJSON_CreateObject();
    cJSON_AddStringToObject(obj, "name", station.name.c_str());
    cJSON_AddStringToObject(obj, "url", station.url.c_str());
    cJSON_AddStringToObject(obj, "type", station.type.c_str());
    char* text = cJSON_PrintUnformatted(obj);
    Settings settings("radio", true);
    settings.SetString("r" + std::to_string(slot), text ? text : "");
    settings.SetString("n" + std::to_string(slot), station.name);
    if (text) {
        cJSON_free(text);
    }
    cJSON_Delete(obj);
    stations_[slot] = station;
}

void TaijiWebRadio::ClearStation(int slot) {
    if (slot < 0 || slot >= MAX_STATIONS) {
        return;
    }
    Settings settings("radio", true);
    settings.EraseKey("r" + std::to_string(slot));
    settings.EraseKey("n" + std::to_string(slot));
    stations_[slot] = Station{};
}

void TaijiWebRadio::Start() {
    if (server_) {
        return;
    }

    httpd_config_t config = HTTPD_DEFAULT_CONFIG();
    config.server_port = 80;
    config.max_uri_handlers = 12;
    config.stack_size = 8192;

    if (httpd_start(&server_, &config) != ESP_OK) {
        server_ = nullptr;
        ESP_LOGE(TAG, "Failed to start HTTP server");
        return;
    }

    httpd_uri_t root = {.uri = "/", .method = HTTP_GET, .handler = RootHandler, .user_ctx = this};
    httpd_uri_t get = {.uri = "/api/radios", .method = HTTP_GET, .handler = StationsGetHandler, .user_ctx = this};
    httpd_uri_t post = {.uri = "/api/radios", .method = HTTP_POST, .handler = StationsPostHandler, .user_ctx = this};
    httpd_uri_t play = {.uri = "/api/play", .method = HTTP_GET, .handler = PlayHandler, .user_ctx = this};
    httpd_uri_t stop = {.uri = "/api/stop", .method = HTTP_GET, .handler = StopHandler, .user_ctx = this};

    httpd_register_uri_handler(server_, &root);
    httpd_register_uri_handler(server_, &get);
    httpd_register_uri_handler(server_, &post);
    httpd_register_uri_handler(server_, &play);
    httpd_register_uri_handler(server_, &stop);

    ESP_LOGI(TAG, "Local radio server started");
}

bool TaijiWebRadio::PlaySelected() {
    int slot = current_slot_;
    if (slot < 0 || slot >= MAX_STATIONS || stations_[slot].url.empty()) {
        slot = -1;
        for (int i = 0; i < MAX_STATIONS; ++i) {
            if (!stations_[i].url.empty()) {
                slot = i;
                break;
            }
        }
    }
    if (slot < 0) {
        return false;
    }
    StartRadio(slot);
    return true;
}

bool TaijiWebRadio::PlayStation(int station_number) {
    const int slot = station_number - 1;
    if (station_number < 1 || station_number > MAX_STATIONS ||
        stations_[slot].url.empty()) {
        ESP_LOGW(TAG, "Station number %d is not configured", station_number);
        return false;
    }
    StartRadio(slot);
    return current_slot_ == slot && (radio_.IsPlaying() || radio_.IsDownloading());
}

bool TaijiWebRadio::NextStation() {
    int start = current_slot_;
    if (start < 0 || start >= MAX_STATIONS) {
        start = -1;
    }
    for (int n = 1; n <= MAX_STATIONS; ++n) {
        int slot = (start + n) % MAX_STATIONS;
        if (!stations_[slot].url.empty()) {
            StartRadio(slot);
            return true;
        }
    }
    return false;
}

bool TaijiWebRadio::StopPlayback() {
    StopRadio();
    return true;
}

void TaijiWebRadio::Stop() {
    StopRadio();
    if (server_) {
        httpd_stop(server_);
        server_ = nullptr;
    }
}

esp_err_t TaijiWebRadio::RootHandler(httpd_req_t* req) {
    return static_cast<TaijiWebRadio*>(req->user_ctx)->HandleRoot(req);
}
esp_err_t TaijiWebRadio::StationsGetHandler(httpd_req_t* req) {
    return static_cast<TaijiWebRadio*>(req->user_ctx)->HandleStationsGet(req);
}
esp_err_t TaijiWebRadio::StationsPostHandler(httpd_req_t* req) {
    return static_cast<TaijiWebRadio*>(req->user_ctx)->HandleStationsPost(req);
}
esp_err_t TaijiWebRadio::PlayHandler(httpd_req_t* req) {
    return static_cast<TaijiWebRadio*>(req->user_ctx)->HandlePlay(req);
}
esp_err_t TaijiWebRadio::StopHandler(httpd_req_t* req) {
    return static_cast<TaijiWebRadio*>(req->user_ctx)->HandleStop(req);
}

esp_err_t TaijiWebRadio::HandleRoot(httpd_req_t* req) {
    httpd_resp_set_type(req, "text/html; charset=utf-8");
    return httpd_resp_send(req, kHtml, HTTPD_RESP_USE_STRLEN);
}

esp_err_t TaijiWebRadio::HandleStationsGet(httpd_req_t* req) {
    cJSON* array = cJSON_CreateArray();
    for (int i = 0; i < MAX_STATIONS; ++i) {
        cJSON* obj = cJSON_CreateObject();
        cJSON_AddNumberToObject(obj, "slot", i);
        cJSON_AddStringToObject(obj, "name", stations_[i].name.c_str());
        cJSON_AddStringToObject(obj, "url", stations_[i].url.c_str());
        cJSON_AddStringToObject(obj, "type", stations_[i].type.c_str());
        cJSON_AddBoolToObject(obj, "playing", current_slot_ == i && radio_.IsPlaying());
        cJSON_AddItemToArray(array, obj);
    }
    char* text = cJSON_PrintUnformatted(array);
    cJSON_Delete(array);
    httpd_resp_set_type(req, "application/json");
    esp_err_t ret = httpd_resp_send(req, text ? text : "[]", HTTPD_RESP_USE_STRLEN);
    if (text) {
        cJSON_free(text);
    }
    return ret;
}

esp_err_t TaijiWebRadio::HandleStationsPost(httpd_req_t* req) {
    std::string body;
    if (!ReadBody(req, body)) {
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Invalid body");
        return ESP_OK;
    }
    cJSON* obj = cJSON_Parse(body.c_str());
    if (!obj) {
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Invalid JSON");
        return ESP_OK;
    }

    cJSON* slot_item = cJSON_GetObjectItem(obj, "slot");
    int slot = cJSON_IsNumber(slot_item) ? slot_item->valueint : -1;
    cJSON* del = cJSON_GetObjectItem(obj, "delete");
    if (cJSON_IsTrue(del)) {
        StopRadio();
        ClearStation(slot);
    } else {
        cJSON* name = cJSON_GetObjectItem(obj, "name");
        cJSON* url = cJSON_GetObjectItem(obj, "url");
        cJSON* type = cJSON_GetObjectItem(obj, "type");
        if (slot < 0 || slot >= MAX_STATIONS || !cJSON_IsString(url)) {
            cJSON_Delete(obj);
            httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Invalid station");
            return ESP_OK;
        }
        Station station;
        station.name = cJSON_IsString(name) ? name->valuestring : "";
        station.url = url->valuestring;
        station.type = cJSON_IsString(type) ? type->valuestring : "mp3";
        if (station.url.size() > 400 || station.name.size() > 80) {
            cJSON_Delete(obj);
            httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Too long");
            return ESP_OK;
        }
        if (station.type != "mp3" && station.type != "aac" &&
            station.type != "ogg" && station.type != "wav") {
            station.type = "mp3";
        }
        SaveStation(slot, station);
    }
    cJSON_Delete(obj);
    httpd_resp_set_type(req, "application/json");
    return httpd_resp_sendstr(req, "{\"ok\":true}");
}

esp_err_t TaijiWebRadio::HandlePlay(httpd_req_t* req) {
    char query[64];
    char value[16];
    if (httpd_req_get_url_query_str(req, query, sizeof(query)) != ESP_OK ||
        httpd_query_key_value(query, "slot", value, sizeof(value)) != ESP_OK) {
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "slot required");
        return ESP_OK;
    }
    int slot = atoi(value);
    if (slot < 0 || slot >= MAX_STATIONS || stations_[slot].url.empty()) {
        httpd_resp_send_err(req, HTTPD_404_NOT_FOUND, "Station not found");
        return ESP_OK;
    }
    StartRadio(slot);
    return httpd_resp_sendstr(req, "{\"ok\":true}");
}

esp_err_t TaijiWebRadio::HandleStop(httpd_req_t* req) {
    StopRadio();
    return httpd_resp_sendstr(req, "{\"ok\":true}");
}

void TaijiWebRadio::SetPageIndicator(int page) {
    if (page < 0) page = 0;
    if (page > 2) page = 2;
    auto display = Board::GetInstance().GetDisplay();
    if (!display || !display->SupportsGuiOperations()) return;
    DisplayLockGuard lock(display);
    if (!lock) return;
    if (!page_indicator_root_) {
        page_indicator_root_ = lv_obj_create(lv_screen_active());
        lv_obj_set_size(page_indicator_root_, 78, 16);
        lv_obj_set_pos(page_indicator_root_, 141, 338);
        lv_obj_set_style_bg_opa(page_indicator_root_, LV_OPA_TRANSP, LV_PART_MAIN);
        lv_obj_set_style_border_width(page_indicator_root_, 0, LV_PART_MAIN);
        lv_obj_set_style_pad_all(page_indicator_root_, 0, LV_PART_MAIN);
        lv_obj_set_style_radius(page_indicator_root_, 0, LV_PART_MAIN);
        lv_obj_clear_flag(page_indicator_root_, LV_OBJ_FLAG_SCROLLABLE);
        lv_obj_clear_flag(page_indicator_root_, LV_OBJ_FLAG_CLICKABLE);
        // Three solid white dots: left=map, center=assistant, right=radio.
        const int centers[3] = {12, 39, 66};
        for (int i = 0; i < 3; ++i) {
            lv_obj_t* dot = lv_obj_create(page_indicator_root_);
            lv_obj_set_size(dot, 6, 6);
            lv_obj_set_pos(dot, centers[i] - 3, 5);
            lv_obj_set_style_radius(dot, LV_RADIUS_CIRCLE, LV_PART_MAIN);
            lv_obj_set_style_bg_color(dot, lv_color_white(), LV_PART_MAIN);
            lv_obj_set_style_bg_opa(dot, LV_OPA_COVER, LV_PART_MAIN);
            lv_obj_set_style_border_width(dot, 0, LV_PART_MAIN);
            lv_obj_set_style_pad_all(dot, 0, LV_PART_MAIN);
            lv_obj_clear_flag(dot, LV_OBJ_FLAG_CLICKABLE);
            lv_obj_clear_flag(dot, LV_OBJ_FLAG_SCROLLABLE);
        }
        // Active page is a short, thick white dash (the Android-style page pill).
        page_indicator_active_ = lv_obj_create(page_indicator_root_);
        lv_obj_set_size(page_indicator_active_, 20, 6);
        lv_obj_set_pos(page_indicator_active_, 2, 5);
        lv_obj_set_style_radius(page_indicator_active_, LV_RADIUS_CIRCLE, LV_PART_MAIN);
        lv_obj_set_style_bg_color(page_indicator_active_, lv_color_white(), LV_PART_MAIN);
        lv_obj_set_style_bg_opa(page_indicator_active_, LV_OPA_COVER, LV_PART_MAIN);
        lv_obj_set_style_border_width(page_indicator_active_, 0, LV_PART_MAIN);
        lv_obj_set_style_pad_all(page_indicator_active_, 0, LV_PART_MAIN);
        lv_obj_clear_flag(page_indicator_active_, LV_OBJ_FLAG_CLICKABLE);
        lv_obj_clear_flag(page_indicator_active_, LV_OBJ_FLAG_SCROLLABLE);
    }
    // Animate only the tiny indicator. Full-screen sliding would force the map and
    // assistant to redraw large areas during radio/network work and can cause stutter.
    lv_anim_delete(page_indicator_active_, nullptr);
    lv_anim_t anim;
    lv_anim_init(&anim);
    lv_anim_set_var(&anim, page_indicator_active_);
    lv_anim_set_values(&anim, lv_obj_get_x(page_indicator_active_), 2 + page * 27);
    lv_anim_set_time(&anim, 140);
    lv_anim_set_path_cb(&anim, lv_anim_path_ease_out);
    lv_anim_set_exec_cb(&anim, [](void* obj, int32_t x) { lv_obj_set_x(static_cast<lv_obj_t*>(obj), x); });
    lv_anim_start(&anim);
    lv_obj_move_foreground(page_indicator_root_);
}


void TaijiWebRadio::EnsureRadioUi() {
    if (radio_ui_root_) return;
    auto display = Board::GetInstance().GetDisplay();
    if (!display || !display->SupportsGuiOperations()) return;
    DisplayLockGuard lock(display);
    if (!lock) return;

    // Use the actual radio-face artwork from the approved composite reference.
    // The map artwork is not touched. Transparent hit zones are placed over the
    // three pictured buttons; only the station title is dynamically overlaid.
    radio_ui_root_ = lv_obj_create(lv_screen_active());
    lv_obj_set_size(radio_ui_root_, 360, 360);
    lv_obj_set_pos(radio_ui_root_, 0, 0);
    lv_obj_set_style_radius(radio_ui_root_, LV_RADIUS_CIRCLE, LV_PART_MAIN);
    lv_obj_set_style_border_width(radio_ui_root_, 0, LV_PART_MAIN);
    lv_obj_set_style_bg_color(radio_ui_root_, lv_color_black(), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(radio_ui_root_, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_pad_all(radio_ui_root_, 0, LV_PART_MAIN);
    lv_obj_clear_flag(radio_ui_root_, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_t* face = lv_image_create(radio_ui_root_);
    lv_image_set_src(face, &kRadioFaceImage);
    // Source artwork is 240x240 RGB565; upscale once to fit the round 360px display.
    lv_obj_set_pos(face, 60, 60);
    lv_image_set_scale(face, 384); // 1.5x; lower flash/RAM footprint than 360x360 source
    lv_obj_clear_flag(face, LV_OBJ_FLAG_CLICKABLE);

    // Cover the station name printed in the reference image so the live station
    // name can be shown without changing the surrounding vintage panel artwork.
    lv_obj_t* title_panel = lv_obj_create(radio_ui_root_);
    lv_obj_set_size(title_panel, 248, 42);
    lv_obj_set_pos(title_panel, 56, 176);
    lv_obj_set_style_radius(title_panel, 3, LV_PART_MAIN);
    lv_obj_set_style_border_width(title_panel, 0, LV_PART_MAIN);
    lv_obj_set_style_bg_color(title_panel, lv_color_make(20, 13, 7), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(title_panel, LV_OPA_90, LV_PART_MAIN);
    lv_obj_set_style_pad_all(title_panel, 0, LV_PART_MAIN);
    lv_obj_clear_flag(title_panel, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_clear_flag(title_panel, LV_OBJ_FLAG_CLICKABLE);

    radio_station_label_ = lv_label_create(title_panel);
    lv_label_set_text(radio_station_label_, "Интернет-радио");
    lv_label_set_long_mode(radio_station_label_, LV_LABEL_LONG_DOT);
    lv_obj_set_width(radio_station_label_, 244);
    lv_obj_set_height(radio_station_label_, 36);
    lv_obj_set_style_bg_opa(radio_station_label_, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_set_style_text_align(radio_station_label_, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN);
    lv_obj_set_style_text_color(radio_station_label_, lv_color_make(255, 184, 66), LV_PART_MAIN);
    lv_obj_set_style_text_font(radio_station_label_, &lv_font_montserrat_14, LV_PART_MAIN);
    lv_obj_align(radio_station_label_, LV_ALIGN_CENTER, 0, 0);
    lv_obj_move_foreground(title_panel);

    // Transparent touch targets match the three physical-looking controls in the artwork.
    const int xs[3] = {70, 154, 237};
    const int ys[3] = {232, 232, 232};
    for (int i = 0; i < 3; ++i) {
        lv_obj_t* btn = lv_btn_create(radio_ui_root_);
        radio_buttons_[i] = btn;
        lv_obj_set_size(btn, 72, 76);
        lv_obj_set_pos(btn, xs[i] - 5, ys[i] - 5);
        lv_obj_set_style_radius(btn, LV_RADIUS_CIRCLE, LV_PART_MAIN);
        lv_obj_set_style_bg_color(btn, lv_color_make(255, 170, 55), LV_PART_MAIN);
        lv_obj_set_style_bg_opa(btn, LV_OPA_TRANSP, LV_PART_MAIN);
        lv_obj_set_style_border_width(btn, 0, LV_PART_MAIN);
        lv_obj_set_style_shadow_width(btn, 0, LV_PART_MAIN);
        lv_obj_set_style_pad_all(btn, 0, LV_PART_MAIN);
        lv_obj_set_user_data(btn, reinterpret_cast<void*>(static_cast<intptr_t>(i + 1)));
        lv_obj_add_flag(btn, LV_OBJ_FLAG_CLICKABLE);
        lv_obj_add_event_cb(btn, RadioUiEvent, LV_EVENT_CLICKED, this);
    }
    lv_obj_add_flag(radio_ui_root_, LV_OBJ_FLAG_HIDDEN);
}

void TaijiWebRadio::RadioButtonFlashTimerCallback(lv_timer_t* timer) {
    auto* self = static_cast<TaijiWebRadio*>(lv_timer_get_user_data(timer));
    if (!self) return;
    for (auto* btn : self->radio_buttons_) {
        if (!btn) continue;
        lv_obj_set_style_bg_opa(btn, LV_OPA_TRANSP, LV_PART_MAIN);
        lv_obj_set_style_border_width(btn, 0, LV_PART_MAIN);
    }
    // repeat_count=1 makes LVGL retire this one-shot timer after the callback.
    self->radio_button_flash_timer_ = nullptr;
}

void TaijiWebRadio::FlashRadioButton(int action) {
    if (action < 1 || action > 3 || !radio_buttons_[action - 1]) return;
    auto* btn = radio_buttons_[action - 1];
    if (radio_button_flash_timer_) {
        // Reuse the existing one-shot timer instead of deleting/recreating it
        // on rapid taps (avoids timer churn while LVGL is servicing input).
        lv_timer_reset(radio_button_flash_timer_);
        lv_timer_resume(radio_button_flash_timer_);
    }
    for (auto* item : radio_buttons_) {
        if (!item) continue;
        lv_obj_set_style_bg_opa(item, LV_OPA_TRANSP, LV_PART_MAIN);
        lv_obj_set_style_border_width(item, 0, LV_PART_MAIN);
    }
    lv_obj_set_style_bg_opa(btn, LV_OPA_70, LV_PART_MAIN);
    lv_obj_set_style_border_color(btn, lv_color_make(255, 204, 90), LV_PART_MAIN);
    lv_obj_set_style_border_width(btn, 4, LV_PART_MAIN);
    if (!radio_button_flash_timer_) {
        radio_button_flash_timer_ = lv_timer_create(RadioButtonFlashTimerCallback, 150, this);
        lv_timer_set_repeat_count(radio_button_flash_timer_, 1);
    }
}

void TaijiWebRadio::ShowRadioUi(bool show) {
    EnsureRadioUi();
    if (!radio_ui_root_) return;
    auto display = Board::GetInstance().GetDisplay();
    if (!display) return;
    {
        DisplayLockGuard lock(display);
        if (!lock) return;
        if (show) {
            UpdateRadioStationLabel();
            lv_obj_clear_flag(radio_ui_root_, LV_OBJ_FLAG_HIDDEN);
            lv_obj_move_foreground(radio_ui_root_);
            radio_ui_visible_ = true;
        } else {
            radio_ui_visible_ = false;
            lv_obj_add_flag(radio_ui_root_, LV_OBJ_FLAG_HIDDEN);
        }
    }
    // Do this after releasing the GUI lock: the display method takes its own lock.
    display->SetRadioLowMotionMode(show);
}

void TaijiWebRadio::UpdateRadioStationLabel() {
    if (!radio_station_label_) return;
    static const char* display_names[MAX_STATIONS] = {
        "Europa Plus", "Rock Classic", "Casseta Disco", "Rock Ataka",
        "Maximus Rock", "Rock Arsenal", "Nashe Rock", "Melodia"
    };
    const char* name = (current_slot_ >= 0 && current_slot_ < MAX_STATIONS)
        ? display_names[current_slot_] : "Internet Radio";
    lv_label_set_text(radio_station_label_, name);
    lv_obj_clear_flag(radio_station_label_, LV_OBJ_FLAG_HIDDEN);
}

void TaijiWebRadio::RadioUiEvent(lv_event_t* event) {
    auto* self = static_cast<TaijiWebRadio*>(lv_event_get_user_data(event));
    // LVGL 9 provides a typed widget-target accessor. Use it instead of
    // lv_event_get_target(), whose return type is void* in this LVGL build.
    lv_obj_t* target_obj = lv_event_get_target_obj(event);
    if (!self || target_obj == nullptr) return;
    intptr_t action = reinterpret_cast<intptr_t>(lv_obj_get_user_data(target_obj));
    // Some LVGL input paths can report a child label as the target.
    if (action < 1 || action > 3) {
        lv_obj_t* parent = lv_obj_get_parent(target_obj);
        if (parent) action = reinterpret_cast<intptr_t>(lv_obj_get_user_data(parent));
    }
    if (action < 1 || action > 3) {
        return;
    }
    ESP_LOGI(TAG, "Radio touch action=%ld", static_cast<long>(action));
    self->FlashRadioButton(static_cast<int>(action));
    if (action == 1) {
        int start = self->current_slot_;
        for (int n = 1; n <= MAX_STATIONS; ++n) {
            int slot = (start - n + MAX_STATIONS * 2) % MAX_STATIONS;
            if (!self->stations_[slot].url.empty()) { self->StartRadio(slot); break; }
        }
    } else if (action == 2) {
        self->StopRadio();
        Application::GetInstance().ToggleChatState();
    } else if (action == 3) self->NextStation();
}

void TaijiWebRadio::HandleTouchDown(int x, int y) {
    if (!radio_ui_visible_) return;
    const int sx = 359 - x;
    const int sy = 359 - y;
    if (sy < 220 || sy > 320) return;
    const int action = (sx >= 25 && sx < 115) ? 1 :
                       ((sx >= 115 && sx < 210) ? 2 :
                       ((sx >= 210 && sx <= 330) ? 3 : 0));
    if (!action) return;
    auto display = Board::GetInstance().GetDisplay();
    if (!display) return;
    DisplayLockGuard lock(display);
    if (lock) {
            FlashRadioButton(action);
    }
}

bool TaijiWebRadio::HandleTouchTap(int x, int y) {
    // UI visibility, not decoder state, is authoritative: the stream can be
    // temporarily buffering while the radio screen remains on display.
    if (!radio_ui_visible_) return false;

    // The LCD is mirrored in both axes in config.h, while CST816S reports
    // native sensor coordinates. Convert to the visible 360x360 coordinate space.
    const int sx = 359 - x;
    const int sy = 359 - y;
    // The upper area (above the three radio buttons) is a manual assistant
    // activation zone. Radio keeps playing; cancel the silent-standby timer so
    // it cannot immediately put the assistant back into idle.
    if (sy < 220) {
        CancelSilentStandbyTimer();
        auto& app = Application::GetInstance();
        // If the voice-command grace period is still active, leave the current
        // assistant session alone; otherwise the tap starts listening from idle.
        if (app.GetDeviceState() == kDeviceStateIdle) {
            app.ToggleChatState();
        }
        return true;
    }
    if (sy > 320) return true; // ignore the bottom margin of the radio page
    int action = 0;
    if (sx >= 25 && sx < 115) action = 1;       // left: previous
    else if (sx >= 115 && sx < 210) action = 2; // center: power / return
    else if (sx >= 210 && sx <= 330) action = 3;// right: next
    if (!action) return true; // outside the three buttons: ignore safely
    auto display = Board::GetInstance().GetDisplay();
    if (display) {
        DisplayLockGuard lock(display);
        if (lock) FlashRadioButton(action);
    }
    // Always show the press, but do not start/stop/reconnect the audio pipeline
    // repeatedly when the user taps several times in quick succession.
    const int64_t now_us = esp_timer_get_time();
    if (now_us - last_radio_action_us_ < 450000) return true;
    last_radio_action_us_ = now_us;
    if (action == 1) {
        int start = current_slot_;
        for (int n = 1; n <= MAX_STATIONS; ++n) {
            int slot = (start - n + MAX_STATIONS * 2) % MAX_STATIONS;
            if (!stations_[slot].url.empty()) { StartRadio(slot); return true; }
        }
        return true;
    }
    if (action == 2) {
        StopRadio();
        // The radio leaves the assistant in silent idle. Re-enter its normal
        // listening/assistant UI immediately after the user presses power.
        Application::GetInstance().ToggleChatState();
        return true;
    }
    NextStation();
    return true;
}

void TaijiWebRadio::StartRadio(int slot) {
    if (slot < 0 || slot >= MAX_STATIONS || stations_[slot].url.empty()) {
        return;
    }

    // Spotpear-style backend: PlayUrl() serializes lifecycle operations with a
    // control mutex and joins the old download/playback threads before a new
    // stream is started. Station numbers and the web UI remain our own layer.
    if (!radio_.PlayUrl(stations_[slot].url, stations_[slot].name)) {
        ESP_LOGE(TAG, "Failed to start station %d: %s", slot + 1, stations_[slot].url.c_str());
        current_slot_ = -1;
        UpdateWifiPowerSave();
        return;
    }

    current_slot_ = slot;
    ShowRadioUi(true);
    ESP_LOGI(TAG, "Starting station %d: %s", slot + 1, stations_[slot].url.c_str());
    // Do not leave AFE/WakeNet running behind the radio screen. The user can
    // still tap the assistant area to resume normal assistant processing.
    CancelSilentStandbyTimer();
    Application::GetInstance().EnterRadioSilentIdle();
    UpdateWifiPowerSave();
}

void TaijiWebRadio::EnterSilentRadioModeNow() {
    // Touch/swipe launch should not open a voice session or stream microphone
    // audio to the assistant. Keep the normal idle/wake-word behavior, but do
    // not wait the 10-second voice-command grace period.
    CancelSilentStandbyTimer();
    Application::GetInstance().EnterRadioSilentIdle();
}

void TaijiWebRadio::SilentStandbyTimerCallback(void* arg) {
    auto* self = static_cast<TaijiWebRadio*>(arg);
    if (!self || !self->IsRadioActive()) {
        return;
    }
    ESP_LOGI(TAG, "Radio active for 10s: entering silent assistant idle");
    Application::GetInstance().EnterRadioSilentIdle();
}

void TaijiWebRadio::StartSilentStandbyTimer() {
    if (!silent_standby_timer_) {
        esp_timer_create_args_t args = {
            .callback = &TaijiWebRadio::SilentStandbyTimerCallback,
            .arg = this,
            .dispatch_method = ESP_TIMER_TASK,
            .name = "radio_silent_idle",
            .skip_unhandled_events = true,
        };
        if (esp_timer_create(&args, &silent_standby_timer_) != ESP_OK) {
            silent_standby_timer_ = nullptr;
            ESP_LOGW(TAG, "Failed to create 10s silent standby timer");
            return;
        }
    }
    esp_timer_stop(silent_standby_timer_);
    esp_timer_start_once(silent_standby_timer_, 10 * 1000 * 1000);
}

void TaijiWebRadio::CancelSilentStandbyTimer() {
    if (silent_standby_timer_) {
        esp_timer_stop(silent_standby_timer_);
    }
}

bool TaijiWebRadio::StopRadio() {
    CancelSilentStandbyTimer();
    const bool active = radio_.IsPlaying() || radio_.IsDownloading();
    if (active) {
        ESP_LOGI(TAG, "Stopping radio through Spotpear-style backend");
    }
    const bool stopped = radio_.Stop();
    current_slot_ = -1;
    ShowRadioUi(false);
    Application::GetInstance().ExitRadioSilentIdle();
    UpdateWifiPowerSave();
    return stopped;
}

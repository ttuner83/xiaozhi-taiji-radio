#ifndef ESP32_MUSIC_H
#define ESP32_MUSIC_H

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <string>
#include "music.h"

// Online MP3 playback through mydazy/esp_mp3_player. Search and metadata are
// handled here; the component owns HTTP streaming, MP3 decoding and buffering.
class Esp32Music : public Music {
public:
    enum DisplayMode { DISPLAY_MODE_SPECTRUM = 0, DISPLAY_MODE_LYRICS = 1 };

    Esp32Music();
    ~Esp32Music() override;
    bool Download(const std::string& song_name, const std::string& artist_name = "") override;
    std::string GetDownloadResult() override;
    bool StartStreaming(const std::string& music_url) override;
    bool StopStreaming() override;
    size_t GetBufferSize() const override;
    bool IsDownloading() const override;
    int16_t* GetAudioData() override;
    void SetDisplayMode(DisplayMode mode) { display_mode_ = mode; }
    DisplayMode GetDisplayMode() const { return display_mode_; }
    std::string GetCurrentSong() const { return current_song_name_; }
    std::string GetCurrentArtist() const { return current_artist_name_; }
    bool IsPlaying() const;

private:
    std::string last_downloaded_data_;
    std::string current_music_url_;
    std::string current_song_name_;
    std::string current_artist_name_;
    std::atomic<bool> is_downloading_{false};
    std::atomic<bool> is_playing_{false};
    std::atomic<DisplayMode> display_mode_{DISPLAY_MODE_SPECTRUM};
};

#endif

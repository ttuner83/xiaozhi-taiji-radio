#include "esp32_music.h"

#include "board.h"
#include "audio/audio_codec.h"
#include "application.h"
#include "boards/taiji-pi-s3/taiji_web_radio.h"
#include "mp3_player.h"
#include "http.h"

#include <esp_log.h>
#include <cJSON.h>
#include <algorithm>
#include <cctype>
#include <cstring>
#include <memory>
#include <string>
#include <vector>

#define TAG "Esp32Music"

namespace {
std::string UrlEncode(const std::string& value) {
    static const char hex[] = "0123456789ABCDEF";
    std::string out;
    for (unsigned char c : value) {
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
            (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.' || c == '~') out += (char)c;
        else if (c == ' ') out += "%20";
        else { out += '%'; out += hex[c >> 4]; out += hex[c & 15]; }
    }
    return out;
}

std::string ResolveRelativeUrl(const std::string& base, const std::string& location);

// Adapter for the firmware's existing network abstraction.
class FirmwareHttp final : public mydazy::IHttpClient {
public:
    bool Open(const std::string& method, const std::string& url) override {
        bytes_read_ = 0;
        current_url_ = url;
        return OpenAt(method, url, 0);
    }
    int GetStatusCode() override {
        if (!http_) return -1;
        auto result = http_->GetStatusCode();
        return result ? *result : -1;
    }
    size_t GetBodyLength() override { return http_ ? http_->GetBodyLength() : 0; }
    int Read(char* buf, size_t size) override {
        if (!http_) return -1;
        auto result = http_->Read(buf, size);
        if (result && *result > 0) {
            bytes_read_ += static_cast<size_t>(*result);
            return *result;
        }
        // A temporary TLS/socket read failure must not immediately kill the song.
        // Resume at the exact byte offset; never restart from byte zero because that
        // would duplicate audio and corrupt MP3 frame alignment.
        if (result && *result == 0) return 0;
        for (int attempt = 1; attempt <= 2; ++attempt) {
            ESP_LOGW(TAG, "MP3 HTTP read failed; attempting range resume %d/2 at byte %u",
                     attempt, static_cast<unsigned>(bytes_read_));
            if (http_) { http_->Close(); http_.reset(); }
            if (!OpenAt("GET", current_url_, bytes_read_)) continue;
            auto resumed = http_->Read(buf, size);
            if (resumed && *resumed > 0) {
                bytes_read_ += static_cast<size_t>(*resumed);
                ESP_LOGI(TAG, "MP3 HTTP range resume succeeded at byte %u",
                         static_cast<unsigned>(bytes_read_));
                return *resumed;
            }
            if (resumed && *resumed == 0) return 0;
        }
        ESP_LOGE(TAG, "MP3 HTTP range resume failed after 2 attempts");
        return -1;
    }
    void Close() override { if (http_) { http_->Close(); http_.reset(); } }
    void SetTimeout(int ms) override { timeout_ms_ = ms; if (http_) http_->SetTimeout(ms); }
private:
    bool OpenAt(const std::string& method, const std::string& url, size_t offset) {
        auto network = Board::GetInstance().GetNetwork();
        if (!network) return false;
        std::string target_url = url;
        for (int redirects = 0; redirects <= 3; ++redirects) {
            http_ = network->CreateHttp(3);
            if (!http_) return false;
            http_->SetHeader("User-Agent", "Mozilla/5.0 (compatible; XiaozhiTaijiRadio/1.0)");
            http_->SetHeader("Accept", "*/*");
            http_->SetTimeout(timeout_ms_);
            if (offset > 0) {
                http_->SetHeader("Range", "bytes=" + std::to_string(offset) + "-");
            }
            if (!http_->Open(method, target_url)) { http_->Close(); http_.reset(); return false; }
            const auto status = http_->GetStatusCode();
            if (status && *status >= 300 && *status < 400 && redirects < 3) {
                const std::string location = http_->GetResponseHeader("Location");
                http_->Close();
                http_.reset();
                if (location.empty()) return false;
                target_url = ResolveRelativeUrl(target_url, location);
                if (target_url.empty()) return false;
                continue;
            }
            // A resume is safe only if the origin honors Range. A 200 response
            // would start the MP3 from byte zero, so reject it rather than corrupt audio.
            if (offset > 0 && (!status || *status != 206)) {
                ESP_LOGW(TAG, "MP3 server did not honor Range resume (HTTP %d)", status ? *status : -1);
                http_->Close();
                http_.reset();
                return false;
            }
            current_url_ = target_url;
            return true;
        }
        return false;
    }
    std::unique_ptr<Http> http_;
    int timeout_ms_ = 30000;
    size_t bytes_read_ = 0;
    std::string current_url_;
};

class FirmwareHttpFactory final : public mydazy::IHttpFactory {
public:
    std::unique_ptr<mydazy::IHttpClient> CreateHttp() override {
        return std::unique_ptr<mydazy::IHttpClient>(new FirmwareHttp());
    }
};

class FirmwareAudioOutput final : public mydazy::IAudioOutput {
public:
    int output_sample_rate() const override {
        auto codec = Board::GetInstance().GetAudioCodec();
        return codec ? codec->output_sample_rate() : 16000;
    }
    int output_channels() const override {
        auto codec = Board::GetInstance().GetAudioCodec();
        return codec ? codec->output_channels() : 1;
    }
    bool output_enabled() const override {
        auto codec = Board::GetInstance().GetAudioCodec();
        return codec && codec->output_enabled();
    }
    void EnableOutput(bool enable) override {
        auto codec = Board::GetInstance().GetAudioCodec();
        if (codec) codec->EnableOutput(enable);
    }
    void OutputData(std::vector<int16_t>& pcm) override {
        auto codec = Board::GetInstance().GetAudioCodec();
        if (!codec || pcm.empty()) return;
        Application::GetInstance().GetAudioService().NotifyExternalOutputActivity();
        if (TaijiWebRadio::IsAssistantDuckActive()) {
            for (auto& sample : pcm) sample = static_cast<int16_t>(sample * 0.03f);
        }
        codec->OutputData(pcm);
    }
};

// Mp3Player keeps these injected objects for its entire lifetime.
FirmwareAudioOutput g_music_audio;
FirmwareHttpFactory g_music_http;
std::atomic<bool> g_mp3_initialized{false};
std::atomic<bool> g_component_playing{false};
void EnsureMp3Initialized() {
    bool expected = false;
    if (!g_mp3_initialized.compare_exchange_strong(expected, true)) return;
    mydazy::Mp3Player::Callbacks callbacks;
    callbacks.on_error = [](const char* status, const char* message) {
        g_component_playing.store(false);
        ESP_LOGE(TAG, "MP3 player error (%s): %s", status ? status : "?", message ? message : "?");
        Application::GetInstance().GetAudioService().SetExternalOutputActive(false);
        TaijiWebRadio::SetAssistantDuck(false);
    };
    callbacks.on_started = [](const std::string& title) {
        ESP_LOGI(TAG, "MP3 playback started: %s", title.c_str());
    };
    callbacks.on_finished = []() {
        ESP_LOGI(TAG, "MP3 playback finished");
        g_component_playing.store(false);
        Application::GetInstance().GetAudioService().SetExternalOutputActive(false);
        TaijiWebRadio::SetAssistantDuck(false);
    };
    mydazy::Mp3Player::GetInstance().Initialize(&g_music_audio, &g_music_http, callbacks);
}

std::string ReadHttpAll(const std::string& url, const char* referer = nullptr) {
    auto network = Board::GetInstance().GetNetwork();
    if (!network) return {};
    auto http = network->CreateHttp(3);
    if (!http) return {};
    http->SetTimeout(12000);
    http->SetHeader("User-Agent", "Mozilla/5.0 (compatible; XiaozhiTaijiRadio/1.0)");
    http->SetHeader("Accept", "text/html,application/json,*/*");
    if (referer) http->SetHeader("Referer", referer);
    if (!http->Open("GET", url)) { http->Close(); return {}; }
    auto status = http->GetStatusCode();
    if (!status || *status < 200 || *status >= 300) {
        ESP_LOGW(TAG, "HTTP GET failed for %s: status=%d", url.c_str(), status ? *status : -1);
        http->Close();
        return {};
    }
    std::string body = http->ReadAll();
    ESP_LOGI(TAG, "HTTP GET completed: status=%d, bytes=%u, url=%s", *status, (unsigned)body.size(), url.c_str());
    http->Close();
    return body;
}


std::string LowerAscii(const std::string& value) {
    std::string out = value;
    for (char& c : out) {
        const unsigned char u = static_cast<unsigned char>(c);
        if (u >= 'A' && u <= 'Z') c = static_cast<char>(u - 'A' + 'a');
    }
    return out;
}

bool ContainsText(const std::string& value, const std::string& part) {
    if (part.empty()) return false;
    return LowerAscii(value).find(LowerAscii(part)) != std::string::npos;
}

std::string ResolveRelativeUrl(const std::string& base, const std::string& location) {
    if (location.rfind("https://", 0) == 0 || location.rfind("http://", 0) == 0) return location;
    const auto scheme = base.find("://");
    if (scheme == std::string::npos) return {};
    const auto host_end = base.find('/', scheme + 3);
    const std::string origin = host_end == std::string::npos ? base : base.substr(0, host_end);
    if (location.rfind("//", 0) == 0) return base.substr(0, scheme + 1) + location;
    if (!location.empty() && location[0] == '/') return origin + location;
    const auto slash = base.rfind('/');
    return (slash == std::string::npos || slash < scheme + 3 ? base + "/" : base.substr(0, slash + 1)) + location;
}

// The hosted Meting instance returns JSON for search and may either redirect
// the audio endpoint to a media URL or return a JSON object containing `url`.
bool FetchMetingAudioUrl(const std::string& api_url, std::string& audio_url) {
    auto network = Board::GetInstance().GetNetwork();
    if (!network) return false;
    auto http = network->CreateHttp(3);
    if (!http) return false;
    http->SetTimeout(15000);
    http->SetHeader("User-Agent", "Mozilla/5.0 (compatible; XiaozhiTaijiRadio/1.0)");
    http->SetHeader("Accept", "application/json,audio/*,*/*");
    http->SetHeader("Referer", "https://meting.mtr.pub/");
    if (!http->Open("GET", api_url)) { http->Close(); return false; }
    auto status = http->GetStatusCode();
    if (!status) { http->Close(); return false; }
    if (*status >= 300 && *status < 400) {
        const std::string location = http->GetResponseHeader("Location");
        http->Close();
        if (location.empty()) return false;
        audio_url = ResolveRelativeUrl(api_url, location);
        return audio_url.rfind("http://", 0) == 0 || audio_url.rfind("https://", 0) == 0;
    }
    if (*status < 200 || *status >= 300) {
        ESP_LOGW(TAG, "Meting audio endpoint returned HTTP %d", *status);
        http->Close();
        return false;
    }
    const std::string body = http->ReadAll();
    http->Close();
    cJSON* root = cJSON_Parse(body.c_str());
    if (root) {
        cJSON* url = cJSON_GetObjectItemCaseSensitive(root, "url");
        if (cJSON_IsString(url) && url->valuestring) audio_url = url->valuestring;
        cJSON_Delete(root);
    }
    if (audio_url.empty()) {
        std::string plain = body;
        const auto first = plain.find_first_not_of(" \r\n\t\"");
        const auto last = plain.find_last_not_of(" \r\n\t\"");
        if (first != std::string::npos && last != std::string::npos) plain = plain.substr(first, last - first + 1);
        if (plain.rfind("https://", 0) == 0 || plain.rfind("http://", 0) == 0) audio_url = plain;
    }
    return audio_url.rfind("https://", 0) == 0 || audio_url.rfind("http://", 0) == 0;
}

bool SearchMeting(const std::string& query, const std::string& requested_song,
                  const std::string& requested_artist, std::string& title,
                  std::string& artist, std::string& audio_url) {
    if (query.empty()) return false;
    const std::string search_url = "https://meting.mtr.pub/api?server=netease&type=search&id=" + UrlEncode(query);
    ESP_LOGI(TAG, "Meting search request: %s", search_url.c_str());
    const std::string body = ReadHttpAll(search_url, "https://meting.mtr.pub/");
    if (body.empty()) return false;
    cJSON* root = cJSON_Parse(body.c_str());
    if (!cJSON_IsArray(root)) {
        ESP_LOGW(TAG, "Meting search response is not a JSON array");
        if (root) cJSON_Delete(root);
        return false;
    }
    int best_score = -1;
    std::string best_id, best_title, best_artist;
    const std::string song_l = LowerAscii(requested_song);
    for (cJSON* item = root->child; item; item = item->next) {
        cJSON* id = cJSON_GetObjectItemCaseSensitive(item, "id");
        cJSON* media_api = cJSON_GetObjectItemCaseSensitive(item, "url");
        cJSON* t = cJSON_GetObjectItemCaseSensitive(item, "title");
        cJSON* a = cJSON_GetObjectItemCaseSensitive(item, "author");
        if (!cJSON_IsString(t) || !t->valuestring || !cJSON_IsString(a) || !a->valuestring) continue;
        std::string candidate_id;
        if (cJSON_IsString(id) && id->valuestring) candidate_id = id->valuestring;
        else if (cJSON_IsNumber(id)) candidate_id = std::to_string(id->valueint);
        else if (cJSON_IsString(media_api) && media_api->valuestring) {
            // This public instance omits an `id` property; it embeds the track
            // ID in each result's `url` field (type=url&id=...).
            const std::string api_link = media_api->valuestring;
            const auto id_pos = api_link.find("id=");
            if (id_pos != std::string::npos) {
                const auto start = id_pos + 3;
                const auto end = api_link.find_first_of("&?#", start);
                candidate_id = api_link.substr(start, end == std::string::npos ? std::string::npos : end - start);
            }
        }
        if (candidate_id.empty()) continue;
        const std::string candidate_title = t->valuestring;
        const std::string candidate_artist = a->valuestring;
        if (candidate_id.empty() || candidate_id.find_first_not_of("0123456789") != std::string::npos) continue;
        int score = 0;
        if (!requested_artist.empty()) {
            if (LowerAscii(candidate_artist) == LowerAscii(requested_artist)) score += 100;
            else if (ContainsText(candidate_artist, requested_artist)) score += 75;
            else if (ContainsText(requested_artist, candidate_artist)) score += 20;
            else continue; // Don't select a same-title result from an unrelated artist.
        } else if (ContainsText(candidate_artist, requested_song)) {
            score += 90;
            if (LowerAscii(candidate_artist) == song_l) score += 20;
        }
        if (!requested_song.empty()) {
            if (LowerAscii(candidate_title) == song_l) score += 80;
            else if (ContainsText(candidate_title, requested_song)) score += 55;
            else if (ContainsText(requested_song, candidate_title)) score += 15;
        }
        if (score > best_score) {
            best_score = score;
            best_id = candidate_id;
            best_title = candidate_title;
            best_artist = candidate_artist;
        }
    }
    cJSON_Delete(root);
    if (best_id.empty() || best_score <= 0) {
        ESP_LOGW(TAG, "Meting returned no suitable matching track");
        return false;
    }
    const std::string audio_api = "https://meting.mtr.pub/api?server=netease&type=url&id=" + best_id;
    ESP_LOGI(TAG, "Meting selected: %s — %s (id=%s, score=%d)", best_artist.c_str(), best_title.c_str(), best_id.c_str(), best_score);
    if (!FetchMetingAudioUrl(audio_api, audio_url)) {
        ESP_LOGW(TAG, "Meting could not resolve an audio URL for track id=%s", best_id.c_str());
        return false;
    }
    title = best_title;
    artist = best_artist;
    return true;
}
} // namespace

Esp32Music::Esp32Music() { EnsureMp3Initialized(); }
Esp32Music::~Esp32Music() { StopStreaming(); }

bool Esp32Music::Download(const std::string& song_name, const std::string& artist_name) {
    if (song_name.empty()) return false;
    is_downloading_ = true;
    const std::string query = (!artist_name.empty() && song_name.find(artist_name) == std::string::npos)
        ? song_name + " " + artist_name : song_name;
    ESP_LOGI(TAG, "Starting online search for: '%s'", query.c_str());
    current_song_name_ = song_name;
    current_artist_name_ = artist_name;
    bool ok = false;
    std::string meting_title, meting_artist, meting_audio_url;
    if (SearchMeting(query, song_name, artist_name, meting_title, meting_artist, meting_audio_url)) {
        current_song_name_ = meting_title;
        current_artist_name_ = meting_artist;
        current_music_url_ = meting_audio_url;
        last_downloaded_data_ = meting_audio_url;
        ok = StartStreaming(meting_audio_url);
    }
    if (!ok) {
        ESP_LOGW(TAG, "Meting search/playback failed; no fallback music sources are enabled");
    }
    ESP_LOGI(TAG, "Online search finished: %s", ok ? "success" : "no playable stream found");
    is_downloading_ = false;
    return ok;
}


std::string Esp32Music::GetDownloadResult() { return last_downloaded_data_; }

bool Esp32Music::StartStreaming(const std::string& music_url) {
    if (music_url.rfind("https://", 0) != 0 && music_url.rfind("http://", 0) != 0) return false;
    EnsureMp3Initialized();
    auto codec = Board::GetInstance().GetAudioCodec();
    if (!codec) return false;
    // Music takes the same exclusive external-output lane as the radio. Wake-word
    // detection remains available; the wake word ends playback through normal app flow.
    Application::GetInstance().GetAudioService().SetExternalOutputActive(true);
    codec->EnableOutput(true);
    std::string error;
    const bool started = mydazy::Mp3Player::GetInstance().Play(music_url, current_song_name_, &error);
    if (!started) {
        ESP_LOGE(TAG, "MP3 Play failed: %s", error.c_str());
        Application::GetInstance().GetAudioService().SetExternalOutputActive(false);
        is_playing_ = false;
        return false;
    }
    current_music_url_ = music_url;
    is_playing_ = true;
    g_component_playing.store(true);
    return true;
}

bool Esp32Music::StopStreaming() {
    mydazy::Mp3Player::GetInstance().Stop();
    g_component_playing.store(false);
    is_playing_ = false;
    is_downloading_ = false;
    Application::GetInstance().GetAudioService().SetExternalOutputActive(false);
    return true;
}

size_t Esp32Music::GetBufferSize() const { return 0; }
bool Esp32Music::IsDownloading() const { return is_downloading_.load(); }
int16_t* Esp32Music::GetAudioData() { return nullptr; }
bool Esp32Music::IsPlaying() const { return g_component_playing.load() || mydazy::Mp3Player::GetInstance().IsPlaying(); }

# v95-8 audio scheduling optimization

Based on the v95-7 archive source tree. Changes are limited to audio task scheduling and playback queue depth:
- Pin `audio_input` and `opus_codec` to Core 1 to reduce contention with Wi-Fi/network activity on Core 0.
- In voice mode, lower `audio_input` priority from 9 to 8 and raise `audio_output` from 8 to 9.
- Increase `MAX_PLAYBACK_TASKS_IN_QUEUE` from 2 to 4.

Static archive checks passed. This source has not been compiled by ESP-IDF or tested on the device in this environment.

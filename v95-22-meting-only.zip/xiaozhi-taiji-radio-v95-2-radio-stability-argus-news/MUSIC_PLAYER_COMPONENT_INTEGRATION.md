# Music player component integration

- Music search uses only the public Meting API hosted at `https://meting.mtr.pub/` with the NetEase catalog.
- Search results are parsed for track title, artist and track ID; the audio endpoint is then queried and may redirect to the media stream.
- No 33ve or Muzofond fallback is enabled. If Meting does not return a playable stream, the tool reports failure and logs details rather than silently trying unrelated sources.
- The API is a third-party public service and may be unavailable, rate-limited, or change without notice.

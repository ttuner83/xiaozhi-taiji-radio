/*
 * MCP Server Implementation
 * Reference: https://modelcontextprotocol.io/specification/2024-11-05
 */

#include "mcp_server.h"
#include <esp_app_desc.h>
#include <esp_heap_caps.h>
#include <esp_log.h>
#include <esp_pthread.h>
#include <dirent.h>
#include <algorithm>
#include <atomic>
#include <cctype>
#include <cstdio>
#include <cstring>
#include <memory>

#include "application.h"
#include "board.h"
#include "display.h"
#include "features/music/esp32_radio.h"
#include "lcd_display.h"
#include "lvgl_display.h"
#include "lvgl_theme.h"
#include "jpeg_to_image.h"
#include "oled_display.h"
#include "settings.h"

#include "picture_decoder.h"

#define TAG "MCP"

#ifdef HAVE_LVGL
// EXIF: parse the Orientation tag (0x0112) from the APP1 "Exif\0\0" segment.
// Returns 1 (normal) when the tag is absent or unreadable, or a value 1..8.
static uint8_t JpegExifOrientation(const uint8_t* src, size_t len) {
    size_t pos = 2;
    while (pos + 4 <= len) {
        if (src[pos] != 0xFF) {
            return 1;
        }
        const uint8_t m = src[pos + 1];
        if (m == 0xD8 || m == 0x01 || (m >= 0xD0 && m <= 0xD7) || m == 0xD9) {
            return 1;
        }
        const uint16_t seg_len = (uint16_t)((src[pos + 2] << 8) | src[pos + 3]);
        if (seg_len < 2 || pos + 2 + (size_t)seg_len > len) {
            return 1;
        }
        if (m == 0xE1 && seg_len >= 8) {
            const uint8_t* p = src + pos + 2;
            // The Exif payload is not guaranteed to start at the beginning of APP1: some
            // phones prepend a marker-like blob (e.g. 0xFF 0x7C). Scan for "Exif\0\0".
            for (size_t i = 0; i + 6 <= (size_t)seg_len; i++) {
                if (p[i] != 'E' || p[i + 1] != 'x' || p[i + 2] != 'i' || p[i + 3] != 'f' ||
                    p[i + 4] != 0 || p[i + 5] != 0) {
                    continue;
                }
                const uint8_t* t = p + i + 6;
                const size_t avail = len - (pos + 2 + i + 6);
                if (avail >= 8) {
                    const bool le = (t[0] == 'I' && t[1] == 'I');
                    if (le || (t[0] == 'M' && t[1] == 'M')) {
                        auto rd16 = [le](const uint8_t* q) {
                            return le ? (uint16_t)(q[0] | (q[1] << 8))
                                      : (uint16_t)((q[0] << 8) | q[1]);
                        };
                        auto rd32 = [le](const uint8_t* q) {
                            return le ? (uint32_t)(q[0] | (q[1] << 8) | (q[2] << 16) |
                                                   ((uint32_t)q[3] << 24))
                                      : (uint32_t)(((uint32_t)q[0] << 24) |
                                                   ((uint32_t)q[1] << 16) | (q[2] << 8) | q[3]);
                        };
                        if (rd16(t + 2) == 42) {
                            const uint32_t ifd = rd32(t + 4);
                            const size_t cap = avail;
                            if ((size_t)ifd + 2 <= cap) {
                                const uint8_t* ifdp = t + ifd;
                                const uint16_t count = rd16(ifdp);
                                if ((size_t)ifd + 2 + (size_t)count * 12 <= cap) {
                                    for (uint16_t k = 0; k < count; k++) {
                                        const uint8_t* ent = ifdp + 2 + (size_t)k * 12;
                                        if (rd16(ent) == 0x0112) {
                                            const uint16_t val = rd16(ent + 8);
                                            if (val >= 1 && val <= 8) {
                                                return (uint8_t)val;
                                            }
                                            return 1;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                break;
            }
        }
        pos += 2 + (size_t)seg_len;
    }
    return 1;
}

// Rotate a full RGB565 frame (stride == width * 2) per EXIF orientation 2..8.
// 'out' must already be allocated with room for the result. For orientations 5-8 the
// dimensions are swapped (output width == input height).
static void RotateRgb565(const uint8_t* in, size_t w, size_t h, uint8_t ori, uint8_t* out,
                         size_t* out_w, size_t* out_h) {
    size_t ow = w, oh = h;
    if (ori >= 5 && ori <= 8) {
        ow = h;
        oh = w;
    }
    *out_w = ow;
    *out_h = oh;
    for (size_t y = 0; y < oh; y++) {
        uint8_t* dst = out + y * ow * 2;
        for (size_t x = 0; x < ow; x++) {
            size_t sx = x, sy = y;
            switch (ori) {
                case 2:
                    sx = w - 1 - x;
                    break;
                case 3:
                    sx = w - 1 - x;
                    sy = h - 1 - y;
                    break;
                case 4:
                    sy = h - 1 - y;
                    break;
                case 5:
                    sx = y;
                    sy = x;
                    break;
                case 6:
                    sx = y;
                    sy = h - 1 - x;
                    break;
                case 7:
                    sx = h - 1 - y;
                    sy = w - 1 - x;
                    break;
                case 8:
                    sx = w - 1 - y;
                    sy = x;
                    break;
                default:
                    break;
            }
            dst[x * 2] = in[sy * w * 2 + sx * 2];
            dst[x * 2 + 1] = in[sy * w * 2 + sx * 2 + 1];
        }
    }
}

// Decode the picture at 'files[index]' and show it on the LCD. Returns an empty string on
// success or a Russian error message on failure. JPEG files are rotated according to their
// EXIF orientation.
static std::string ShowPictureFile(LcdDisplay* lcd, const std::vector<std::string>& files,
                                   size_t index) {
    const size_t kMaxFileBytes = 12 * 1024 * 1024;
    FILE* fp = fopen(files[index].c_str(), "rb");
    if (fp == nullptr) {
        ESP_LOGE(TAG, "pictures.show: cannot open '%s'", files[index].c_str());
        return "Ошибка: не удалось открыть файл картинки.";
    }
    if (fseek(fp, 0, SEEK_END) != 0) {
        fclose(fp);
        return "Ошибка: не удалось прочитать файл картинки.";
    }
    long file_size = ftell(fp);
    rewind(fp);
    if (file_size <= 0 || (unsigned long)file_size > kMaxFileBytes) {
        ESP_LOGE(TAG, "pictures.show: bad file size %ld for '%s'", file_size,
                 files[index].c_str());
        fclose(fp);
        return file_size <= 0 ? "Ошибка: пустой файл картинки."
                              : "Ошибка: файл картинки слишком большой.";
    }

    char* data = (char*)heap_caps_malloc((size_t)file_size, MALLOC_CAP_8BIT);
    if (data == nullptr) {
        ESP_LOGE(TAG, "pictures.show: malloc(%ld) failed", file_size);
        fclose(fp);
        return "Ошибка: недостаточно памяти для картинки.";
    }
    size_t read_bytes = fread(data, 1, (size_t)file_size, fp);
    fclose(fp);
    if (read_bytes != (size_t)file_size) {
        ESP_LOGE(TAG, "pictures.show: read %d of %ld bytes", (int)read_bytes, file_size);
        heap_caps_free(data);
        return "Ошибка: не удалось прочитать файл картинки.";
    }

    std::string pic_ext = files[index].substr(files[index].find_last_of('.') + 1);
    std::transform(pic_ext.begin(), pic_ext.end(), pic_ext.begin(),
                   [](unsigned char c) { return std::tolower(c); });
    const bool is_jpeg = (pic_ext == "jpg" || pic_ext == "jpeg");

    LvglAllocatedImage* raw = nullptr;
    if (is_jpeg) {
        // LVGL's in-memory JPEG decoder needs a pre-filled header (and LV_USE_FS_MEMFS),
        // which we don't have. Decode to RGB565 ourselves and build the dsc directly.
        // NOTE: jpeg_to_image() rounds dimensions up to a multiple of 16, so scale to
        // fit later in ShowPicture.
        uint8_t* decoded = nullptr;
        size_t decoded_len = 0, img_w = 0, img_h = 0, stride = 0;
        esp_err_t jerr = jpeg_to_image((const uint8_t*)data, (size_t)file_size, &decoded,
                                       &decoded_len, &img_w, &img_h, &stride);
        if (jerr != ESP_OK || decoded == nullptr) {
            ESP_LOGW(TAG, "pictures.show: jpeg decode failed (%s) for '%s', trying "
                     "progressive fallback",
                     esp_err_to_name(jerr), files[index].c_str());
            // esp_new_jpeg doesn't support progressive JPEG scans. Try stb_image.
            jerr = DecodeProgressiveJpeg((const uint8_t*)data, (size_t)file_size, &decoded,
                                         &decoded_len, &img_w, &img_h, &stride);
            if (jerr != ESP_OK || decoded == nullptr) {
                ESP_LOGE(TAG,
                         "pictures.show: progressive jpeg decode failed (%s) for '%s'",
                         esp_err_to_name(jerr), files[index].c_str());
                heap_caps_free(data);
                return "Ошибка: не удалось распознать изображение (JPG повреждён или "
                       "слишком большой).";
            }
        }
        const uint8_t orientation = JpegExifOrientation((const uint8_t*)data, (size_t)file_size);
        heap_caps_free(data);
        data = (char*)decoded;
        file_size = (long)decoded_len;
        if (orientation != 1 && img_w > 0 && img_h > 0) {
            size_t ow = 0, oh = 0;
            uint8_t* rotated =
                (uint8_t*)heap_caps_malloc(img_h * img_w * 2, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
            if (rotated != nullptr) {
                RotateRgb565(decoded, img_w, img_h, orientation, rotated, &ow, &oh);
                heap_caps_free(decoded);
                decoded = rotated;
                file_size = (long)(ow * oh * 2);
                img_w = ow;
                img_h = oh;
                stride = ow * 2;
                data = (char*)decoded;
            }
        }
        try {
            // Second ctor takes explicit w/h/stride/cf, no header parsing.
            raw = new LvglAllocatedImage(data, (size_t)file_size, (int)img_w, (int)img_h,
                                         (int)stride, LV_COLOR_FORMAT_RGB565);
        } catch (...) {
            heap_caps_free(data);
            return "Ошибка: не удалось распознать изображение.";
        }
    } else if (pic_ext == "png") {
        // LVGL's PNG pipeline decodes into an ARGB8888 draw buffer at draw time and must
        // fit the LVGL image cache; large PNGs render black. Decode to RGB565 ourselves.
        uint8_t* decoded = nullptr;
        size_t decoded_len = 0, img_w = 0, img_h = 0, stride = 0;
        esp_err_t perr = DecodePngToRgb565((const uint8_t*)data, (size_t)file_size, &decoded,
                                           &decoded_len, &img_w, &img_h, &stride);
        if (perr != ESP_OK || decoded == nullptr) {
            ESP_LOGE(TAG, "pictures.show: png decode failed (%s) for '%s'",
                     esp_err_to_name(perr), files[index].c_str());
            heap_caps_free(data);
            return "Ошибка: не удалось распознать изображение (PNG повреждён или "
                   "слишком большой).";
        }
        heap_caps_free(data);
        data = (char*)decoded;
        file_size = (long)decoded_len;
        try {
            raw = new LvglAllocatedImage(data, (size_t)file_size, (int)img_w, (int)img_h,
                                         (int)stride, LV_COLOR_FORMAT_RGB565);
        } catch (...) {
            heap_caps_free(data);
            return "Ошибка: не удалось распознать изображение.";
        }
    } else {
        try {
            raw = new LvglAllocatedImage(data, (size_t)file_size);
        } catch (...) {
            ESP_LOGE(TAG, "pictures.show: decode header failed for '%s'",
                     files[index].c_str());
            heap_caps_free(data);
            return "Ошибка: не удалось распознать изображение. Поддерживаются JPG, "
                   "PNG, BMP.";
        }
    }
    std::unique_ptr<LvglAllocatedImage> picture(raw);

    const auto& header = picture->image_dsc()->header;
    // JPEG is decoded to a full RGB565 buffer in PSRAM up front. PNG/BMP decode to a
    // full buffer too, so keep those smaller, but a 240x240 target does not need much.
    const uint32_t max_side = is_jpeg ? 16384 : 4096;
    const size_t max_decoded = 64 * 1024 * 1024;
    const size_t decoded_bytes = (size_t)header.w * (size_t)header.h * 2;
    if (header.w == 0 || header.h == 0 || header.w > max_side || header.h > max_side ||
        decoded_bytes > max_decoded) {
        ESP_LOGE(TAG, "pictures.show: size limit for '%s' %dx%d (%d dec bytes, jpeg=%d)",
                 files[index].c_str(), header.w, header.h, (int)decoded_bytes, (int)is_jpeg);
        return is_jpeg ? "Ошибка: слишком большое изображение (JPG)."
                       : "Ошибка: слишком большое изображение (PNG/BMP). Для экрана "
                         "240x240 достаточно примерно 2800x2800.";
    }

    ESP_LOGI(TAG, "pictures.show: showing '%s' (%ld bytes, %dx%d)", files[index].c_str(),
             file_size, header.w, header.h);
    if (!lcd->ShowPicture(std::move(picture))) {
        ESP_LOGE(TAG, "pictures.show: LcdDisplay::ShowPicture returned false");
        return "Ошибка: не удалось показать картинку.";
    }
    return "";
}

struct SlideshowArgs {
    LcdDisplay* lcd;
    int interval;
    std::vector<std::string> files;
    std::shared_ptr<std::atomic<bool>> running;
};

static void SlideshowTask(void* arg) {
    auto* a = static_cast<SlideshowArgs*>(arg);
    ESP_LOGI(TAG, "slideshow: task started (%d files, %d s interval)", (int)a->files.size(),
             a->interval);
    // Keep the current picture on screen regardless of transient device states
    // (e.g. the listening state that follows the launch command).
    a->lcd->SetSlideshowActive(true);
    size_t index = 0;
    bool stop = false;
    while (!stop) {
        if (!a->running->load()) {
            break;
        }
        std::string err = ShowPictureFile(a->lcd, a->files, index);
        if (err.empty()) {
            ESP_LOGI(TAG, "slideshow: showing '%s'", a->files[index].c_str());
        } else {
            ESP_LOGW(TAG, "slideshow: '%s' -> %s", a->files[index].c_str(), err.c_str());
        }
        index = (index + 1) % a->files.size();
        for (int s = 0; s < a->interval && !stop; ++s) {
            if (!a->running->load()) {
                stop = true;
                break;
            }
            vTaskDelay(pdMS_TO_TICKS(1000));
        }
    }
    a->running->store(false);
    a->lcd->SetSlideshowActive(false);
    delete a;
    vTaskDelete(nullptr);
}
#endif  // HAVE_LVGL

McpServer::McpServer() {}

McpServer::~McpServer() {
    for (auto tool : tools_) {
        delete tool;
    }
    tools_.clear();
}

void McpServer::AddCommonTools() {
    // *Important* To speed up the response time, we add the common tools to the beginning of
    // the tools list to utilize the prompt cache.
    // **重要** 为了提升响应速度，我们把常用的工具放在前面，利用 prompt cache 的特性。

    // Backup the original tools list and restore it after adding the common tools.
    auto original_tools = std::move(tools_);
    auto& board = Board::GetInstance();

    // Do not add custom tools here.
    // Custom tools must be added in the board's InitializeTools function.

    AddTool("self.get_device_status",
            "Provides the real-time information of the device, including the current status of the "
            "audio speaker, screen, battery, network, etc.\n"
            "Use this tool for: \n"
            "1. Answering questions about current condition (e.g. what is the current volume of "
            "the audio speaker?)\n"
            "2. As the first step to control the device (e.g. turn up / down the volume of the "
            "audio speaker, etc.)",
            PropertyList(), [&board](const PropertyList& properties) -> ReturnValue {
                return board.GetDeviceStatusJson();
            });

    AddTool("self.audio_speaker.set_volume",
            "Set the volume of the audio speaker. If the current volume is unknown, you must call "
            "`self.get_device_status` tool first and then call this tool.",
            PropertyList({Property("volume", kPropertyTypeInteger, 0, 100)}),
            [&board](const PropertyList& properties) -> ReturnValue {
                auto codec = board.GetAudioCodec();
                codec->SetOutputVolume(properties["volume"].value<int>());
                return true;
            });

    auto backlight = board.GetBacklight();
    if (backlight) {
        AddTool("self.screen.set_brightness", "Set the brightness of the screen.",
                PropertyList({Property("brightness", kPropertyTypeInteger, 0, 100)}),
                [backlight](const PropertyList& properties) -> ReturnValue {
                    uint8_t brightness =
                        static_cast<uint8_t>(properties["brightness"].value<int>());
                    backlight->SetBrightness(brightness, true);
                    return true;
                });
    }

#ifdef HAVE_LVGL
    auto display = board.GetDisplay();
    if (display && display->GetTheme() != nullptr) {
        AddTool("self.screen.set_theme",
                "Set the theme of the screen. The theme can be `light` or `dark`.",
                PropertyList({Property("theme", kPropertyTypeString)}),
                [display](const PropertyList& properties) -> ReturnValue {
                    auto theme_name = properties["theme"].value<std::string>();
                    auto& theme_manager = LvglThemeManager::GetInstance();
                    auto theme = theme_manager.GetTheme(theme_name);
                    if (theme != nullptr) {
                        display->SetTheme(theme);
                        return true;
                    }
                    return false;
                });
    }

    auto camera = board.GetCamera();
    if (camera) {
        AddTool("self.camera.take_photo",
                "Always remember you have a camera. If the user asks you to see something, use "
                "this tool to take a photo and then explain it.\n"
                "Args:\n"
                "  `question`: The question that you want to ask about the photo.\n"
                "Return:\n"
                "  A JSON object that provides the photo information.",
                PropertyList({Property("question", kPropertyTypeString)}),
                [camera](const PropertyList& properties) -> ReturnValue {
                    // Lower the priority to do the camera capture
                    TaskPriorityReset priority_reset(1);

                    if (!camera->Capture()) {
                        throw std::runtime_error("Failed to capture photo");
                    }
                    auto question = properties["question"].value<std::string>();
                    return camera->Explain(question);
                });
    }
#endif

    // Internet radio control
    auto radio = Application::GetInstance().GetRadio();
    if (radio) {
        AddTool("self.radio.play_station",
                "Play a radio station by name. Station names are in Russian; names/keywords are "
                "matched case-insensitively (partial match also works). Example station names: "
                "'Маяк', 'Европа Плюс', 'Авторадио', 'Ретро FM', 'Радио Шансон'. Use "
                "self.radio.get_stations to list all stations.",
                PropertyList({Property("station_name", kPropertyTypeString)}),
                [radio](const PropertyList& properties) -> ReturnValue {
                    auto station_name = properties["station_name"].value<std::string>();
                    if (radio->PlayStation(station_name)) {
                        return "Playing radio station: " + station_name;
                    }
                    return "Ошибка: станция не найдена. Используйте self.radio.get_stations для "
                           "списка станций. Пример: Маяк, Европа Плюс, Авторадио";
                });
        AddTool("self.radio.play_url",
                "Play a custom radio stream by direct URL (http/https mp3 or aac stream).",
                PropertyList({Property("url", kPropertyTypeString)}),
                [radio](const PropertyList& properties) -> ReturnValue {
                    auto url = properties["url"].value<std::string>();
                    if (radio->PlayUrl(url, "")) {
                        return "Playing radio url: " + url;
                    }
                    return "Ошибка: не удалось начать воспроизведение URL";
                });
        AddTool("self.radio.stop", "Stop the currently playing radio stream.", PropertyList(),
                [radio](const PropertyList& properties) -> ReturnValue {
                    radio->Stop();
                    return "Stopping radio";
                });
        AddTool("self.radio.get_stations",
                "List all available radio stations with their keys and display names.",
                PropertyList(), [radio](const PropertyList& properties) -> ReturnValue {
                    std::string response = "Available radio stations:\n";
                    for (const auto& s : radio->GetStationList()) {
                        response += "- " + s + "\n";
                    }
                    return response;
                });

        AddTool(
            "self.music.play",
            "Play music files from the microSD card inserted into the device, from the 'music' "
            "folder. Optional 'track' parameter: a track number from self.music.list (starting "
            "from 1), or a part of the file name (case-insensitive). Without 'track', plays the "
            "whole folder in alphabetical order and stops at the end of the playlist.",
            PropertyList({Property("track", kPropertyTypeString, std::string())}),
            [radio](const PropertyList& properties) -> ReturnValue {
                std::string track = properties["track"].value<std::string>();
                if (radio->PlayFile(track)) {
                    if (track.empty()) {
                        return "Playing music from SD card (playlist)";
                    }
                    return "Playing music from SD card: " + track;
                }
                return "Ошибка: не удалось запустить музыку. Проверьте, что microSD-карта "
                       "вставлена и в папке 'music' есть аудиофайлы (mp3, aac, wav, ogg, flac).";
            });
        AddTool(
            "self.music.list",
            "List the music tracks found on the microSD card in the 'music' folder, numbered from "
            "1.",
            PropertyList(), [radio](const PropertyList& properties) -> ReturnValue {
                auto tracks = radio->GetMusicTracks();
                if (tracks.empty()) {
                    return "Ошибка: музыка не найдена. Проверьте SD-карту и папку 'music' на ней.";
                }
                std::string response = "Музыка на SD-карте:\n";
                for (size_t i = 0; i < tracks.size(); ++i) {
                    size_t pos = tracks[i].rfind('/');
                    std::string name =
                        (pos == std::string::npos) ? tracks[i] : tracks[i].substr(pos + 1);
                    response += std::to_string(i + 1) + ". " + name + "\n";
                }
                return response;
            });
        AddTool("self.music.stop", "Stop SD card music playback.", PropertyList(),
                [radio](const PropertyList& properties) -> ReturnValue {
                    radio->Stop();
                    return "Stopping music";
                });
    }

    // Restore the original tools list to the end of the tools list
    tools_.insert(tools_.end(), original_tools.begin(), original_tools.end());
}

void McpServer::AddUserOnlyTools() {
    // System tools
    AddUserOnlyTool("self.get_system_info", "Get the system information", PropertyList(),
                    [this](const PropertyList& properties) -> ReturnValue {
                        auto& board = Board::GetInstance();
                        return board.GetSystemInfoJson();
                    });

    AddUserOnlyTool("self.reboot", "Reboot the system", PropertyList(),
                    [this](const PropertyList& properties) -> ReturnValue {
                        auto& app = Application::GetInstance();
                        app.Schedule([&app]() {
                            ESP_LOGW(TAG, "User requested reboot");
                            vTaskDelay(pdMS_TO_TICKS(1000));

                            app.Reboot();
                        });
                        return true;
                    });

    // Firmware upgrade
    AddUserOnlyTool(
        "self.upgrade_firmware",
        "Upgrade firmware from a specific URL. This will download and install the firmware, then "
        "reboot the device.",
        PropertyList({Property("url", kPropertyTypeString,
                               "The URL of the firmware binary file to download and install")}),
        [this](const PropertyList& properties) -> ReturnValue {
            auto url = properties["url"].value<std::string>();
            ESP_LOGI(TAG, "User requested firmware upgrade from URL: %s", url.c_str());

            auto& app = Application::GetInstance();
            app.Schedule([url, &app]() {
                bool success = app.UpgradeFirmware(url);
                if (!success) {
                    ESP_LOGE(TAG, "Firmware upgrade failed");
                }
            });

            return true;
        });

    // Display control
#ifdef HAVE_LVGL
    auto display = dynamic_cast<LvglDisplay*>(Board::GetInstance().GetDisplay());
    if (display) {
        AddUserOnlyTool("self.screen.get_info",
                        "Information about the screen, including width, height, etc.",
                        PropertyList(), [display](const PropertyList& properties) -> ReturnValue {
                            cJSON* json = cJSON_CreateObject();
                            cJSON_AddNumberToObject(json, "width", display->width());
                            cJSON_AddNumberToObject(json, "height", display->height());
                            if (dynamic_cast<OledDisplay*>(display)) {
                                cJSON_AddBoolToObject(json, "monochrome", true);
                            } else {
                                cJSON_AddBoolToObject(json, "monochrome", false);
                            }
                            return json;
                        });

#if CONFIG_LV_USE_SNAPSHOT
        AddUserOnlyTool(
            "self.screen.snapshot", "Snapshot the screen and upload it to a specific URL",
            PropertyList({Property("url", kPropertyTypeString),
                          Property("quality", kPropertyTypeInteger, 80, 1, 100)}),
            [display](const PropertyList& properties) -> ReturnValue {
                auto url = properties["url"].value<std::string>();
                auto quality = properties["quality"].value<int>();

                std::string jpeg_data;
                if (!display->SnapshotToJpeg(jpeg_data, quality)) {
                    throw std::runtime_error("Failed to snapshot screen");
                }

                ESP_LOGI(TAG, "Upload snapshot %u bytes to %s", jpeg_data.size(), url.c_str());

                // 构造multipart/form-data请求体
                std::string boundary = "----ESP32_SCREEN_SNAPSHOT_BOUNDARY";

                auto http = Board::GetInstance().GetNetwork()->CreateHttp(3);
                http->SetHeader("Content-Type", "multipart/form-data; boundary=" + boundary);
                if (!http->Open("POST", url)) {
                    throw std::runtime_error("Failed to open URL: " + url);
                }
                {
                    // 文件字段头部
                    std::string file_header;
                    file_header += "--" + boundary + "\r\n";
                    file_header +=
                        "Content-Disposition: form-data; name=\"file\"; "
                        "filename=\"screenshot.jpg\"\r\n";
                    file_header += "Content-Type: image/jpeg\r\n";
                    file_header += "\r\n";
                    http->Write(file_header.c_str(), file_header.size());
                }

                // JPEG数据
                http->Write((const char*)jpeg_data.data(), jpeg_data.size());

                {
                    // multipart尾部
                    std::string multipart_footer;
                    multipart_footer += "\r\n--" + boundary + "--\r\n";
                    http->Write(multipart_footer.c_str(), multipart_footer.size());
                }
                http->Write("", 0);

                if (http->GetStatusCode() != 200) {
                    throw std::runtime_error("Unexpected status code: " +
                                             std::to_string(http->GetStatusCode()));
                }
                std::string result = http->ReadAll();
                http->Close();
                ESP_LOGI(TAG, "Snapshot screen result: %s", result.c_str());
                return true;
            });

        AddUserOnlyTool(
            "self.screen.preview_image", "Preview an image on the screen",
            PropertyList({Property("url", kPropertyTypeString)}),
            [display](const PropertyList& properties) -> ReturnValue {
                auto url = properties["url"].value<std::string>();
                auto http = Board::GetInstance().GetNetwork()->CreateHttp(3);

                if (!http->Open("GET", url)) {
                    throw std::runtime_error("Failed to open URL: " + url);
                }
                int status_code = http->GetStatusCode();
                if (status_code != 200) {
                    throw std::runtime_error("Unexpected status code: " +
                                             std::to_string(status_code));
                }

                size_t content_length = http->GetBodyLength();
                char* data = (char*)heap_caps_malloc(content_length, MALLOC_CAP_8BIT);
                if (data == nullptr) {
                    throw std::runtime_error("Failed to allocate memory for image: " + url);
                }
                size_t total_read = 0;
                while (total_read < content_length) {
                    int ret = http->Read(data + total_read, content_length - total_read);
                    if (ret < 0) {
                        heap_caps_free(data);
                        throw std::runtime_error("Failed to download image: " + url);
                    }
                    if (ret == 0) {
                        break;
                    }
                    total_read += ret;
                }
                http->Close();

                auto image = std::make_unique<LvglAllocatedImage>(data, content_length);
                display->SetPreviewImage(std::move(image));
                return true;
            });
#endif  // CONFIG_LV_USE_SNAPSHOT
    }

    // Pictures from the microSD card ("pictures" folder), shown on the screen.
    auto lcd = dynamic_cast<LcdDisplay*>(display);
    if (lcd) {
        auto current_picture_index = std::make_shared<std::atomic<size_t>>(0);

        auto list_pictures = []() -> std::vector<std::string> {
            std::vector<std::string> files;
            auto& board = Board::GetInstance();
            std::string dir_path = board.GetSdCardMountPoint();
            if (board.IsSdCardAvailable() && !dir_path.empty()) {
                dir_path += "/pictures";
            } else {
                return files;
            }
            DIR* dir = opendir(dir_path.c_str());
            if (dir == nullptr) {
                return files;
            }
            struct dirent* entry = nullptr;
            while ((entry = readdir(dir)) != nullptr) {
                if (entry->d_type != DT_REG) {
                    continue;
                }
                std::string name = entry->d_name;
                std::string ext = name.substr(name.find_last_of('.') + 1);
                std::transform(ext.begin(), ext.end(), ext.begin(),
                               [](unsigned char c) { return std::tolower(c); });
                if (ext != "jpg" && ext != "jpeg" && ext != "png" && ext != "bmp") {
                    continue;
                }
                files.push_back(dir_path + "/" + name);
            }
            closedir(dir);
            std::sort(files.begin(), files.end());
            return files;
        };

        auto base_name = [](const std::string& path) -> std::string {
            size_t pos = path.rfind('/');
            return (pos == std::string::npos) ? path : path.substr(pos + 1);
        };

        // Resolve a user-provided 'name' (number or file-name part) to an index in 'files'.
        // Leaves 'index' untouched when 'name' is empty. Returns an error message on failure.
        auto resolve_index = [base_name](const std::vector<std::string>& files,
                                         const std::string& name,
                                         size_t& index) -> std::string {
            if (name.empty()) {
                return "";
            }
            try {
                size_t num = std::stoul(name);
                if (num >= 1 && num <= files.size()) {
                    index = num - 1;
                    return "";
                }
            } catch (...) {
            }
            std::string needle = name;
            std::transform(needle.begin(), needle.end(), needle.begin(),
                           [](unsigned char c) { return std::tolower(c); });
            for (size_t i = 0; i < files.size(); ++i) {
                std::string fname = base_name(files[i]);
                std::transform(fname.begin(), fname.end(), fname.begin(),
                               [](unsigned char c) { return std::tolower(c); });
                if (fname.find(needle) != std::string::npos) {
                    index = i;
                    return "";
                }
            }
            return "Ошибка: картинка не найдена. Используйте self.pictures.list для списка.";
        };

        AddTool(
            "self.pictures.list",
            "List the picture files found on the microSD card in the 'pictures' folder, numbered "
            "from 1. Supported formats: JPG, JPEG, PNG, BMP.",
            PropertyList(), [list_pictures](const PropertyList&) -> ReturnValue {
                auto files = list_pictures();
                if (files.empty()) {
                    return "Ошибка: картинки не найдены. Проверьте, что microSD-карта вставлена и "
                           "в папке 'pictures' есть файлы (jpg, png, bmp).";
                }
                std::string response = "Картинки на SD-карте:\n";
                for (size_t i = 0; i < files.size(); ++i) {
                    size_t pos = files[i].rfind('/');
                    response += std::to_string(i + 1) + ". " +
                                ((pos == std::string::npos) ? files[i] : files[i].substr(pos + 1)) +
                                "\n";
                }
                return response;
            });

        auto slideshow_running = std::make_shared<std::atomic<bool>>(false);
        auto stop_slideshow = [slideshow_running, lcd]() {
            bool expected = true;
            if (!slideshow_running->compare_exchange_strong(expected, false)) {
                return;  // not running
            }
            lcd->SetSlideshowActive(false);
            lcd->HidePicture();
        };
        lcd->SetSlideshowStopCallback(stop_slideshow);
AddTool(
            "self.pictures.show",
            "Show a picture from the microSD card 'pictures' folder on the screen. Optional "
            "'name' parameter: a picture number from self.pictures.list (starting from 1), or a "
            "part of the file name (case-insensitive). Without 'name', shows the next picture in "
            "the folder. The picture stays on the screen while the device is idle; it disappears "
            "when the user starts talking (e.g. to give the next command) or when "
            "self.pictures.hide is called.",
            PropertyList({Property("name", kPropertyTypeString, std::string())}),
            [list_pictures, base_name, lcd, current_picture_index,
             stop_slideshow, resolve_index](const PropertyList& properties) -> ReturnValue {
                std::string name = properties["name"].value<std::string>();
                stop_slideshow();
                auto files = list_pictures();
                ESP_LOGI(TAG, "pictures.show: name='%s', %d files found", name.c_str(),
                         (int)files.size());
                if (files.empty()) {
                    return "Ошибка: картинки не найдены. Проверьте SD-карту и папку 'pictures'.";
                }

                size_t index = 0;
                if (name.empty()) {
                    index = (*current_picture_index + 1) % files.size();
                } else {
                    std::string err = resolve_index(files, name, index);
                    if (!err.empty()) {
                        return err;
                    }
                }
                *current_picture_index = index;

                std::string perr = ShowPictureFile(lcd, files, index);
                if (!perr.empty()) {
                    return perr;
                }
                return "Показываю картинку: " + base_name(files[index]);
            });

        AddTool(
            "self.pictures.pin",
            "Show a picture from the microSD card 'pictures' folder on the screen and keep it "
            "there until the user touches the screen or until self.pictures.hide or "
            "self.pictures.slideshow.stop is called. Use this tool when the user asks to show a "
            "picture and leave it on the screen (e.g. \"покажи картинку 2 и не убирай\", "
            "\"оставь фото на экране\", \"выведи картинку пока я не коснусь экрана\"). Optional "
            "'name' parameter: a picture number "
            "from self.pictures.list (starting from 1), or a part of the file name "
            "(case-insensitive). Without 'name', shows the next picture in the folder. Unlike "
            "self.pictures.show, the picture stays on screen when the user talks and the screen "
            "does not go to sleep.",
            PropertyList({Property("name", kPropertyTypeString, std::string())}),
            [list_pictures, base_name, lcd, current_picture_index, slideshow_running,
             resolve_index](const PropertyList& properties) -> ReturnValue {
                std::string name = properties["name"].value<std::string>();
                auto files = list_pictures();
                ESP_LOGI(TAG, "pictures.pin: name='%s', %d files found", name.c_str(),
                         (int)files.size());
                if (files.empty()) {
                    return "Ошибка: картинки не найдены. Проверьте SD-карту и папку 'pictures'.";
                }

                size_t index = 0;
                if (name.empty()) {
                    index = (*current_picture_index + 1) % files.size();
                } else {
                    std::string err = resolve_index(files, name, index);
                    if (!err.empty()) {
                        return err;
                    }
                }
                *current_picture_index = index;

                bool expected = false;
                if (!slideshow_running->compare_exchange_strong(expected, true)) {
                    return "Ошибка: слайдшоу уже запущено. Сначала остановите его.";
                }
                lcd->SetSlideshowActive(true);
                std::string perr = ShowPictureFile(lcd, files, index);
                if (!perr.empty()) {
                    slideshow_running->store(false);
                    lcd->SetSlideshowActive(false);
                    return perr;
                }
                return "Показываю картинку: " + base_name(files[index]) +
                       ". Она останется на экране, пока не коснётесь экрана.";
            });

        AddTool("self.pictures.hide",
                "Hide the currently displayed picture and return "
                "to the eyes.",
                PropertyList(), [lcd, stop_slideshow](const PropertyList&) -> ReturnValue {
                    stop_slideshow();
                    lcd->HidePicture();
                    return "Картинка скрыта";
                });

        AddTool(
            "self.pictures.slideshow",
            "Start a slideshow: show every picture from the 'pictures' folder on the screen, in "
            "alphabetical order, switching to the next picture every 'interval' seconds (default "
            "60). The slideshow runs until it is stopped with self.pictures.slideshow.stop or "
            "another picture command is issued.",
            PropertyList({Property("interval", kPropertyTypeInteger, 60, 5, 3600)}),
            [list_pictures, lcd, slideshow_running](const PropertyList& properties)
                -> ReturnValue {
                auto files = list_pictures();
                if (files.empty()) {
                    return "Ошибка: картинки не найдены. Проверьте SD-карту и папку 'pictures'.";
                }
                int interval = properties["interval"].value<int>();
                bool expected = false;
                if (!slideshow_running->compare_exchange_strong(expected, true)) {
                    return "Слайдшоу уже запущено.";
                }
                lcd->SetSlideshowActive(true);
                auto* args = new SlideshowArgs{lcd, interval, std::move(files),
                                               slideshow_running};
                xTaskCreate(SlideshowTask, "slideshow", 32768, args, 3, nullptr);
                return "Запускаю слайдшоу: все картинки по очереди, каждые " +
                       std::to_string(interval) + " секунд.";
            });
        AddTool("self.pictures.slideshow.stop",
                "Stop the running slideshow and hide the current picture.",
                PropertyList(), [lcd, stop_slideshow](const PropertyList&) -> ReturnValue {
                    stop_slideshow();
                    lcd->HidePicture();
                    return "Слайдшоу остановлено.";
                });
    }
#endif  // HAVE_LVGL

    // Assets download url (always registered — Settings storage works regardless of partition
    // layout)
    AddUserOnlyTool("self.assets.set_download_url", "Set the download url for the assets",
                    PropertyList({Property("url", kPropertyTypeString)}),
                    [](const PropertyList& properties) -> ReturnValue {
                        auto url = properties["url"].value<std::string>();
                        Settings settings("assets", true);
                        settings.SetString("download_url", url);
                        return true;
                    });
}

void McpServer::AddTool(McpTool* tool) {
    // Prevent adding duplicate tools
    if (std::find_if(tools_.begin(), tools_.end(), [tool](const McpTool* t) {
            return t->name() == tool->name();
        }) != tools_.end()) {
        ESP_LOGW(TAG, "Tool %s already added", tool->name().c_str());
        return;
    }

    ESP_LOGI(TAG, "Add tool: %s%s", tool->name().c_str(), tool->user_only() ? " [user]" : "");
    tools_.push_back(tool);
}

void McpServer::AddTool(const std::string& name, const std::string& description,
                        const PropertyList& properties,
                        std::function<ReturnValue(const PropertyList&)> callback) {
    AddTool(new McpTool(name, description, properties, callback));
}

void McpServer::AddUserOnlyTool(const std::string& name, const std::string& description,
                                const PropertyList& properties,
                                std::function<ReturnValue(const PropertyList&)> callback) {
    auto tool = new McpTool(name, description, properties, callback);
    tool->set_user_only(true);
    AddTool(tool);
}

void McpServer::ParseMessage(const std::string& message) {
    cJSON* json = cJSON_Parse(message.c_str());
    if (json == nullptr) {
        ESP_LOGE(TAG, "Failed to parse MCP message: %s", message.c_str());
        return;
    }
    ParseMessage(json);
    cJSON_Delete(json);
}

void McpServer::ParseCapabilities(const cJSON* capabilities) {
    auto vision = cJSON_GetObjectItem(capabilities, "vision");
    if (cJSON_IsObject(vision)) {
        auto url = cJSON_GetObjectItem(vision, "url");
        auto token = cJSON_GetObjectItem(vision, "token");
        if (cJSON_IsString(url)) {
            auto camera = Board::GetInstance().GetCamera();
            if (camera) {
                std::string url_str = std::string(url->valuestring);
                std::string token_str;
                if (cJSON_IsString(token)) {
                    token_str = std::string(token->valuestring);
                }
                camera->SetExplainUrl(url_str, token_str);
            }
        }
    }
}

void McpServer::ParseMessage(const cJSON* json) {
    // Check JSONRPC version
    auto version = cJSON_GetObjectItem(json, "jsonrpc");
    if (version == nullptr || !cJSON_IsString(version) ||
        strcmp(version->valuestring, "2.0") != 0) {
        ESP_LOGE(TAG, "Invalid JSONRPC version: %s", version ? version->valuestring : "null");
        return;
    }

    // Check method
    auto method = cJSON_GetObjectItem(json, "method");
    if (method == nullptr || !cJSON_IsString(method)) {
        ESP_LOGE(TAG, "Missing method");
        return;
    }

    auto method_str = std::string(method->valuestring);
    if (method_str.find("notifications") == 0) {
        return;
    }

    // Check params
    auto params = cJSON_GetObjectItem(json, "params");
    if (params != nullptr && !cJSON_IsObject(params)) {
        ESP_LOGE(TAG, "Invalid params for method: %s", method_str.c_str());
        return;
    }

    auto id = cJSON_GetObjectItem(json, "id");
    if (id == nullptr || !cJSON_IsNumber(id)) {
        ESP_LOGE(TAG, "Invalid id for method: %s", method_str.c_str());
        return;
    }
    auto id_int = id->valueint;

    if (method_str == "initialize") {
        if (cJSON_IsObject(params)) {
            auto capabilities = cJSON_GetObjectItem(params, "capabilities");
            if (cJSON_IsObject(capabilities)) {
                ParseCapabilities(capabilities);
            }
        }
        auto app_desc = esp_app_get_description();
        std::string message =
            "{\"protocolVersion\":\"2024-11-05\",\"capabilities\":{\"tools\":{}},\"serverInfo\":{"
            "\"name\":\"" BOARD_NAME "\",\"version\":\"";
        message += app_desc->version;
        message += "\"}}";
        ReplyResult(id_int, message);
    } else if (method_str == "tools/list") {
        std::string cursor_str = "";
        bool list_user_only_tools = false;
        if (params != nullptr) {
            auto cursor = cJSON_GetObjectItem(params, "cursor");
            if (cJSON_IsString(cursor)) {
                cursor_str = std::string(cursor->valuestring);
            }
            auto with_user_tools = cJSON_GetObjectItem(params, "withUserTools");
            if (cJSON_IsBool(with_user_tools)) {
                list_user_only_tools = with_user_tools->valueint == 1;
            }
        }
        GetToolsList(id_int, cursor_str, list_user_only_tools);
    } else if (method_str == "tools/call") {
        if (!cJSON_IsObject(params)) {
            ESP_LOGE(TAG, "tools/call: Missing params");
            ReplyError(id_int, "Missing params");
            return;
        }
        auto tool_name = cJSON_GetObjectItem(params, "name");
        if (!cJSON_IsString(tool_name)) {
            ESP_LOGE(TAG, "tools/call: Missing name");
            ReplyError(id_int, "Missing name");
            return;
        }
        auto tool_arguments = cJSON_GetObjectItem(params, "arguments");
        if (tool_arguments != nullptr && !cJSON_IsObject(tool_arguments)) {
            ESP_LOGE(TAG, "tools/call: Invalid arguments");
            ReplyError(id_int, "Invalid arguments");
            return;
        }
        DoToolCall(id_int, std::string(tool_name->valuestring), tool_arguments);
    } else {
        ESP_LOGE(TAG, "Method not implemented: %s", method_str.c_str());
        ReplyError(id_int, "Method not implemented: " + method_str);
    }
}

void McpServer::ReplyResult(int id, const std::string& result) {
    std::string payload = "{\"jsonrpc\":\"2.0\",\"id\":";
    payload += std::to_string(id) + ",\"result\":";
    payload += result;
    payload += "}";
    Application::GetInstance().SendMcpMessage(payload);
}

void McpServer::ReplyError(int id, const std::string& message) {
    std::string payload = "{\"jsonrpc\":\"2.0\",\"id\":";
    payload += std::to_string(id);
    payload += ",\"error\":{\"message\":\"";
    payload += message;
    payload += "\"}}";
    Application::GetInstance().SendMcpMessage(payload);
}

void McpServer::GetToolsList(int id, const std::string& cursor, bool list_user_only_tools) {
    const int max_payload_size = 20000;
    std::string json = "{\"tools\":[";

    bool found_cursor = cursor.empty();
    auto it = tools_.begin();
    std::string next_cursor = "";
    int sent_count = 0;

    while (it != tools_.end()) {
        // 如果我们还没有找到起始位置，继续搜索
        if (!found_cursor) {
            if ((*it)->name() == cursor) {
                found_cursor = true;
            } else {
                ++it;
                continue;
            }
        }

        if (!list_user_only_tools && (*it)->user_only()) {
            ++it;
            continue;
        }

        // 添加tool前检查大小
        std::string tool_json = (*it)->to_json() + ",";
        if (json.length() + tool_json.length() + 30 > max_payload_size) {
            // 如果添加这个tool会超出大小限制，设置next_cursor并退出循环
            next_cursor = (*it)->name();
            break;
        }

        json += tool_json;
        ++it;
        ++sent_count;
    }

    if (json.back() == ',') {
        json.pop_back();
    }

    if (json.back() == '[' && !tools_.empty()) {
        // 如果没有添加任何tool，返回错误
        ESP_LOGE(TAG, "tools/list: Failed to add tool %s because of payload size limit",
                 next_cursor.c_str());
        ReplyError(id, "Failed to add tool " + next_cursor + " because of payload size limit");
        return;
    }

    if (next_cursor.empty()) {
        json += "]}";
        ESP_LOGI(TAG, "tools/list: sent %d tools (user_only=%d), complete", sent_count,
                 list_user_only_tools ? 1 : 0);
    } else {
        json += "],\"nextCursor\":\"" + next_cursor + "\"}";
        ESP_LOGI(TAG, "tools/list: sent %d tools (user_only=%d), next_cursor=%s", sent_count,
                 list_user_only_tools ? 1 : 0, next_cursor.c_str());
    }

    ReplyResult(id, json);
}

void McpServer::DoToolCall(int id, const std::string& tool_name, const cJSON* tool_arguments) {
    auto tool_iter = std::find_if(tools_.begin(), tools_.end(), [&tool_name](const McpTool* tool) {
        return tool->name() == tool_name;
    });

    if (tool_iter == tools_.end()) {
        ESP_LOGE(TAG, "tools/call: Unknown tool: %s", tool_name.c_str());
        ReplyError(id, "Unknown tool: " + tool_name);
        return;
    }

    PropertyList arguments = (*tool_iter)->properties();
    try {
        for (auto& argument : arguments) {
            bool found = false;
            if (cJSON_IsObject(tool_arguments)) {
                auto value = cJSON_GetObjectItem(tool_arguments, argument.name().c_str());
                if (argument.type() == kPropertyTypeBoolean && cJSON_IsBool(value)) {
                    argument.set_value<bool>(value->valueint == 1);
                    found = true;
                } else if (argument.type() == kPropertyTypeInteger && cJSON_IsNumber(value)) {
                    argument.set_value<int>(value->valueint);
                    found = true;
                } else if (argument.type() == kPropertyTypeString && cJSON_IsString(value)) {
                    argument.set_value<std::string>(value->valuestring);
                    found = true;
                }
            }

            if (!argument.has_default_value() && !found) {
                ESP_LOGE(TAG, "tools/call: Missing valid argument: %s", argument.name().c_str());
                ReplyError(id, "Missing valid argument: " + argument.name());
                return;
            }
        }
    } catch (const std::exception& e) {
        ESP_LOGE(TAG, "tools/call: %s", e.what());
        ReplyError(id, e.what());
        return;
    }

    // Use main thread to call the tool
    auto& app = Application::GetInstance();
    app.Schedule([this, id, tool_iter, arguments = std::move(arguments)]() {
        try {
            ReplyResult(id, (*tool_iter)->Call(arguments));
        } catch (const std::exception& e) {
            ESP_LOGE(TAG, "tools/call: %s", e.what());
            ReplyError(id, e.what());
        }
    });
}

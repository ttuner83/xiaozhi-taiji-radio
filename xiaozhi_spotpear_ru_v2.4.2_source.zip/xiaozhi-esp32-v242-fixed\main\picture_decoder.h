#pragma once

#include <stddef.h>
#include <stdint.h>

#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

// Decode a JPEG (including progressive) to an RGB565 buffer allocated in PSRAM.
// Returns ESP_OK and sets *out (SPIRAM, freed with heap_caps_free), *out_len, *width,
// *height, *stride (stride = width * 2).
esp_err_t DecodeProgressiveJpeg(const uint8_t* src, size_t src_len, uint8_t** out, size_t* out_len,
                                size_t* width, size_t* height, size_t* stride);

// Decode a PNG to an RGB565 buffer allocated in PSRAM. Non-interlaced 8-bit PNGs (colour
// types 0/2/3/4/6) are decoded with a streaming scanline inflater; alpha is dropped
// (flattened against black). Other PNGs fall back to stb_image.
esp_err_t DecodePngToRgb565(const uint8_t* src, size_t src_len, uint8_t** out, size_t* out_len,
                            size_t* width, size_t* height, size_t* stride);

#ifdef __cplusplus
}
#endif
#include "picture_decoder.h"

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>

#include "esp_heap_caps.h"
#include "esp_log.h"
#include "uzlib.h"

// stb_image custom allocators using PSRAM for large decoded images.
static void* PictureRealloc(void* p, size_t sz) {
    if (p == NULL) {
        return heap_caps_malloc(sz, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    }
    return heap_caps_realloc(p, sz, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
}

#define STBI_NO_STDIO
#define STBI_MALLOC(sz) heap_caps_malloc((sz), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT)
#define STBI_REALLOC(p, sz) PictureRealloc((p), (sz))
#define STBI_FREE(p) heap_caps_free(p)
#define STB_IMAGE_IMPLEMENTATION
#if defined(__GNUC__)
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wall"
#pragma GCC diagnostic ignored "-Wextra"
#endif
#include "stb_image.h"
#if defined(__GNUC__)
#pragma GCC diagnostic pop
#endif

#define TAG "picture_decoder"

// Convert an 8-bit-per-channel RGB buffer (w*h*3 bytes) to RGB565 little-endian IN-PLACE
// and shrink the allocation to w*h*2. For pixel i the two output bytes (2i, 2i+1) are always
// at or below the three source bytes (3i..3i+2), so a read-before-write per pixel is safe.
static esp_err_t ConvertRgbToRgb565InPlace(uint8_t* rgb, size_t w, size_t h, uint8_t** out,
                                           size_t* out_len, size_t* width, size_t* height,
                                           size_t* stride) {
    const size_t total = w * h;
    for (size_t i = 0; i < total; ++i) {
        const uint8_t* p = rgb + i * 3;
        uint8_t* d = rgb + i * 2;
        uint16_t px = (uint16_t)(((p[0] >> 3) << 11) | ((p[1] >> 2) << 5) | (p[2] >> 3));
        d[0] = (uint8_t)(px & 0xFF);
        d[1] = (uint8_t)(px >> 8);
    }

    size_t buf_len = w * h * 2;
    uint8_t* out_buf = heap_caps_realloc(rgb, buf_len, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (out_buf == NULL) {
        ESP_LOGE(TAG, "decoder: shrink alloc %u bytes failed (free SPIRAM=%u)", (unsigned)buf_len,
                 (unsigned)heap_caps_get_free_size(MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
        heap_caps_free(rgb);
        return ESP_ERR_NO_MEM;
    }
    ESP_LOGI(TAG, "decoded %ux%u -> %u bytes RGB565 (free SPIRAM=%u)", (unsigned)w, (unsigned)h,
             (unsigned)buf_len,
             (unsigned)heap_caps_get_free_size(MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));

    *out = out_buf;
    *out_len = buf_len;
    *width = w;
    *height = h;
    *stride = w * 2;
    return ESP_OK;
}

// Core decoder: loads any format stb supports (JPEG, PNG, BMP, GIF, PSD, TGA, HDR, PIC) as
// 8-bit RGB in PSRAM, then converts to RGB565 in place. Peak footprint is w*h*3 plus stb's
// internal buffers.
static esp_err_t DecodeToRgb565(const uint8_t* src, size_t src_len, uint8_t** out, size_t* out_len,
                                size_t* width, size_t* height, size_t* stride) {
    if (src == NULL || src_len == 0 || out == NULL || out_len == NULL || width == NULL ||
        height == NULL || stride == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    int w = 0, h = 0, comp = 0;
    uint8_t* rgb = stbi_load_from_memory(src, (int)src_len, &w, &h, &comp, 3);
    if (rgb == NULL) {
        const char* why = stbi_failure_reason();
        ESP_LOGW(TAG, "stbi_load_from_memory failed: %s (free SPIRAM=%u, free DRAM=%u)",
                 why != NULL ? why : "unknown",
                 (unsigned)heap_caps_get_free_size(MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT),
                 (unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL));
        return ESP_ERR_NOT_SUPPORTED;
    }
    if (w <= 0 || h <= 0 || w > 32768 || h > 32768) {
        ESP_LOGW(TAG, "decoder: bad dimensions %dx%d", w, h);
        stbi_image_free(rgb);
        return ESP_ERR_INVALID_SIZE;
    }

    return ConvertRgbToRgb565InPlace(rgb, (size_t)w, (size_t)h, out, out_len, width, height,
                                     stride);
}

// ---------------------------------------------------------------------------
// DC-only progressive JPEG thumbnail decoder. A progressive JPEG starts with
// scans that carry only the DC coefficient of each 8x8 block (SOS Ss=0); AC
// The refinements follow in later scans. We read just those DC values and emit
// a (w/8) x (h/8) thumbnail, far cheaper than a full decode through stb_image
// (which needs w*h*3 raw bytes and can OOM on 2 MP progressive photos).
// Baseline JPEGs (SOF0) are never routed here.
// ---------------------------------------------------------------------------

#define JPEG_DC_THUMB_THRESHOLD (1000000u)  // progressive pictures above ~1 MP get a DC preview

typedef struct {
    uint8_t counts[16];
    uint8_t syms[256];
    uint8_t nsyms;
    int32_t mincode[17];
    int32_t maxcode[17];
    int16_t valptr[17];
} JpegDcHuff;

typedef struct {
    uint32_t ww;
    uint32_t hh;
    uint8_t sof;
    uint8_t nf;
    uint8_t ids[4];
    uint8_t hf[4];
    uint8_t vf[4];
    uint8_t tq[4];
    bool have_dqt[4];
    uint8_t nscan;
    uint8_t s_ids[4];
    uint8_t s_t[4];
    uint8_t ss;
    uint8_t al;
    uint32_t epos;
    uint32_t dri;
    bool have_dri;
    int32_t hmax;
    int32_t vmax;
    int32_t mcu_w;
    int32_t mcu_h;
    JpegDcHuff huff[8];  // index (tc << 2) | th; only DC tables are used here
} JpegThumbCtx;

// Quick SOF scan: reports the SOF marker (0xC0 baseline / 0xC2 progressive) and
// the encoded dimensions without touching the entropy data.
static esp_err_t jpeg_quick_info(const uint8_t* src, size_t src_len, uint8_t* sof, uint32_t* w,
                                 uint32_t* h) {
    if (src_len < 8 || src[0] != 0xFF || src[1] != 0xD8) {
        return ESP_ERR_NOT_SUPPORTED;
    }
    size_t pos = 2;
    while (pos + 4 <= src_len) {
        if (src[pos] != 0xFF) {
            pos++;
            continue;
        }
        const uint8_t m = src[pos + 1];
        if (m == 0x00 || m == 0xD8 || m == 0x01 || (m >= 0xD0 && m <= 0xD7)) {
            pos += 2;
            continue;
        }
        if (m == 0xD9) {
            return ESP_ERR_NOT_FOUND;
        }
        const uint16_t ln = (uint16_t)((src[pos + 2] << 8) | src[pos + 3]);
        if (ln < 2 || pos + 2 + (size_t)ln > src_len) {
            return ESP_ERR_INVALID_SIZE;
        }
        if ((m >= 0xC0 && m <= 0xCF) && m != 0xC4 && m != 0xC8 && m != 0xCC && ln >= 8) {
            *sof = m;
            *h = ((uint32_t)src[pos + 5] << 8) | src[pos + 6];
            *w = ((uint32_t)src[pos + 7] << 8) | src[pos + 8];
            return ESP_OK;
        }
        pos += 2 + (size_t)ln;
    }
    return ESP_ERR_NOT_FOUND;
}

// MSB-first bit reader with JPEG byte stuffing. getbit() returns 0/1, or -1 when
// a non-stuffed marker (0xFF xx) is hit; on a marker the reader is left pointing
// at the leading 0xFF so the restart-marker code can see the full marker.
typedef struct {
    const uint8_t* data;
    size_t len;
    size_t pos;
    uint8_t bits;
    uint8_t bitcnt;
} JpegBitSrc;

static int jpegbits_getbit(JpegBitSrc* s) {
    if (s->bitcnt == 0) {
        if (s->pos >= s->len) {
            return -1;
        }
        uint8_t b = s->data[s->pos++];
        if (b == 0xFF) {
            if (s->pos >= s->len) {
                return -1;
            }
            const uint8_t nb = s->data[s->pos];
            if (nb == 0x00) {
                s->pos++;  // stuffed 0xFF00: single data byte 0xFF, filler dropped
            } else {
                s->pos--;
                return -1;
            }
        }
        s->bits = b;
        s->bitcnt = 8;
    }
    s->bitcnt--;
    return (s->bits >> s->bitcnt) & 1;
}

static int jpegbits_getbits(JpegBitSrc* s, int n) {
    int v = 0;
    for (int i = 0; i < n; i++) {
        int bit = jpegbits_getbit(s);
        if (bit < 0) {
            return -1;
        }
        v = (v << 1) | bit;
    }
    return v;
}

static int jpegbits_symbol(JpegBitSrc* s, const JpegDcHuff* h) {
    int32_t code = 0;
    for (int32_t len = 1; len <= 16; len++) {
        int bit = jpegbits_getbit(s);
        if (bit < 0) {
            return -1;
        }
        code = (code << 1) | bit;
        if (code <= h->maxcode[len]) {
            return h->syms[h->valptr[len] + (code - h->mincode[len])];
        }
    }
    return -2;  // no valid symbol
}

static void jpegbits_build(JpegDcHuff* h) {
    int32_t code = 0;
    for (int32_t len = 1; len <= 16; len++) {
        h->mincode[len] = code;
        code += h->counts[len - 1];
        code <<= 1;
    }
    int32_t j = 0;
    for (int32_t len = 1; len <= 16; len++) {
        h->valptr[len] = (int16_t)j;
        j += h->counts[len - 1];
        h->maxcode[len] = h->counts[len - 1] ? h->mincode[len] + h->counts[len - 1] - 1 : -1;
    }
}
// Parse DQT/DHT/DRI/SOF/SOS and fill the context. Returns ESP_OK only for a
// progressive (SOF2) file whose first scan is DC-only (Ss == 0).
static esp_err_t djpegs_parse(JpegThumbCtx* c, const uint8_t* src, size_t src_len,
                              uint8_t qtab[4][64]) {
    size_t pos = 2;
    bool have_sos = false;
    while (pos + 4 <= src_len) {
        if (src[pos] != 0xFF) {
            pos++;
            continue;
        }
        const uint8_t m = src[pos + 1];
        if (m == 0x00 || m == 0xD8 || m == 0x01 || (m >= 0xD0 && m <= 0xD7)) {
            pos += 2;
            continue;
        }
        if (m == 0xD9) {
            break;
        }
        const uint16_t ln = (uint16_t)((src[pos + 2] << 8) | src[pos + 3]);
        if (ln < 2 || pos + 2 + (size_t)ln > src_len) {
            break;
        }
        const uint8_t* p = src + pos + 4;
        const uint16_t plen = ln - 2;
        if (m == 0xDB) {  // DQT
            uint16_t i = 0;
            while (i + 65 <= plen) {
                const uint8_t info = p[i++];
                if ((info >> 4) != 0) {
                    return ESP_ERR_NOT_SUPPORTED;  // 16-bit quant tables
                }
                const uint8_t tq = info & 0x0F;
                memcpy(qtab[tq], p + i, 64);
                c->have_dqt[tq] = true;
                i += 64;
            }
        } else if (m == 0xC4) {  // DHT
            uint16_t i = 0;
            while (i + 17 <= plen) {
                const uint8_t info = p[i++];
                const uint8_t tc = info >> 4;
                const uint8_t th = info & 0x0F;
                if (tc > 1 || th > 3) {
                    return ESP_ERR_NOT_SUPPORTED;
                }
                JpegDcHuff* h = &c->huff[(tc << 2) | th];
                uint8_t total = 0;
                for (uint8_t l = 0; l < 16; l++) {
                    const uint8_t cnt = p[i];
                    h->counts[l] = cnt;
                    total += cnt;
                    i++;
                }
                if (i + total > plen) {
                    return ESP_ERR_INVALID_SIZE;
                }
                memcpy(h->syms, p + i, total);
                h->nsyms = total;
                i += total;
                jpegbits_build(h);
            }
        } else if (m == 0xDD) {  // DRI
            if (plen >= 2) {
                c->dri = ((uint32_t)p[0] << 8) | p[1];
                c->have_dri = true;
            }
        } else if ((m >= 0xC0 && m <= 0xCF) && m != 0xC4 && m != 0xC8 && m != 0xCC) {
            if (plen < 6 || p[0] != 8) {
                return ESP_ERR_NOT_SUPPORTED;
            }
            c->sof = m;
            c->hh = ((uint32_t)p[1] << 8) | p[2];
            c->ww = ((uint32_t)p[3] << 8) | p[4];
            c->nf = p[5];
            if (c->hh == 0 || c->ww == 0 || c->nf == 0 || c->nf > 4 ||
                plen < 6 + 3 * c->nf) {
                return ESP_ERR_INVALID_SIZE;
            }
            c->hmax = 0;
            c->vmax = 0;
            for (uint8_t k = 0; k < c->nf; k++) {
                c->ids[k] = p[6 + 3 * k];
                c->hf[k] = p[7 + 3 * k] >> 4;
                c->vf[k] = p[7 + 3 * k] & 0x0F;
                c->tq[k] = p[8 + 3 * k];
                if (c->hf[k] > c->hmax) {
                    c->hmax = c->hf[k];
                }
                if (c->vf[k] > c->vmax) {
                    c->vmax = c->vf[k];
                }
            }
            if (c->hmax == 0 || c->vmax == 0) {
                return ESP_ERR_INVALID_SIZE;
            }
        } else if (m == 0xDA) {  // SOS: first scan only
            if (c->nf == 0 || plen < 1 + 2 + 3) {
                return ESP_ERR_INVALID_SIZE;
            }
            c->nscan = p[0];
            if (c->nscan == 0 || c->nscan > 4 || plen < 1 + 2 * c->nscan + 3) {
                return ESP_ERR_INVALID_SIZE;
            }
            for (uint8_t k = 0; k < c->nscan; k++) {
                c->s_ids[k] = p[1 + 2 * k];
                c->s_t[k] = p[2 + 2 * k] >> 4;
                if (c->s_t[k] > 3) {
                    return ESP_ERR_NOT_SUPPORTED;
                }
            }
            const uint8_t* t = p + 1 + 2 * c->nscan;
            c->ss = t[0];
            c->al = t[2] & 0x0F;
            pos += 2 + (size_t)ln;
            c->epos = (uint32_t)pos;
            have_sos = true;
            break;
        }
        pos += 2 + (size_t)ln;
    }
    if (!have_sos) {
        return ESP_ERR_INVALID_SIZE;
    }
    if (c->sof != 0xC2 || c->ss != 0) {
        return ESP_ERR_NOT_SUPPORTED;  // DC-only path is for progressive (SOF2) scans
    }
    for (uint8_t ci = 0; ci < c->nscan; ci++) {
        uint8_t k = 255;
        for (uint8_t t = 0; t < c->nf; t++) {
            if (c->ids[t] == c->s_ids[ci]) {
                k = t;
                break;
            }
        }
        if (k == 255 || !c->have_dqt[c->tq[k]] || c->huff[c->s_t[ci]].nsyms == 0) {
            return ESP_ERR_NOT_SUPPORTED;
        }
    }
    c->mcu_w = ((int32_t)c->ww + 8 * c->hmax - 1) / (8 * c->hmax);
    c->mcu_h = ((int32_t)c->hh + 8 * c->vmax - 1) / (8 * c->vmax);
    if (c->mcu_w <= 0 || c->mcu_h <= 0) {
        return ESP_ERR_INVALID_SIZE;
    }
    return ESP_OK;
}
// Decode the DC scan into per-component planes (PSRAM) and compose an RGB565
// thumbnail of mcu area (w/8 x h/8). YCbCr -> RGB565 with clamp.
static esp_err_t djpegs_run(const JpegThumbCtx* c, const uint8_t* src, size_t src_len,
                            const uint8_t qtab[4][64], uint8_t** out, size_t* out_len,
                            size_t* width, size_t* height, size_t* stride) {
    const int32_t n_mcu = c->mcu_w * c->mcu_h;
    size_t poff[4] = {0};
    size_t pdx[4] = {0};
    size_t plane_total = 0;
    for (uint8_t k = 0; k < c->nf; k++) {
        poff[k] = plane_total;
        pdx[k] = (size_t)c->mcu_w * c->hf[k];
        plane_total += pdx[k] * (size_t)c->mcu_h * c->vf[k];
    }
    int16_t* planes = (int16_t*)heap_caps_malloc(plane_total * sizeof(int16_t),
                                                 MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (planes == NULL) {
        ESP_LOGE(TAG, "jpeg dc: planes alloc %u bytes failed (free SPIRAM=%u)",
                 (unsigned)(plane_total * sizeof(int16_t)),
                 (unsigned)heap_caps_get_free_size(MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
        return ESP_ERR_NO_MEM;
    }

    JpegBitSrc bs;
    bs.data = src;
    bs.len = src_len;
    bs.pos = c->epos;
    bs.bits = 0;
    bs.bitcnt = 0;
    int32_t pred[4] = {0};
    esp_err_t err = ESP_OK;
    for (int32_t mcu_id = 0; mcu_id < n_mcu; mcu_id++) {
        if (c->have_dri && c->dri > 0 && mcu_id > 0 && (int32_t)(mcu_id % c->dri) == 0) {
            bs.bitcnt = 0;
            for (uint8_t t = 0; t < 4; t++) {
                pred[t] = 0;
            }
            while (bs.pos + 1 < bs.len && bs.data[bs.pos] == 0xFF && bs.data[bs.pos + 1] == 0xFF) {
                bs.pos++;
            }
            if (!(bs.pos + 1 < bs.len && bs.data[bs.pos] == 0xFF &&
                  bs.data[bs.pos + 1] >= 0xD0 && bs.data[bs.pos + 1] <= 0xD7)) {
                err = ESP_ERR_INVALID_RESPONSE;
                break;
            }
            bs.pos += 2;
        }
        const int32_t mc = mcu_id % c->mcu_w;
        const int32_t mr = mcu_id / c->mcu_w;
        for (uint8_t ci = 0; ci < c->nscan; ci++) {
            uint8_t k = 255;
            for (uint8_t t = 0; t < c->nf; t++) {
                if (c->ids[t] == c->s_ids[ci]) {
                    k = t;
                    break;
                }
            }
            if (k == 255) {
                err = ESP_ERR_INVALID_RESPONSE;
                break;
            }
            const JpegDcHuff* tpl = &c->huff[c->s_t[ci]];
            for (uint8_t bi = 0; bi < c->hf[k] * c->vf[k]; bi++) {
                int sym = jpegbits_symbol(&bs, tpl);
                if (sym < 0) {
                    err = ESP_ERR_INVALID_RESPONSE;
                    break;
                }
                const int sbits = sym & 0x0F;
                int v = 0;
                if (sbits != 0) {
                    int r = jpegbits_getbits(&bs, sbits);
                    if (r < 0) {
                        err = ESP_ERR_INVALID_RESPONSE;
                        break;
                    }
                    if (r & (1 << (sbits - 1))) {
                        v = r;
                    } else {
                        v = r - ((1 << sbits) - 1);
                    }
                }
                if (c->al != 0) {
                    v <<= c->al;
                }
                pred[k] += v;
                planes[poff[k] + (size_t)(mr * c->vf[k] + bi / c->hf[k]) * pdx[k] +
                       (size_t)(mc * c->hf[k] + bi % c->hf[k])] = (int16_t)pred[k];
            }
            if (err != ESP_OK) {
                break;
            }
        }
        if (err != ESP_OK) {
            break;
        }
    }
    if (err != ESP_OK) {
        heap_caps_free(planes);
        return err;
    }

    const int32_t Wo = c->mcu_w * c->hmax;
    const int32_t Ho = c->mcu_h * c->vmax;
    uint8_t* rgb565 = (uint8_t*)heap_caps_malloc((size_t)Wo * Ho * 2,
                                                 MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (rgb565 == NULL) {
        heap_caps_free(planes);
        return ESP_ERR_NO_MEM;
    }
    uint8_t yk = 0;
    for (uint8_t t = 0; t < c->nf; t++) {
        if (c->hf[t] == c->hmax && c->vf[t] == c->vmax) {
            yk = t;
            break;
        }
    }
    uint8_t ck1 = 255, ck2 = 255;
    for (uint8_t t = 0; t < c->nf; t++) {
        if (t == yk) {
            continue;
        }
        if (ck1 == 255) {
            ck1 = t;
        } else if (ck2 == 255) {
            ck2 = t;
        }
    }
    const int ymul = qtab[c->tq[yk]][0];
    const int c1mul = ck1 != 255 ? qtab[c->tq[ck1]][0] : 0;
    const int c2mul = ck2 != 255 ? qtab[c->tq[ck2]][0] : 0;
    int16_t* yp = planes + poff[yk];
    const size_t ydx = pdx[yk];
    int16_t* cp1 = ck1 != 255 ? planes + poff[ck1] : NULL;
    const size_t c1dx = ck1 != 255 ? pdx[ck1] : 0;
    int16_t* cp2 = ck2 != 255 ? planes + poff[ck2] : NULL;
    const size_t c2dx = ck2 != 255 ? pdx[ck2] : 0;

    for (int32_t j = 0; j < Ho; j++) {
        for (int32_t i = 0; i < Wo; i++) {
            int y = (yp[j * ydx + i] * ymul) / 8 + 128;
            int cb = 128;
            int cr = 128;
            if (cp1 != NULL) {
                const int jc = j * c->vf[ck1] / c->vmax;
                const int ic = i * c->hf[ck1] / c->hmax;
                cb = (cp1[jc * c1dx + ic] * c1mul) / 8 + 128;
            }
            if (cp2 != NULL) {
                const int jc = j * c->vf[ck2] / c->vmax;
                const int ic = i * c->hf[ck2] / c->hmax;
                cr = (cp2[jc * c2dx + ic] * c2mul) / 8 + 128;
            }
            if (y < 0) {
                y = 0;
            } else if (y > 255) {
                y = 255;
            }
            if (cb < 0) {
                cb = 0;
            } else if (cb > 255) {
                cb = 255;
            }
            if (cr < 0) {
                cr = 0;
            } else if (cr > 255) {
                cr = 255;
            }
            const int r = y + (381 * (cr - 128) + 128) / 256;
            const int g = y - (93 * (cb - 128) + 128) / 256 - (194 * (cr - 128) + 128) / 256;
            const int b = y + (481 * (cb - 128) + 128) / 256;
            const uint8_t rr = r < 0 ? 0 : (r > 255 ? 255 : (uint8_t)r);
            const uint8_t gg = g < 0 ? 0 : (g > 255 ? 255 : (uint8_t)g);
            const uint8_t bb = b < 0 ? 0 : (b > 255 ? 255 : (uint8_t)b);
            const uint16_t px = (uint16_t)(((rr >> 3) << 11) | ((gg >> 2) << 5) | (bb >> 3));
            rgb565[(j * Wo + i) * 2] = (uint8_t)(px & 0xFF);
            rgb565[(j * Wo + i) * 2 + 1] = (uint8_t)(px >> 8);
        }
    }
    heap_caps_free(planes);

    ESP_LOGI(TAG, "jpeg: progressive DC thumbnail %ux%u -> %u bytes RGB565 (free SPIRAM=%u)",
             (unsigned)Wo, (unsigned)Ho, (unsigned)((size_t)Wo * Ho * 2),
             (unsigned)heap_caps_get_free_size(MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
    *out = rgb565;
    *out_len = (size_t)Wo * Ho * 2;
    *width = (size_t)Wo;
    *height = (size_t)Ho;
    *stride = (size_t)Wo * 2;
    return ESP_OK;
}

static esp_err_t DecodeJpegThumbnail(const uint8_t* src, size_t src_len, uint8_t** out,
                                     size_t* out_len, size_t* width, size_t* height,
                                     size_t* stride) {
    if (src_len < 8 || src[0] != 0xFF || src[1] != 0xD8) {
        return ESP_ERR_NOT_SUPPORTED;
    }
    JpegThumbCtx* c = (JpegThumbCtx*)heap_caps_malloc(sizeof(JpegThumbCtx),
                                                      MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    if (c == NULL) {
        return ESP_ERR_NO_MEM;
    }
    memset(c, 0, sizeof(JpegThumbCtx));
    uint8_t qtab[4][64] = {{0}};
    esp_err_t err = djpegs_parse(c, src, src_len, qtab);
    if (err == ESP_OK) {
        err = djpegs_run(c, src, src_len, qtab, out, out_len, width, height, stride);
    }
    heap_caps_free(c);
    if (err != ESP_OK) {
        *out = NULL;
        *out_len = 0;
        *width = 0;
        *height = 0;
        *stride = 0;
    }
    return err;
}

esp_err_t DecodeProgressiveJpeg(const uint8_t* src, size_t src_len, uint8_t** out, size_t* out_len,
                                size_t* width, size_t* height, size_t* stride) {
    uint32_t w = 0;
    uint32_t h = 0;
    uint8_t sof = 0;
    if (jpeg_quick_info(src, src_len, &sof, &w, &h) == ESP_OK && sof == 0xC2 &&
        (uint64_t)w * h > JPEG_DC_THUMB_THRESHOLD) {
        esp_err_t r = DecodeJpegThumbnail(src, src_len, out, out_len, width, height, stride);
        if (r == ESP_OK) {
            return ESP_OK;
        }
        ESP_LOGW(TAG, "jpeg: DC thumbnail unavailable for %ux%u (%s), falling back to full decode",
                 (unsigned)w, (unsigned)h, esp_err_to_name(r));
    }
    return DecodeToRgb565(src, src_len, out, out_len, width, height, stride);
}

// ---------------------------------------------------------------------------
// Streaming PNG decoder. stb_image and lodepng need two full-size buffers
// (~w*h*4 inflated + w*h*3 output) which does not fit the 8 MB PSRAM for large
// pictures. Here we inflate the zlib stream one scanline at a time with uzlib
// and run the PNG filters incrementally, so the only large allocation is the
// final RGB image (w*h*3). Supports 8-bit, non-interlaced PNG with colour types
// 0 (grey), 2 (RGB), 3 (palette), 4 (grey+alpha) and 6 (RGBA). Alpha is dropped
// (flattened against black).
// The whole decoder state (uzlib decompressor, IDAT segment table, palette) is
// kept on the heap, NOT the stack, because the MCP tool task stack is small
// (the segment table alone can be several KB).
// ---------------------------------------------------------------------------

#define UZLIB_DICT_BYTES (32 * 1024)
#define UZLIB_MAX_IDAT 512

typedef struct {
    const uint8_t* start;
    const uint8_t* end;
} UzlibPngSeg;

typedef struct {
    uzlib_uncomp_t* d;
    const UzlibPngSeg* segs;
    size_t nsegs;
    size_t idx;
} UzlibPngCache;

// Decoder context, allocated from internal heap. "flex" is the flexible segment
// array + palette appended after the fixed members (see DecodePngStreaming).
typedef struct {
    uzlib_uncomp_t d;
    UzlibPngCache cache;
    size_t pal_entries;
    uint32_t w;
    uint32_t h;
    uint8_t bitdepth;
    uint8_t colortype;
    uint8_t interlace;
} PngCtx;

static uint32_t png_be32(const uint8_t* p) {
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) | ((uint32_t)p[2] << 8) | (uint32_t)p[3];
}

// Called by uzlib when d->source reaches d->source_limit: advance to the next IDAT
// segment's data and hand uzlib a fresh source window. Returns -1 when exhausted.
// Sets source to the byte AFTER the returned one, since the caller will next read
// via the source pointer.
static int uzlib_png_source_cb(void* param) {
    UzlibPngCache* c = (UzlibPngCache*)param;
    while (true) {
        c->idx++;
        if (c->idx >= c->nsegs) {
            c->d->eof = true;
            return -1;
        }
        const uint8_t* s = c->segs[c->idx].start;
        const uint8_t* e = c->segs[c->idx].end;
        if (s >= e) {
            continue;
        }
        c->d->source = s + 1;
        c->d->source_limit = e;
        return *s;
    }
}

static inline uint8_t png_paeth(uint8_t a, uint8_t b, uint8_t c) {
    int pa = abs((int)b - (int)c);
    int pb = abs((int)a - (int)c);
    int pc = abs((int)a + (int)b - 2 * (int)c);
    if (pa <= pb && pa <= pc) return a;
    if (pb <= pc) return b;
    return c;
}

// Apply a PNG scanline filter (None/Sub/Up/Average/Paeth) in place. len is the number of
// data bytes (w*bpp), bpp is the bytes-per-pixel (== channels for 8-bit), prev is the raw
// previous scanline data (zeros for the first row).
static void png_unfilter(uint8_t* cur, const uint8_t* prev, size_t len, size_t bpp,
                         uint8_t ftype) {
    size_t i;
    switch (ftype) {
    case 0:
        return;
    case 1:
        for (i = bpp; i < len; ++i) cur[i] += cur[i - bpp];
        break;
    case 2:
        for (i = 0; i < len; ++i) cur[i] += prev[i];
        break;
    case 3:
        for (i = 0; i < len; ++i) {
            uint8_t a = (i >= bpp) ? cur[i - bpp] : 0;
            cur[i] += (uint8_t)(((unsigned)a + (unsigned)prev[i]) >> 1);
        }
        break;
    case 4:
        for (i = 0; i < len; ++i) {
            uint8_t a = (i >= bpp) ? cur[i - bpp] : 0;
            uint8_t b = prev[i];
            uint8_t c = (i >= bpp) ? prev[i - bpp] : 0;
            cur[i] += png_paeth(a, b, c);
        }
        break;
    }
}

// Expand one unfiltered scanline (w pixels, channels per colortype) to RGB888.
static void png_expand_to_rgb(uint8_t* dst, const uint8_t* row, size_t w, uint8_t colortype,
                              const uint8_t* pal) {
    size_t i;
    switch (colortype) {
    case 0:
        for (i = 0; i < w; ++i) {
            uint8_t g = row[i];
            dst[0] = g;
            dst[1] = g;
            dst[2] = g;
            dst += 3;
        }
        break;
    case 2:
        memcpy(dst, row, w * 3);
        break;
    case 3:
        for (i = 0; i < w; ++i) {
            const uint8_t* e = pal + (size_t)row[i] * 3;
            dst[0] = e[0];
            dst[1] = e[1];
            dst[2] = e[2];
            dst += 3;
        }
        break;
    case 4:
        for (i = 0; i < w; ++i) {
            uint8_t g = row[i * 2];
            dst[0] = g;
            dst[1] = g;
            dst[2] = g;
            dst += 3;
        }
        break;
    case 6:
        for (i = 0; i < w; ++i) {
            dst[0] = row[i * 4];
            dst[1] = row[i * 4 + 1];
            dst[2] = row[i * 4 + 2];
            dst += 3;
        }
        break;
    }
}

static esp_err_t DecodePngStreaming(const uint8_t* src, size_t src_len, uint8_t** out,
                                    size_t* out_len, size_t* width, size_t* height,
                                    size_t* stride) {
    if (src_len < 8 + 12 || memcmp(src, "\x89PNG\r\n\x1a\n", 8) != 0) {
        return ESP_ERR_NOT_SUPPORTED;
    }

    // Pass 1: validate chunk framing, capture IHDR/PLTE, count IDAT segments.
    uint32_t w = 0, h = 0;
    uint8_t bitdepth = 0, colortype = 0, interlace = 0;
    bool have_ihdr = false;
    size_t plte_len = 0;
    size_t nsegs = 0;
    size_t off = 8;
    while (off + 12 <= src_len) {
        uint32_t len = png_be32(src + off);
        const uint8_t* type = src + off + 4;
        if (off + 12 + (size_t)len > src_len) {
            return ESP_ERR_NOT_SUPPORTED;  // truncated
        }
        const uint8_t* data = src + off + 8;
        if (memcmp(type, "IEND", 4) == 0) {
            break;
        } else if (memcmp(type, "IHDR", 4) == 0) {
            if (len < 13 || have_ihdr) {
                return ESP_ERR_NOT_SUPPORTED;
            }
            w = png_be32(data);
            h = png_be32(data + 4);
            bitdepth = data[8];
            colortype = data[9];
            interlace = data[12];
            have_ihdr = true;
        } else if (memcmp(type, "PLTE", 4) == 0) {
            plte_len = len;
        } else if (memcmp(type, "IDAT", 4) == 0) {
            if (len > 0) {
                nsegs++;
            }
        }
        off += 12 + (size_t)len;
    }

    if (!have_ihdr || nsegs == 0 || nsegs > UZLIB_MAX_IDAT || w == 0 || h == 0 || w > 16384 ||
        h > 16384 || bitdepth != 8 || interlace != 0) {
        return ESP_ERR_NOT_SUPPORTED;
    }

    static const uint8_t kChannels[7] = {1, 0, 3, 1, 2, 0, 4};
    if (colortype > 6 || kChannels[colortype] == 0) {
        return ESP_ERR_NOT_SUPPORTED;
    }
    if (plte_len == 0 && colortype == 3) {
        return ESP_ERR_NOT_SUPPORTED;
    }
    if (plte_len > 256 * 3 || (colortype != 3 && plte_len != 0)) {
        return ESP_ERR_NOT_SUPPORTED;
    }
    const size_t channels = kChannels[colortype];

    if (src_len < 8 + 12 + 2 + 4) {
        return ESP_ERR_NOT_SUPPORTED;
    }
    // The concatenated IDAT data is a zlib stream: skip the 2-byte header at the start
    // and the 4-byte adler32 trailer at the end (uzlib checksum is disabled). Validate
    // the header here by peeking at the whole IDAT layout in pass 2 (we need the first
    // and last segment start/end which we do not know until segments are filled).

    // Allocate the full decoder context from INTERNAL heap: uzlib state +
    // source-cache struct + segment table (up to ~4 KB) + palette (<=768 B).
    // Nothing large here sits on the MCP task stack.
    const uint8_t* pal = NULL;
    size_t total_ctx = sizeof(PngCtx) + 8 + nsegs * sizeof(UzlibPngSeg);
    if (plte_len > 0) {
        total_ctx += plte_len;
    }
    uint8_t* ctx = (uint8_t*)heap_caps_malloc(total_ctx, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    if (ctx == NULL) {
        ESP_LOGE(TAG, "png: ctx alloc %u bytes failed", (unsigned)total_ctx);
        return ESP_ERR_NO_MEM;
    }
    PngCtx* pc = (PngCtx*)ctx;
    memset(pc, 0, sizeof(PngCtx));
    size_t offset = (sizeof(PngCtx) + 7) & ~(size_t)7;  // align up to 8
    UzlibPngSeg* segs = (UzlibPngSeg*)(ctx + offset);
    offset += nsegs * sizeof(UzlibPngSeg);
    if (plte_len > 0) {
        pal = ctx + offset;
    }
    pc->w = w;
    pc->h = h;
    pc->bitdepth = bitdepth;
    pc->colortype = colortype;
    pc->interlace = interlace;

    // Pass 2: fill segments (trim zlib header/adler) and copy the palette.
    size_t si = 0;
    off = 8;
    while (si < nsegs && off + 12 <= src_len) {
        uint32_t len = png_be32(src + off);
        const uint8_t* type = src + off + 4;
        const uint8_t* data = src + off + 8;
        if (memcmp(type, "IDAT", 4) == 0 && len > 0) {
            segs[si].start = data;
            segs[si].end = data + len;
            si++;
        } else if (memcmp(type, "PLTE", 4) == 0) {
            memcpy((uint8_t*)pal, data, plte_len);
        } else if (memcmp(type, "IEND", 4) == 0) {
            break;
        }
        off += 12 + (size_t)len;
    }
    if (segs[0].end - segs[0].start < 2 || segs[nsegs - 1].end - segs[nsegs - 1].start < 4) {
        heap_caps_free(ctx);
        return ESP_ERR_NOT_SUPPORTED;
    }
    uint16_t cmf = (uint16_t)((segs[0].start[0] << 8) | segs[0].start[1]);
    if ((segs[0].start[0] & 0x0F) != 8 || (cmf % 31) != 0) {
        ESP_LOGW(TAG, "png: unexpected zlib header 0x%04x", cmf);
        heap_caps_free(ctx);
        return ESP_ERR_NOT_SUPPORTED;
    }
    segs[0].start += 2;
    segs[nsegs - 1].end -= 4;

    // Final RGB image in PSRAM: the one large allocation during streaming decode.
    size_t total_rgb = (size_t)w * (size_t)h * 3;
    uint8_t* rgb = (uint8_t*)heap_caps_malloc(total_rgb, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (rgb == NULL) {
        heap_caps_free(ctx);
        ESP_LOGE(TAG, "png: alloc %u bytes failed (free SPIRAM=%u)", (unsigned)total_rgb,
                 (unsigned)heap_caps_get_free_size(MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
        return ESP_ERR_NO_MEM;
    }

    size_t rowlen = (size_t)w * channels + 1;
    // +8 guard: if a non-final deflate block ends exactly at a row boundary,
    // uzlib_uncompress may write 1 byte past dest_limit before checking the
    // while(dest<dest_limit) condition. Padding prevents heap corruption.
    // Row buffers live in PSRAM to avoid exhausting internal DRAM (which stays
    // tiny on PSRAM boards); they are only touched once per row during inflate.
    size_t rowbuf = rowlen + 8;
    uint8_t* prev =
        (uint8_t*)heap_caps_malloc(rowbuf, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    uint8_t* cur = (uint8_t*)heap_caps_malloc(rowbuf, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (prev == NULL || cur == NULL) {
        heap_caps_free(rgb);
        heap_caps_free(ctx);
        heap_caps_free(prev);
        heap_caps_free(cur);
        ESP_LOGE(TAG, "png: row buffer alloc %u bytes failed", (unsigned)rowbuf);
        return ESP_ERR_NO_MEM;
    }
    memset(prev, 0, rowbuf);

    // uzlib's LZ77 sliding window. PSRAM is fast enough on octal-PSRAM boards and
    // keeps internal DRAM from being exhausted by a single image decode.
    uint8_t* dict = (uint8_t*)heap_caps_malloc(UZLIB_DICT_BYTES,
                                               MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (dict == NULL) {
        heap_caps_free(rgb);
        heap_caps_free(ctx);
        heap_caps_free(prev);
        heap_caps_free(cur);
        ESP_LOGE(TAG, "png: dict alloc %u bytes failed", UZLIB_DICT_BYTES);
        return ESP_ERR_NO_MEM;
    }
    memset(dict, 0, UZLIB_DICT_BYTES);

    uzlib_uncomp_t* d = &pc->d;
    UzlibPngCache* cache = &pc->cache;
    cache->d = d;
    cache->segs = segs;
    cache->nsegs = nsegs;
    cache->idx = SIZE_MAX;  // first callback advances to seg 0
    d->source = (uint8_t*)(pc + 1);  // equal non-NULL pair: forces every read through
    d->source_limit = (uint8_t*)(pc + 1);  // the callback (which fills the windows)
    d->source_read_data = cache;
    d->source_read_cb = uzlib_png_source_cb;
    d->checksum_type = UZLIB_CHKSUM_NONE;
    d->dest = cur;
    uzlib_uncompress_init(d, dict, UZLIB_DICT_BYTES);

    const size_t data_len = (size_t)w * channels;
    bool complete = false;
    esp_err_t err = ESP_OK;
    for (uint32_t y = 0; y < h; ++y) {
        d->dest = cur;
        d->dest_limit = cur + rowlen;
        int res = uzlib_uncompress(d);
        size_t got = (size_t)(d->dest - cur);
        if (res == UZLIB_DONE && got >= rowlen) {
            complete = true;  // deflate stream ended exactly on the last row
        } else if (res == UZLIB_DONE || got < rowlen) {
            ESP_LOGW(TAG, "png: inflate ended early at row %u (res=%d, %u of %u bytes)",
                     (unsigned)y, res, (unsigned)got, (unsigned)rowlen);
            err = ESP_ERR_INVALID_RESPONSE;
            break;
        }
        png_unfilter(cur + 1, prev + 1, data_len, channels, cur[0]);
        png_expand_to_rgb(rgb + (size_t)y * (size_t)w * 3, cur + 1, w, colortype, pal);
        uint8_t* tmp = prev;
        prev = cur;
        cur = tmp;
    }

    // The last scanline may fill the row buffer exactly, so the final deflate block's
    // end-of-block symbol (256) is not consumed yet. Do one final call with a small
    // sink to confirm the deflate stream ends cleanly (UZLIB_DONE, no extra data).
    if (err == ESP_OK && !complete) {
        uint8_t sink[40];
        d->dest = sink;
        d->dest_limit = sink + sizeof(sink);
        int res = uzlib_uncompress(d);
        if (res == UZLIB_DONE) {
            complete = true;
        } else {
            ESP_LOGW(TAG, "png: deflate stream did not end cleanly (res=%d, %u extra bytes)",
                     res, (unsigned)(d->dest - sink));
            err = ESP_ERR_INVALID_RESPONSE;
        }
    }

    heap_caps_free(dict);
    heap_caps_free(ctx);
    heap_caps_free(prev);
    heap_caps_free(cur);

    if (err != ESP_OK || !complete) {
        if (err == ESP_OK) {
            ESP_LOGW(TAG, "png: deflate stream did not end cleanly after %u rows", (unsigned)h);
            err = ESP_ERR_INVALID_RESPONSE;
        }
        heap_caps_free(rgb);
        return err;
    }

    return ConvertRgbToRgb565InPlace(rgb, w, h, out, out_len, width, height, stride);
}

esp_err_t DecodePngToRgb565(const uint8_t* src, size_t src_len, uint8_t** out, size_t* out_len,
                            size_t* width, size_t* height, size_t* stride) {
    esp_err_t err = DecodePngStreaming(src, src_len, out, out_len, width, height, stride);
    if (err == ESP_OK) {
        return ESP_OK;
    }
    // Fall back to stb_image for PNGs the streaming path rejects
    // (16-bit, interlaced, sub-8-bit depth, etc.).
    ESP_LOGW(TAG, "png: streaming decode unavailable (%s), trying stb_image",
             esp_err_to_name(err));
    return DecodeToRgb565(src, src_len, out, out_len, width, height, stride);
}
# Сборка из исходников (кастомная прошивка для Spotpear ESP32-S3 1.28 Box)

Это полное дерево исходников прошивки с нашими изменениями относительно официального тега
`v2.4.2` (тот же diff лежит в `source-changes.patch`). Готово к сборке «как есть».

## Состав изменений (кратко)

- Интернет-радио: 15 российских станций по голосовой команде (MP3/AAC).
- Музыка и картинки с microSD-карты (папки `music` / `pictures`).
- Цветной аудио-спектроанализатор на экране во время радио/музыки.
- Смешные голосовые озвучки при разряде батареи (≤15% и ≤5%; файлы на SD, папка `announce`).
- **Фикс**: радио больше не замолкает через ~минуту. Причина — энергосберегающий таймер
  аудио-сервиса (`main/audio/audio_service.cc`, `AUDIO_POWER_TIMEOUT_MS`) отключал усилитель,
  т.к. радио пишет PCM в обход аудио-сервиса. Добавлен keep-alive:
  `AudioService::NotifyExternalOutputActivity()` вызывается в цикле радио/музыки/озвучек.
- Глаза Cozmo: компонент `components/esp32_eyes` (лицензия **AGPL-3.0** — при распространении
  бинарников исходники должны передаваться вместе с ними, это и есть цель этого архива).

## Требования

- Windows / Linux / macOS.
- ESP-IDF **5.5** (последняя ветка, в которой осталась эта плата).
  - Windows: установщик espressif → выбрать ESP-IDF 5.5; переменная `IDF_PATH`.
- Python 3.9+ (ставится вместе с ESP-IDF).

## Сборка

```sh
# Windows PowerShell:
. $env:IDF_PATH\export.ps1
idf.py set-target esp32s3
idf.py build

# Linux/macOS:
. $IDF_PATH/export.sh
idf.py set-target esp32s3
idf.py build
```

- Плата и язык уже заданы в `sdkconfig.defaults.esp32s3`
  (`CONFIG_BOARD_TYPE_SPOTPEAR_ESP32_S3_1_28_BOX=y`, `CONFIG_LANGUAGE_RU_RU=y`).
- Зависимости (`esp-sr`, `opus`, LVGL и т.д.) подтянутся автоматически через
  `idf_component_manager` — интернет нужен при первой сборке. Это и есть `managed_components/`,
  которая не включена в архив.

## Прошивка

```sh
idf.py -p COMxx flash
```

xперепрошить устройство так же как обычную сборку (те же офсеты: 0x0, 0x8000, 0xd000, 0x20000,
0x800000). Или собрать merged-образ и залить одним файлом на 0x0:

```sh
python -m esptool merge_bin -o flash.bin --flash_mode dio --flash_freq 80m --flash_size 16MB \
  0x0 build/bootloader/bootloader.bin 0x8000 build/partition_table/partition-table.bin \
  0xd000 build/ota_data_initial.bin 0x20000 build/xiaozhi.bin 0x800000 build/generated_assets.bin
python -m esptool --chip esp32s3 -p COMxx write_flash --flash_mode dio --flash_freq 80m --flash_size 16MB 0x0 flash.bin
```

## После прошивки

1. Устройство перезагрузится и создаст точку доступа Wi-Fi — подключитесь, задайте свою сеть.
2. Активируйте на аккаунте xiaozhi.me (код устройства свой — в прошивку ничего чужого не зашито).
3. «Hi, ESP» — и пробуйте: «включи радио Маяк».
4. Для озвучек батареи положите на SD-карту папку `announce` с `battery_15.mp3` и `battery_5.mp3`
   (готовые файлы в папке `announce` рядом с прошивкой).

This firmware is based on https://github.com/78/xiaozhi-esp32 (tag v2.4.2).
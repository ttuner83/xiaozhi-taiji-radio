#include "taiji_web_radio.h"
#include "esp32_music.h"
#include "radio_face_image.h"

#include "application.h"
#include "board.h"
#include "settings.h"
#include "mcp_server.h"
#include "display/display.h"

#include <algorithm>
#include <cstring>
#include <atomic>
#include <cstdlib>
#include <cstdio>
#include <cctype>
#include <new>

#include <cJSON.h>
#include <esp_http_client.h>
#include <esp_crt_bundle.h>
#include <esp_wifi.h>
#include <esp_log.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <wifi_manager.h>

#define TAG "TaijiWebRadio"
#define MAX_STATIONS 8
// Keep Wi-Fi awake while either the radio or the voice assistant is active.
// In idle state, return to modem-sleep so the device can wait for the wake word
// with lower Wi-Fi power consumption.
int TaijiWebRadio::GetIdleTimeoutSeconds() {
    Settings st("radio", false);
    int seconds = atoi(st.GetString("idle_seconds", "15").c_str());
    if (seconds < 1) seconds = 1;
    if (seconds > 3600) seconds = 3600;
    return seconds;
}

void TaijiWebRadio::UpdateWifiPowerSave() {
    const bool radio_active = instance_ != nullptr && instance_->IsRadioActive();
    const auto state = Application::GetInstance().GetDeviceState();
    // Only the idle state is allowed to use Wi-Fi modem-sleep. All other
    // application states keep Wi-Fi awake because they may involve network
    // activity or audio playback/recording.
    // The state machine may become IDLE before the final assistant audio packets
    // and protocol channel have drained. Treat that tail as active work too.
    const bool assistant_active = state != kDeviceStateIdle ||
        !Application::GetInstance().CanEnterSleepMode();

    const wifi_ps_type_t target = (radio_active || assistant_active)
        ? WIFI_PS_NONE
        : WIFI_PS_MIN_MODEM;

    static wifi_ps_type_t last_mode = WIFI_PS_MAX_MODEM;
    if (target != last_mode) {
        esp_err_t err = esp_wifi_set_ps(target);
        if (err == ESP_OK) {
            last_mode = target;
            ESP_LOGI(TAG, "Wi-Fi power save: %s",
                     target == WIFI_PS_NONE ? "NONE" : "MIN_MODEM");
        } else {
            ESP_LOGW(TAG, "Failed to set Wi-Fi power save mode %d: %s",
                     (int)target, esp_err_to_name(err));
        }
    }
}

// Wikipedia reference: bounded HTTP responses to protect ESP32-S3 RAM.
struct WikiHttpBuffer { std::string body; size_t limit = 12000; };
static esp_err_t WikiHttpEvent(esp_http_client_event_t* evt) {
    if (evt && evt->event_id == HTTP_EVENT_ON_DATA && evt->user_data && evt->data && evt->data_len > 0) {
        auto* b = static_cast<WikiHttpBuffer*>(evt->user_data);
        if (b->body.size() + static_cast<size_t>(evt->data_len) <= b->limit)
            b->body.append(static_cast<const char*>(evt->data), evt->data_len);
    }
    return ESP_OK;
}
static std::string WikiUrlEncode(const std::string& in) {
    static const char hex[] = "0123456789ABCDEF"; std::string out;
    for (unsigned char c : in) {
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c=='-' || c=='_' || c=='.' || c=='~') out += (char)c;
        else if (c == ' ') out += "%20";
        else { out += '%'; out += hex[c >> 4]; out += hex[c & 15]; }
    }
    return out;
}
static bool WikiGet(const std::string& url, std::string& body, size_t max_size=12000) {
    WikiHttpBuffer buffer; buffer.limit=max_size;
    esp_http_client_config_t cfg = {};
    cfg.url=url.c_str(); cfg.event_handler=WikiHttpEvent; cfg.user_data=&buffer;
    cfg.crt_bundle_attach=esp_crt_bundle_attach; // Required: verify Wikipedia TLS certificate.
    cfg.timeout_ms=9000; cfg.buffer_size=2048; cfg.buffer_size_tx=1024;
    cfg.disable_auto_redirect=false; cfg.max_redirection_count=3;
    esp_http_client_handle_t client=esp_http_client_init(&cfg);
    if (!client) return false;
    esp_http_client_set_header(client,"User-Agent","XiaozhiTaijiRadio/1.0 (Wikipedia reference)");
    esp_http_client_set_header(client,"Accept","application/json");
    esp_err_t err=esp_http_client_perform(client);
    int status=esp_http_client_get_status_code(client);
    esp_http_client_cleanup(client); body.swap(buffer.body);
    return err==ESP_OK && status>=200 && status<300 && !body.empty();
}
static std::string WikiSummary(const std::string& query) {
    if (query.empty()) return "Назовите тему или термин для поиска в Википедии.";
    std::string body;
    const std::string search_url="https://ru.wikipedia.org/w/api.php?action=query&list=search&srsearch="+WikiUrlEncode(query)+"&srlimit=1&format=json&utf8=1";
    if (!WikiGet(search_url,body,10000)) return "Не удалось подключиться к русской Википедии. Проверьте интернет-соединение.";
    cJSON* root=cJSON_Parse(body.c_str()); if (!root) return "Википедия вернула некорректный ответ.";
    cJSON* query_obj=cJSON_GetObjectItem(root,"query"); cJSON* results=query_obj?cJSON_GetObjectItem(query_obj,"search"):nullptr;
    cJSON* first=(results && cJSON_IsArray(results))?cJSON_GetArrayItem(results,0):nullptr;
    cJSON* title=first?cJSON_GetObjectItem(first,"title"):nullptr;
    std::string article=(cJSON_IsString(title)&&title->valuestring)?title->valuestring:""; cJSON_Delete(root);
    if (article.empty()) return "В русской Википедии не нашлось подходящей статьи по запросу: "+query;
    const std::string extract_url="https://ru.wikipedia.org/w/api.php?action=query&prop=extracts&exintro=1&explaintext=1&exchars=1800&redirects=1&titles="+WikiUrlEncode(article)+"&format=json&utf8=1";
    if (!WikiGet(extract_url,body,12000)) return "Нашёл статью «"+article+"», но не удалось загрузить её краткое содержание.";
    root=cJSON_Parse(body.c_str()); if (!root) return "Нашёл статью «"+article+"», но ответ с описанием не удалось разобрать.";
    query_obj=cJSON_GetObjectItem(root,"query"); cJSON* pages=query_obj?cJSON_GetObjectItem(query_obj,"pages"):nullptr;
    cJSON* page=(pages && cJSON_IsObject(pages))?pages->child:nullptr; cJSON* extract=page?cJSON_GetObjectItem(page,"extract"):nullptr;
    std::string summary=(cJSON_IsString(extract)&&extract->valuestring)?extract->valuestring:""; cJSON_Delete(root);
    if (summary.empty()) return "Статья «"+article+"» найдена, но краткое описание отсутствует.";
    // Keep TTS response concise and avoid reading excessive text.
    if (summary.size()>1700) {
        summary.resize(1700);
        while (!summary.empty() && (static_cast<unsigned char>(summary.back()) & 0xC0) == 0x80) summary.pop_back();
        if (!summary.empty()) {
            const unsigned char last = static_cast<unsigned char>(summary.back());
            if ((last & 0xE0) == 0xC0 || (last & 0xF0) == 0xE0 || (last & 0xF8) == 0xF0) summary.pop_back();
        }
    }
    return "По данным русской Википедии. Статья: "+article+". "+summary;
}

TaijiWebRadio* TaijiWebRadio::instance_ = nullptr;
static std::atomic<bool> g_radio_assistant_duck{false};

bool TaijiWebRadio::IsRadioActive() const {
    // Keep the device awake for the whole music-player session, including the
    // short gap between network download completion and the final decoded PCM.
    // The player screen remains open until the user explicitly returns to the assistant.
    return radio_.IsPlaying() || radio_.IsDownloading() || music_ui_visible_ ||
           music_search_active_.load() ||
           (music_player_ && (music_player_->IsPlaying() || music_player_->IsDownloading()));
}

bool TaijiWebRadio::IsAnyRadioActive() {
    return instance_ != nullptr && instance_->IsRadioActive();
}

bool TaijiWebRadio::StopActiveRadioFromVoice() {
    auto* radio = instance_;
    if (radio == nullptr) return false;
    bool stopped = false;
    if (radio->radio_.IsPlaying() || radio->radio_.IsDownloading()) {
        ESP_LOGI(TAG, "Local voice command: stopping Internet radio");
        stopped = radio->StopPlayback() || stopped;
    }
    if (radio->music_player_ && radio->music_player_->IsPlaying()) {
        ESP_LOGI(TAG, "Wake-word/voice command: stopping music stream");
        radio->music_player_->StopStreaming();
        radio->ShowMusicUi(false);
        stopped = true;
    }
    return stopped;
}

void TaijiWebRadio::SetAssistantDuck(bool enabled) { g_radio_assistant_duck.store(enabled); }
bool TaijiWebRadio::IsAssistantDuckActive() { return g_radio_assistant_duck.load(); }


static const char kHtml[] = R"HTML(
<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Taiji Pi Radio</title>
<style>
body{font-family:Arial,sans-serif;max-width:760px;margin:20px auto;padding:0 12px;background:#f4f4f4;color:#222}
h2{margin-bottom:8px}.card{background:#fff;padding:14px;margin:10px 0;border-radius:10px}
input,select,button{font-size:16px;padding:9px;margin:4px 0;box-sizing:border-box}
input{width:100%}button{cursor:pointer}.row{display:flex;gap:8px;flex-wrap:wrap}.row button{flex:1}
small{color:#666;word-break:break-all}.playing{font-weight:bold}
</style></head><body>
<h2>Taiji Pi S3 — Internet Radio</h2>
<div class="card"><div id="list">Загрузка...</div></div>
<div class="card"><b>Добавить / изменить станцию</b>
<input id="slot" type="number" min="0" max="7" value="0" placeholder="Номер 0..7">
<input id="name" placeholder="Название станции">
<input id="url" placeholder="http://... или https://...">
<select id="type"><option value="mp3">MP3</option><option value="aac">AAC</option><option value="ogg">OGG/Opus</option><option value="wav">WAV</option></select>
<div class="row"><button onclick="save()">Сохранить</button><button onclick="stop()">Стоп</button></div>
</div>
<div class="card"><b>Настройки энергосбережения и источников</b>
<label>Выключать дисплей после ожидания (секунды)</label><input id="idleSeconds" type="number" min="1" max="3600" value="15">
<label>RSS новости — адрес 1</label><input id="rss1" placeholder="https://...">
<label>RSS новости — адрес 2</label><input id="rss2" placeholder="https://...">
<label>RSS новости — адрес 3</label><input id="rss3" placeholder="https://...">
<label>Адрес парсера дронов</label><input id="droneUrl" placeholder="https://...">
<button onclick="saveConfig()">Сохранить настройки</button><small id="configStatus"></small>
</div>
<script>
async function loadConfig(){try{let c=await(await fetch('/api/config')).json();document.getElementById('idleSeconds').value=c.idle_seconds||15;document.getElementById('rss1').value=c.rss1||'';document.getElementById('rss2').value=c.rss2||'';document.getElementById('rss3').value=c.rss3||'';document.getElementById('droneUrl').value=c.drone_url||'';}catch(e){document.getElementById('configStatus').textContent='Не удалось загрузить настройки';}}
async function saveConfig(){let c={idle_seconds:+document.getElementById('idleSeconds').value,rss1:document.getElementById('rss1').value,rss2:document.getElementById('rss2').value,rss3:document.getElementById('rss3').value,drone_url:document.getElementById('droneUrl').value};let r=await fetch('/api/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(c)});document.getElementById('configStatus').textContent=r.ok?'Сохранено':'Ошибка сохранения';}
async function load(){
 let r=await fetch('/api/radios'); let a=await r.json();
 let h='';
 a.forEach((x,i)=>{if(!x.url)return;
 h+=`<div class="card"><b>${i}: ${esc(x.name||'Без названия')}</b><br><small>${esc(x.url)} [${esc(x.type||'mp3')}]</small>
 <div class="row"><button onclick="play(${i})">▶ Играть</button><button onclick="edit(${i})">Изменить</button><button onclick="del(${i})">Удалить</button></div></div>`});
 document.getElementById('list').innerHTML=h||'Станций пока нет';
}
function esc(s){return String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]))}
async function save(){
 let o={slot:+slot.value,name:name.value,url:url.value,type:type.value};
 await fetch('/api/radios',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(o)});
 load();
}
async function play(i){await fetch('/api/play?slot='+i);load()}
async function stop(){await fetch('/api/stop')}
async function del(i){await fetch('/api/radios',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({slot:i,delete:true})});load()}
async function edit(i){
 let a=await (await fetch('/api/radios')).json(),x=a[i];
 slot.value=i;name.value=x.name||'';url.value=x.url||'';type.value=x.type||'mp3';
}
load();loadConfig();
</script></body></html>
)HTML";

static bool ReadBody(httpd_req_t* req, std::string& body) {
    if (req->content_len <= 0 || req->content_len > 4096) {
        return false;
    }
    body.resize(req->content_len);
    size_t received = 0;
    while (received < body.size()) {
        int ret = httpd_req_recv(req, body.data() + received, body.size() - received);
        if (ret <= 0) {
            return false;
        }
        received += ret;
    }
    return true;
}

// Normalize UTF-8 Russian station names for voice matching: ignore punctuation/spacing,
// fold ASCII and Cyrillic uppercase, and treat ё/е as equivalent.
static std::string NormalizeStationName(const std::string& input) {
    std::string out;
    out.reserve(input.size());
    for (size_t i = 0; i < input.size(); ++i) {
        unsigned char c = static_cast<unsigned char>(input[i]);
        if (c == 0xD0 && i + 1 < input.size()) {
            unsigned char n = static_cast<unsigned char>(input[i + 1]);
            if (n >= 0x90 && n <= 0xAF) n = static_cast<unsigned char>(n + 0x20); // А-Я -> а-я
            if (n == 0x81) { // Ё -> ё, then fold ё to е below
                out += "е";
                ++i;
                continue;
            }
            out.push_back(static_cast<char>(c));
            out.push_back(static_cast<char>(n));
            ++i;
            continue;
        }
        if (c == 0xD1 && i + 1 < input.size()) {
            unsigned char n = static_cast<unsigned char>(input[i + 1]);
            if (n == 0x91) { out += "е"; ++i; continue; } // ё -> е
            out.push_back(static_cast<char>(c));
            out.push_back(static_cast<char>(n));
            ++i;
            continue;
        }
        if (c < 0x80) {
            if (std::isalnum(c)) out.push_back(static_cast<char>(std::tolower(c)));
            continue;
        }
        out.push_back(static_cast<char>(c));
    }
    return out;
}

TaijiWebRadio::TaijiWebRadio() {
    instance_ = this;
    radio_.Initialize();
    music_player_ = std::make_unique<Esp32Music>();

    LoadStations();

    auto& mcp = McpServer::GetInstance();
    mcp.AddTool("self.wikipedia.search",
        "Найди справочную информацию в русской Википедии и озвучь краткое содержание статьи. Используй для вопросов вида «что такое ...», «расскажи о ...», «найди в Википедии ...», когда нужен энциклопедический факт или описание. Передай короткую тему поиска в параметре query. Это справочный источник, не источник оперативных новостей.",
        PropertyList({Property("query", kPropertyTypeString)}),
        [](const PropertyList& properties) -> ReturnValue {
            const std::string query=properties["query"].value<std::string>();
            ESP_LOGI(TAG, "Wikipedia lookup requested (query length=%u)", (unsigned)query.size());
            return WikiSummary(query);
        });
    mcp.AddTool("self.network.get_ip",
        "Report the current local Wi-Fi IP address and web radio interface URL. Use for requests such as: 'Скажи свой IP', 'Какой у тебя IP-адрес?', 'Назови адрес веб-интерфейса в локальной сети'.",
        PropertyList(),
        [](const PropertyList&) -> ReturnValue {
            auto& wifi = WifiManager::GetInstance();
            std::string ip = wifi.GetIpAddress();
            if (ip.empty()) return std::string("Wi-Fi не подключён, локальный IP пока неизвестен.");
            return std::string("Локальный IP устройства: ") + ip + ". Веб-интерфейс радио: http://" + ip + "/";
        });
    auto music_search_handler = [this](const PropertyList& properties) -> ReturnValue {
        const std::string song = properties["song_name"].value<std::string>();
        const std::string artist = properties["artist_name"].value<std::string>();
        ESP_LOGI(TAG, "Music search tool invoked: song='%s', artist='%s'", song.c_str(), artist.c_str());
        if ((song.empty() && artist.empty()) || !music_player_) return std::string("Нет такой.");
        if (!PlayMusicSearch(song, artist, true)) {
            if (music_player_ && music_player_->HasPendingShortSong()) {
                const size_t bytes = music_player_->GetPendingShortSongSize();
                return std::string("Полноразмерную запись больше 1 МБ не нашёл. Есть короткий вариант ") +
                       music_player_->GetCurrentArtist() + " — " + music_player_->GetCurrentSong() +
                       " (" + std::to_string(bytes / 1024) + " КБ). Включить его? Если согласится — вызови self.music.confirm_short_song; без согласия не запускай.";
            }
            return std::string("Нет такой.");
        }
        // Success is deliberately silent. Do not narrate search progress or results.
        return std::string("");
    };
    const PropertyList music_search_properties({Property("song_name", kPropertyTypeString), Property("artist_name", kPropertyTypeString, "")});
    mcp.AddTool("self.music.play_song",
        "ОБЯЗАТЕЛЬНО вызывай этот инструмент каждый раз, когда пользователь просит найти, включить или поставить песню; не отвечай, что уже искал, и не объявляй отказ до результата инструмента. Инструмент может работать 30 секунд и дольше: дождись его завершения, не прерывай и не делай вывод по памяти. Ищи молча: не говори «сейчас поищу», не комментируй результаты; при успехе ничего не произноси, при неудаче ответь только «Нет такой». Если назван исполнитель и сказано «любую песню», «что-нибудь группы» или название песни не указано, передай song_name пустой строкой, artist_name — имя исполнителя; будет выбран подходящий трек этого исполнителя. Если указаны и песня, и исполнитель, не включай другую песню вместо запрошенной. Передавай название и исполнителя на языке, указанном пользователем, не транслитерируй самовольно. Устройство проверяет размер файла и пропускает известные варианты меньше 1 МБ; если полноразмерной записи нет, сначала спроси разрешение на короткую запись. Используется только публичный Meting API (NetEase), без резервных музыкальных источников.",
        music_search_properties, music_search_handler);
// Confirm a known-small file only after the user explicitly agrees.
    mcp.AddTool("self.music.confirm_short_song",
        "Вызывай только после явного согласия пользователя включить найденную неполную песню размером меньше 1 МБ. Не вызывай при сомнении или отказе.",
        PropertyList(), [this](const PropertyList&) -> ReturnValue {
            if (!ConfirmShortSongPlayback()) return std::string("Не удалось запустить сохранённый короткий вариант песни.");
            return std::string("");
        });
// Не регистрируем короткий alias search_music: это имя уже занято другим MCP-инструментом.
    mcp.AddTool("self.music.stop", "Останови воспроизведение музыки.", PropertyList(),
        [this](const PropertyList&) -> ReturnValue {
            if (music_player_) music_player_->StopStreaming();
            UpdateMusicUi();
            return std::string("Воспроизведение музыки остановлено.");
        });
    mcp.AddTool("self.radio.play",
        "Start the selected saved Internet radio station. Use for requests such as: 'Включи радио', 'Запусти радио'.",
        PropertyList(),
        [this](const PropertyList&) -> ReturnValue { return PlaySelected(); });
    mcp.AddTool("self.radio.play_station",
        "Start a saved Internet radio station by number. The user-visible station numbers start at 1. Use for requests such as: 'Включи станцию 4', 'Запусти станцию номер 4'.",
        PropertyList({Property("station", kPropertyTypeInteger, 1, 1, MAX_STATIONS)}),
        [this](const PropertyList& properties) -> ReturnValue {
            return PlayStation(properties["station"].value<int>());
        });
    mcp.AddTool("self.radio.play_station_by_name",
        "Включи радиостанцию по её названию из текущего списка веб-интерфейса. Используй для фраз «включи радио Европа Плюс», «включи радио Рок Арсенал», «поставь радио [название]». Название бери из слов пользователя и передавай целиком; не выбирай номер станции по памяти — устройство само сопоставит имя с актуальными станциями, сохранёнными в веб-интерфейсе. Если совпадения нет, сообщи об этом и предложи проверить название в веб-интерфейсе.",
        PropertyList({Property("name", kPropertyTypeString)}),
        [this](const PropertyList& properties) -> ReturnValue {
            const std::string name = properties["name"].value<std::string>();
            const bool ok = PlayStationByName(name);
            return ok ? ReturnValue(std::string("Включаю радиостанцию: ") + name)
                      : ReturnValue(std::string("Не нашёл станцию «") + name + "» среди настроенных в веб-интерфейсе.");
        });
    mcp.AddTool("self.radio.next",
        "Switch to the next configured Internet radio station and start it. Use for requests such as: 'Следующая радиостанция', 'Переключи радио'.",
        PropertyList(),
        [this](const PropertyList&) -> ReturnValue { return NextStation(); });
    mcp.AddTool("self.radio.stop",
        "Вызови self.radio.stop при любой просьбе выключить или остановить интернет-радио/музыку: «выключи радио», «выруби радио», «отключи радио», «останови радио», «хватит радио», «стоп радио», «выключи музыку». Не отвечай только словами — выполни инструмент. Он останавливает поток и не меняет громкость помощника.",
        PropertyList(),
        [this](const PropertyList&) -> ReturnValue {
            const bool stopped = StopPlayback();
            return stopped ? ReturnValue(std::string("Радио выключено.")) : ReturnValue(std::string("Не удалось штатно остановить радио."));
        });
    mcp.AddTool("self.radio.get_volume",
        "Get ONLY the independent Internet radio volume (0-100%). This is separate from self.audio_speaker.set_volume. Use for radio volume requests such as 'громкость радио', 'радио громче' or 'радио тише'.",
        PropertyList(),
        [this](const PropertyList&) -> ReturnValue { return radio_.GetVolume(); });
    mcp.AddTool("self.radio.set_volume",
        "Set ONLY the independent Internet radio volume from 0 to 100%. NEVER use self.audio_speaker.set_volume for this. Use this tool when the user says 'громкость радио 30%', 'радио 30%', 'громкость радио', 'сделай радио тише' or 'сделай радио громче'. This must not change the voice assistant volume.",
        PropertyList({Property("volume", kPropertyTypeInteger, 40, 0, 100)}),
        [this](const PropertyList& properties) -> ReturnValue {
            radio_.SetVolume(properties["volume"].value<int>());
            if (radio_ui_visible_) {
                auto display = Board::GetInstance().GetDisplay();
                if (display) {
                    DisplayLockGuard lock(display);
                    if (lock) UpdateRadioStationLabel();
                }
            }
            return true;
        });
}

TaijiWebRadio::~TaijiWebRadio() {
    Stop();
    if (silent_standby_timer_) {
        esp_timer_delete(silent_standby_timer_);
        silent_standby_timer_ = nullptr;
    }
    if (radio_button_flash_timer_) { lv_timer_delete(radio_button_flash_timer_); radio_button_flash_timer_ = nullptr; }
    if (instance_ == this) {
        instance_ = nullptr;
    }
}

void TaijiWebRadio::LoadStations() {
    stations_.clear();
    stations_.resize(MAX_STATIONS);
    Settings settings("radio", false);
    struct Preset { const char* name; const char* url; const char* type; };
    static const Preset presets[MAX_STATIONS] = {
        {"Европа Плюс", "http://emgregion.hostingradio.ru:8064/moscow.europaplus.mp3", "mp3"},
        {"Рок Классик", "https://stream06.pcradio.app/Rock_Legend-med", "mp3"},
        {"Кассета Диско", "https://casseta-disco.ru:1090/stream", "mp3"},
        {"Рок Атака", "https://listen7.myradio24.com/rockataka", "mp3"},
        {"Максимус Рок", "https://maximusrockfm.stream.laut.fm/maximusrockfm", "mp3"},
        {"Рок Арсенал", "https://online.rockarsenal.ru/rockwotalk?5423", "mp3"},
        {"Наше Рок", "https://nashe1.hostingradio.ru/nasheclassic.mp3", "mp3"},
        {"Мелодия", "http://stream128.melodiafm.spb.ru:8000/melodia128", "mp3"},
    };
    for (int i = 0; i < MAX_STATIONS; ++i) {
        std::string key = "r" + std::to_string(i);
        std::string value = settings.GetString(key, "");
        if (value.empty()) {
            stations_[i].name = presets[i].name;
            stations_[i].url = presets[i].url;
            stations_[i].type = presets[i].type;
            continue;
        }
        cJSON* obj = cJSON_Parse(value.c_str());
        if (!obj) {
            continue;
        }
        auto get = [&](const char* key) -> std::string {
            cJSON* item = cJSON_GetObjectItemCaseSensitive(obj, key);
            return cJSON_IsString(item) ? item->valuestring : "";
        };
        stations_[i].name = get("name");
        if (stations_[i].name.empty()) {
            stations_[i].name = settings.GetString("n" + std::to_string(i), "");
        }
        stations_[i].url = get("url");
        stations_[i].type = get("type");
        if (stations_[i].type.empty()) {
            stations_[i].type = "mp3";
        }
        cJSON_Delete(obj);
    }

    // Migrate only the old built-in defaults saved by earlier firmware.
    // User-customized stations are left untouched.
    struct Migration { int slot; const char* old_name; const char* old_url; const char* new_name; const char* new_url; };
    static const Migration migrations[] = {
        {0, "Мелодия", "http://stream128.melodiafm.spb.ru:8000/melodia128", "Европа Плюс", "http://emgregion.hostingradio.ru:8064/moscow.europaplus.mp3"},
        {1, "Европа Плюс", "http://emgregion.hostingradio.ru:8064/moscow.europaplus.mp3", "Рок Классик", "https://stream06.pcradio.app/Rock_Legend-med"},
        {1, "Рок Классик", "https://strm112.1.fm/rockclassics_mobile_mp3", "Рок Классик", "https://stream06.pcradio.app/Rock_Legend-med"},
        {1, "Рок Классик", "https://strm112.1.fm/crock_mobile_mp3", "Рок Классик", "https://stream06.pcradio.app/Rock_Legend-med"},
        {1, "STAR FM Classic", "https://stream.starfm.de/classic/mp3-128/stream.starfm.de/", "Рок Классик", "https://stream06.pcradio.app/Rock_Legend-med"},
        {2, "Радио Рекорд", "http://online.radiorecord.ru:8102/sd90_128", "Кассета Диско", "https://casseta-disco.ru:1090/stream"},
        {6, "Мелодия", "http://stream128.melodiafm.spb.ru:8000/melodia128", "Наше Рок", "https://nashe1.hostingradio.ru/nasheclassic.mp3"},
        {7, "Наше Рок", "https://nashe1.hostingradio.ru/nasheclassic.mp3", "Мелодия", "http://stream128.melodiafm.spb.ru:8000/melodia128"},
    };
    for (const auto& m : migrations) {
        if (stations_[m.slot].name == m.old_name && stations_[m.slot].url == m.old_url) {
            Station station;
            station.name = m.new_name;
            station.url = m.new_url;
            station.type = "mp3";
            SaveStation(m.slot, station);
        }
    }
}

void TaijiWebRadio::SaveStation(int slot, const Station& station) {
    if (slot < 0 || slot >= MAX_STATIONS) {
        return;
    }
    cJSON* obj = cJSON_CreateObject();
    cJSON_AddStringToObject(obj, "name", station.name.c_str());
    cJSON_AddStringToObject(obj, "url", station.url.c_str());
    cJSON_AddStringToObject(obj, "type", station.type.c_str());
    char* text = cJSON_PrintUnformatted(obj);
    Settings settings("radio", true);
    settings.SetString("r" + std::to_string(slot), text ? text : "");
    settings.SetString("n" + std::to_string(slot), station.name);
    if (text) {
        cJSON_free(text);
    }
    cJSON_Delete(obj);
    stations_[slot] = station;
}

void TaijiWebRadio::ClearStation(int slot) {
    if (slot < 0 || slot >= MAX_STATIONS) {
        return;
    }
    Settings settings("radio", true);
    settings.EraseKey("r" + std::to_string(slot));
    settings.EraseKey("n" + std::to_string(slot));
    stations_[slot] = Station{};
}

void TaijiWebRadio::Start() {
    if (server_) {
        return;
    }

    httpd_config_t config = HTTPD_DEFAULT_CONFIG();
    config.server_port = 80;
    config.max_uri_handlers = 12;
    config.stack_size = 8192;

    if (httpd_start(&server_, &config) != ESP_OK) {
        server_ = nullptr;
        ESP_LOGE(TAG, "Failed to start HTTP server");
        return;
    }

    httpd_uri_t root = {.uri = "/", .method = HTTP_GET, .handler = RootHandler, .user_ctx = this};
    httpd_uri_t get = {.uri = "/api/radios", .method = HTTP_GET, .handler = StationsGetHandler, .user_ctx = this};
    httpd_uri_t post = {.uri = "/api/radios", .method = HTTP_POST, .handler = StationsPostHandler, .user_ctx = this};
    httpd_uri_t play = {.uri = "/api/play", .method = HTTP_GET, .handler = PlayHandler, .user_ctx = this};
    httpd_uri_t stop = {.uri = "/api/stop", .method = HTTP_GET, .handler = StopHandler, .user_ctx = this};
    httpd_uri_t cfgget = {.uri = "/api/config", .method = HTTP_GET, .handler = ConfigGetHandler, .user_ctx = this};
    httpd_uri_t cfgpost = {.uri = "/api/config", .method = HTTP_POST, .handler = ConfigPostHandler, .user_ctx = this};

    httpd_register_uri_handler(server_, &root);
    httpd_register_uri_handler(server_, &get);
    httpd_register_uri_handler(server_, &post);
    httpd_register_uri_handler(server_, &play);
    httpd_register_uri_handler(server_, &stop);
    httpd_register_uri_handler(server_, &cfgget);
    httpd_register_uri_handler(server_, &cfgpost);

    ESP_LOGI(TAG, "Local radio server started");
}

bool TaijiWebRadio::PlaySelected() {
    int slot = current_slot_;
    if (slot < 0 || slot >= MAX_STATIONS || stations_[slot].url.empty()) {
        slot = -1;
        for (int i = 0; i < MAX_STATIONS; ++i) {
            if (!stations_[i].url.empty()) {
                slot = i;
                break;
            }
        }
    }
    if (slot < 0) {
        return false;
    }
    StartRadio(slot);
    return true;
}

bool TaijiWebRadio::PlayStation(int station_number) {
    const int slot = station_number - 1;
    if (station_number < 1 || station_number > MAX_STATIONS ||
        stations_[slot].url.empty()) {
        ESP_LOGW(TAG, "Station number %d is not configured", station_number);
        return false;
    }
    StartRadio(slot);
    return true;
}

bool TaijiWebRadio::PlayStationByName(const std::string& spoken_name) {
    const std::string query = NormalizeStationName(spoken_name);
    if (query.empty()) return false;

    int best_slot = -1;
    int best_score = -1;
    for (int i = 0; i < MAX_STATIONS; ++i) {
        if (stations_[i].url.empty() || stations_[i].name.empty()) continue;
        const std::string name = NormalizeStationName(stations_[i].name);
        if (name.empty()) continue;

        int score = -1;
        if (query == name) score = 10000 + static_cast<int>(name.size());
        else if (query.find(name) != std::string::npos) score = 5000 + static_cast<int>(name.size());
        else if (name.find(query) != std::string::npos && query.size() >= 4)
            score = 3000 + static_cast<int>(query.size());
        else {
            // Conservative token-overlap fallback for minor recognition errors.
            // It is used only if at least two three-character fragments match.
            if (name.size() >= 5 && query.size() >= 5) {
                size_t common = 0;
                for (size_t p = 0; p + 2 < name.size(); ++p) {
                    if (query.find(name.substr(p, 3)) != std::string::npos) common += 3;
                }
                if (common >= 6) score = static_cast<int>(common);
            }
        }
        if (score > best_score) { best_score = score; best_slot = i; }
    }

    // Require a reasonably strong match; ambiguous or partial requests must not switch randomly.
    if (best_slot < 0 || best_score < 6) {
        ESP_LOGW(TAG, "No configured station matches spoken name: %s", spoken_name.c_str());
        return false;
    }
    ESP_LOGI(TAG, "Voice station match '%s' -> slot %d '%s'", spoken_name.c_str(),
             best_slot + 1, stations_[best_slot].name.c_str());
    StartRadio(best_slot);
    return true;
}

bool TaijiWebRadio::NextStation() {
    int start = current_slot_;
    if (start < 0 || start >= MAX_STATIONS) {
        start = -1;
    }
    for (int n = 1; n <= MAX_STATIONS; ++n) {
        int slot = (start + n) % MAX_STATIONS;
        if (!stations_[slot].url.empty()) {
            StartRadio(slot);
            return true;
        }
    }
    return false;
}

bool TaijiWebRadio::StopPlayback() {
    StopRadio();
    return true;
}

void TaijiWebRadio::Stop() {
    StopRadio();
    if (music_player_) music_player_->StopStreaming();
    if (music_ui_visible_) ShowMusicUi(false);
    if (server_) {
        httpd_stop(server_);
        server_ = nullptr;
    }
}

esp_err_t TaijiWebRadio::RootHandler(httpd_req_t* req) {
    return static_cast<TaijiWebRadio*>(req->user_ctx)->HandleRoot(req);
}
esp_err_t TaijiWebRadio::StationsGetHandler(httpd_req_t* req) {
    return static_cast<TaijiWebRadio*>(req->user_ctx)->HandleStationsGet(req);
}
esp_err_t TaijiWebRadio::StationsPostHandler(httpd_req_t* req) {
    return static_cast<TaijiWebRadio*>(req->user_ctx)->HandleStationsPost(req);
}
esp_err_t TaijiWebRadio::PlayHandler(httpd_req_t* req) {
    return static_cast<TaijiWebRadio*>(req->user_ctx)->HandlePlay(req);
}
esp_err_t TaijiWebRadio::StopHandler(httpd_req_t* req) {
    return static_cast<TaijiWebRadio*>(req->user_ctx)->HandleStop(req);
}

esp_err_t TaijiWebRadio::ConfigGetHandler(httpd_req_t* req) { return static_cast<TaijiWebRadio*>(req->user_ctx)->HandleConfigGet(req); }
esp_err_t TaijiWebRadio::ConfigPostHandler(httpd_req_t* req) { return static_cast<TaijiWebRadio*>(req->user_ctx)->HandleConfigPost(req); }

esp_err_t TaijiWebRadio::HandleConfigGet(httpd_req_t* req) {
    Settings st("radio", false);
    cJSON* o = cJSON_CreateObject();
    if (!o) { httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "Out of memory"); return ESP_OK; }
    cJSON_AddNumberToObject(o, "idle_seconds", atoi(st.GetString("idle_seconds", "15").c_str()));
    cJSON_AddStringToObject(o, "rss1", st.GetString("rss1", "").c_str());
    cJSON_AddStringToObject(o, "rss2", st.GetString("rss2", "").c_str());
    cJSON_AddStringToObject(o, "rss3", st.GetString("rss3", "").c_str());
    cJSON_AddStringToObject(o, "drone_url", st.GetString("drone_url", "").c_str());
    char* out = cJSON_PrintUnformatted(o); cJSON_Delete(o);
    httpd_resp_set_type(req, "application/json");
    esp_err_t e = httpd_resp_send(req, out ? out : "{}", HTTPD_RESP_USE_STRLEN);
    if (out) cJSON_free(out);
    return e;
}

esp_err_t TaijiWebRadio::HandleConfigPost(httpd_req_t* req) {
    std::string body;
    if (!ReadBody(req, body)) { httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Invalid body"); return ESP_OK; }
    cJSON* o = cJSON_Parse(body.c_str());
    if (!o) { httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Invalid JSON"); return ESP_OK; }
    cJSON* sec = cJSON_GetObjectItem(o, "idle_seconds");
    int n = cJSON_IsNumber(sec) ? sec->valueint : 15;
    if (n < 1) n = 1;
    if (n > 3600) n = 3600;
    Settings st("radio", true); st.SetString("idle_seconds", std::to_string(n));
    const char* keys[] = {"rss1", "rss2", "rss3", "drone_url"};
    for (const char* k : keys) {
        cJSON* v = cJSON_GetObjectItem(o, k);
        if (cJSON_IsString(v) && v->valuestring && strlen(v->valuestring) <= 400) st.SetString(k, v->valuestring);
    }
    cJSON_Delete(o); httpd_resp_sendstr(req, "OK"); return ESP_OK;
}

esp_err_t TaijiWebRadio::HandleRoot(httpd_req_t* req) {
    httpd_resp_set_type(req, "text/html; charset=utf-8");
    return httpd_resp_send(req, kHtml, HTTPD_RESP_USE_STRLEN);
}

esp_err_t TaijiWebRadio::HandleStationsGet(httpd_req_t* req) {
    cJSON* array = cJSON_CreateArray();
    for (int i = 0; i < MAX_STATIONS; ++i) {
        cJSON* obj = cJSON_CreateObject();
        cJSON_AddNumberToObject(obj, "slot", i);
        cJSON_AddStringToObject(obj, "name", stations_[i].name.c_str());
        cJSON_AddStringToObject(obj, "url", stations_[i].url.c_str());
        cJSON_AddStringToObject(obj, "type", stations_[i].type.c_str());
        cJSON_AddBoolToObject(obj, "playing", current_slot_ == i && radio_.IsPlaying());
        cJSON_AddItemToArray(array, obj);
    }
    char* text = cJSON_PrintUnformatted(array);
    cJSON_Delete(array);
    httpd_resp_set_type(req, "application/json");
    esp_err_t ret = httpd_resp_send(req, text ? text : "[]", HTTPD_RESP_USE_STRLEN);
    if (text) {
        cJSON_free(text);
    }
    return ret;
}

esp_err_t TaijiWebRadio::HandleStationsPost(httpd_req_t* req) {
    std::string body;
    if (!ReadBody(req, body)) {
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Invalid body");
        return ESP_OK;
    }
    cJSON* obj = cJSON_Parse(body.c_str());
    if (!obj) {
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Invalid JSON");
        return ESP_OK;
    }

    cJSON* slot_item = cJSON_GetObjectItem(obj, "slot");
    int slot = cJSON_IsNumber(slot_item) ? slot_item->valueint : -1;
    cJSON* del = cJSON_GetObjectItem(obj, "delete");
    if (cJSON_IsTrue(del)) {
        StopRadio();
        ClearStation(slot);
    } else {
        cJSON* name = cJSON_GetObjectItem(obj, "name");
        cJSON* url = cJSON_GetObjectItem(obj, "url");
        cJSON* type = cJSON_GetObjectItem(obj, "type");
        if (slot < 0 || slot >= MAX_STATIONS || !cJSON_IsString(url)) {
            cJSON_Delete(obj);
            httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Invalid station");
            return ESP_OK;
        }
        Station station;
        station.name = cJSON_IsString(name) ? name->valuestring : "";
        station.url = url->valuestring;
        station.type = cJSON_IsString(type) ? type->valuestring : "mp3";
        if (station.url.size() > 400 || station.name.size() > 80) {
            cJSON_Delete(obj);
            httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Too long");
            return ESP_OK;
        }
        if (station.type != "mp3" && station.type != "aac" &&
            station.type != "ogg" && station.type != "wav") {
            station.type = "mp3";
        }
        SaveStation(slot, station);
    }
    cJSON_Delete(obj);
    httpd_resp_set_type(req, "application/json");
    return httpd_resp_sendstr(req, "{\"ok\":true}");
}

esp_err_t TaijiWebRadio::HandlePlay(httpd_req_t* req) {
    char query[64];
    char value[16];
    if (httpd_req_get_url_query_str(req, query, sizeof(query)) != ESP_OK ||
        httpd_query_key_value(query, "slot", value, sizeof(value)) != ESP_OK) {
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "slot required");
        return ESP_OK;
    }
    int slot = atoi(value);
    if (slot < 0 || slot >= MAX_STATIONS || stations_[slot].url.empty()) {
        httpd_resp_send_err(req, HTTPD_404_NOT_FOUND, "Station not found");
        return ESP_OK;
    }
    StartRadio(slot);
    return httpd_resp_sendstr(req, "{\"ok\":true}");
}

esp_err_t TaijiWebRadio::HandleStop(httpd_req_t* req) {
    StopRadio();
    return httpd_resp_sendstr(req, "{\"ok\":true}");
}

void TaijiWebRadio::SetPageIndicator(int page) {
    if (page < 0) page = 0;
    if (page > 2) page = 2;
    auto display = Board::GetInstance().GetDisplay();
    if (!display || !display->SupportsGuiOperations()) return;
    DisplayLockGuard lock(display);
    if (!lock) return;
    if (!page_indicator_root_) {
        page_indicator_root_ = lv_obj_create(lv_screen_active());
        lv_obj_set_size(page_indicator_root_, 78, 16);
        lv_obj_set_pos(page_indicator_root_, 141, 338);
        lv_obj_set_style_bg_opa(page_indicator_root_, LV_OPA_TRANSP, LV_PART_MAIN);
        lv_obj_set_style_border_width(page_indicator_root_, 0, LV_PART_MAIN);
        lv_obj_set_style_pad_all(page_indicator_root_, 0, LV_PART_MAIN);
        lv_obj_set_style_radius(page_indicator_root_, 0, LV_PART_MAIN);
        lv_obj_clear_flag(page_indicator_root_, LV_OBJ_FLAG_SCROLLABLE);
        lv_obj_clear_flag(page_indicator_root_, LV_OBJ_FLAG_CLICKABLE);
        // Three solid white dots: left=map, center=assistant, right=radio.
        const int centers[3] = {12, 39, 66};
        for (int i = 0; i < 3; ++i) {
            lv_obj_t* dot = lv_obj_create(page_indicator_root_);
            lv_obj_set_size(dot, 6, 6);
            lv_obj_set_pos(dot, centers[i] - 3, 5);
            lv_obj_set_style_radius(dot, LV_RADIUS_CIRCLE, LV_PART_MAIN);
            lv_obj_set_style_bg_color(dot, lv_color_white(), LV_PART_MAIN);
            lv_obj_set_style_bg_opa(dot, LV_OPA_COVER, LV_PART_MAIN);
            lv_obj_set_style_border_width(dot, 0, LV_PART_MAIN);
            lv_obj_set_style_pad_all(dot, 0, LV_PART_MAIN);
            lv_obj_clear_flag(dot, LV_OBJ_FLAG_CLICKABLE);
            lv_obj_clear_flag(dot, LV_OBJ_FLAG_SCROLLABLE);
        }
        // Active page is a short, thick white dash (the Android-style page pill).
        page_indicator_active_ = lv_obj_create(page_indicator_root_);
        lv_obj_set_size(page_indicator_active_, 20, 6);
        lv_obj_set_pos(page_indicator_active_, 2, 5);
        lv_obj_set_style_radius(page_indicator_active_, LV_RADIUS_CIRCLE, LV_PART_MAIN);
        lv_obj_set_style_bg_color(page_indicator_active_, lv_color_white(), LV_PART_MAIN);
        lv_obj_set_style_bg_opa(page_indicator_active_, LV_OPA_COVER, LV_PART_MAIN);
        lv_obj_set_style_border_width(page_indicator_active_, 0, LV_PART_MAIN);
        lv_obj_set_style_pad_all(page_indicator_active_, 0, LV_PART_MAIN);
        lv_obj_clear_flag(page_indicator_active_, LV_OBJ_FLAG_CLICKABLE);
        lv_obj_clear_flag(page_indicator_active_, LV_OBJ_FLAG_SCROLLABLE);
    }
    // Animate only the tiny indicator. Full-screen sliding would force the map and
    // assistant to redraw large areas during radio/network work and can cause stutter.
    lv_anim_delete(page_indicator_active_, nullptr);
    lv_anim_t anim;
    lv_anim_init(&anim);
    lv_anim_set_var(&anim, page_indicator_active_);
    lv_anim_set_values(&anim, lv_obj_get_x(page_indicator_active_), 2 + page * 27);
    lv_anim_set_time(&anim, 140);
    lv_anim_set_path_cb(&anim, lv_anim_path_ease_out);
    lv_anim_set_exec_cb(&anim, [](void* obj, int32_t x) { lv_obj_set_x(static_cast<lv_obj_t*>(obj), x); });
    lv_anim_start(&anim);
    lv_obj_move_foreground(page_indicator_root_);
}


void TaijiWebRadio::EnsureRadioUi() {
    if (radio_ui_root_) return;
    auto display = Board::GetInstance().GetDisplay();
    if (!display || !display->SupportsGuiOperations()) return;
    DisplayLockGuard lock(display);
    if (!lock) return;

    // Use the actual radio-face artwork from the approved composite reference.
    // The map artwork is not touched. Transparent hit zones are placed over the
    // three pictured buttons; only the station title is dynamically overlaid.
    radio_ui_root_ = lv_obj_create(lv_screen_active());
    lv_obj_set_size(radio_ui_root_, 360, 360);
    lv_obj_set_pos(radio_ui_root_, 0, 0);
    lv_obj_set_style_radius(radio_ui_root_, LV_RADIUS_CIRCLE, LV_PART_MAIN);
    lv_obj_set_style_border_width(radio_ui_root_, 0, LV_PART_MAIN);
    lv_obj_set_style_bg_color(radio_ui_root_, lv_color_black(), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(radio_ui_root_, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_pad_all(radio_ui_root_, 0, LV_PART_MAIN);
    lv_obj_clear_flag(radio_ui_root_, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_t* face = lv_image_create(radio_ui_root_);
    lv_image_set_src(face, &kRadioFaceImage);
    // Source artwork is 240x240 RGB565; upscale once to fit the round 360px display.
    lv_obj_set_pos(face, 60, 60);
    lv_image_set_scale(face, 384); // 1.5x; lower flash/RAM footprint than 360x360 source
    lv_obj_clear_flag(face, LV_OBJ_FLAG_CLICKABLE);

    // Live volume percentage sits immediately above the station name.
    radio_volume_label_ = lv_label_create(radio_ui_root_);
    lv_label_set_text(radio_volume_label_, "40%");
    lv_obj_set_size(radio_volume_label_, 100, 18);
    lv_obj_set_pos(radio_volume_label_, 130, 153);
    lv_obj_set_style_text_color(radio_volume_label_, lv_color_make(255, 196, 90), LV_PART_MAIN);
    lv_obj_set_style_text_font(radio_volume_label_, &lv_font_montserrat_14, LV_PART_MAIN);
    lv_obj_set_style_text_align(radio_volume_label_, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(radio_volume_label_, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_clear_flag(radio_volume_label_, LV_OBJ_FLAG_CLICKABLE);

    // Cover the station name printed in the reference image so the live station
    // name can be shown without changing the surrounding vintage panel artwork.
    // Narrow the panel slightly to make room for the +/- volume controls.
    lv_obj_t* title_panel = lv_obj_create(radio_ui_root_);
    lv_obj_set_size(title_panel, 204, 42);
    lv_obj_set_pos(title_panel, 78, 176);
    lv_obj_set_style_radius(title_panel, 3, LV_PART_MAIN);
    lv_obj_set_style_border_width(title_panel, 0, LV_PART_MAIN);
    lv_obj_set_style_bg_color(title_panel, lv_color_make(20, 13, 7), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(title_panel, LV_OPA_90, LV_PART_MAIN);
    lv_obj_set_style_pad_all(title_panel, 0, LV_PART_MAIN);
    lv_obj_clear_flag(title_panel, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_clear_flag(title_panel, LV_OBJ_FLAG_CLICKABLE);

    radio_station_label_ = lv_label_create(title_panel);
    lv_label_set_text(radio_station_label_, "Интернет-радио");
    lv_label_set_long_mode(radio_station_label_, LV_LABEL_LONG_DOT);
    lv_obj_set_width(radio_station_label_, 200);
    lv_obj_set_height(radio_station_label_, 36);
    lv_obj_set_style_bg_opa(radio_station_label_, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_set_style_text_align(radio_station_label_, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN);
    lv_obj_set_style_text_color(radio_station_label_, lv_color_make(255, 184, 66), LV_PART_MAIN);
    lv_obj_set_style_text_font(radio_station_label_, &lv_font_montserrat_14, LV_PART_MAIN);
    lv_obj_align(radio_station_label_, LV_ALIGN_CENTER, 0, 0);
    lv_obj_move_foreground(title_panel);

    // Transparent touch targets match the three physical-looking station controls.
    const int xs[3] = {70, 154, 237};
    const int ys[3] = {232, 232, 232};
    for (int i = 0; i < 3; ++i) {
        lv_obj_t* btn = lv_btn_create(radio_ui_root_);
        radio_buttons_[i] = btn;
        lv_obj_set_size(btn, 80, 84);
        const int wide_x[3] = {60, 140, 220};
        lv_obj_set_pos(btn, wide_x[i], ys[i] - 9);
        lv_obj_set_style_radius(btn, LV_RADIUS_CIRCLE, LV_PART_MAIN);
        lv_obj_set_style_bg_color(btn, lv_color_make(255, 170, 55), LV_PART_MAIN);
        lv_obj_set_style_bg_opa(btn, LV_OPA_TRANSP, LV_PART_MAIN);
        lv_obj_set_style_border_width(btn, 0, LV_PART_MAIN);
        lv_obj_set_style_shadow_width(btn, 0, LV_PART_MAIN);
        lv_obj_set_style_pad_all(btn, 0, LV_PART_MAIN);
        lv_obj_set_user_data(btn, reinterpret_cast<void*>(static_cast<intptr_t>(i + 1)));
        lv_obj_add_flag(btn, LV_OBJ_FLAG_CLICKABLE);
        lv_obj_add_event_cb(btn, RadioUiEvent, LV_EVENT_CLICKED, this);
    }

    // Visible +/- controls, matching the radio's dark enamel and warm amber trim.
    // Minus is on the left, plus on the right. Each tap changes 5%.
    const int volume_x[2] = {32, 274};
    const char* volume_text[2] = {"-", "+"};
    for (int i = 0; i < 2; ++i) {
        const int action = i == 0 ? 4 : 5;
        lv_obj_t* btn = lv_btn_create(radio_ui_root_);
        radio_buttons_[action - 1] = btn;
        lv_obj_set_size(btn, 54, 46);
        lv_obj_set_pos(btn, volume_x[i], 174);
        lv_obj_set_style_radius(btn, 7, LV_PART_MAIN);
        lv_obj_set_style_bg_color(btn, lv_color_make(35, 22, 12), LV_PART_MAIN);
        lv_obj_set_style_bg_opa(btn, LV_OPA_COVER, LV_PART_MAIN);
        lv_obj_set_style_border_color(btn, lv_color_make(205, 139, 48), LV_PART_MAIN);
        lv_obj_set_style_border_width(btn, 2, LV_PART_MAIN);
        lv_obj_set_style_shadow_width(btn, 0, LV_PART_MAIN);
        lv_obj_set_style_pad_all(btn, 0, LV_PART_MAIN);
        lv_obj_set_user_data(btn, reinterpret_cast<void*>(static_cast<intptr_t>(action)));
        lv_obj_add_event_cb(btn, RadioUiEvent, LV_EVENT_CLICKED, this);
        lv_obj_t* label = lv_label_create(btn);
        lv_label_set_text(label, volume_text[i]);
        lv_obj_set_style_text_color(label, lv_color_make(255, 190, 76), LV_PART_MAIN);
        lv_obj_set_style_text_font(label, &lv_font_montserrat_14, LV_PART_MAIN);
        lv_obj_center(label);
    }
    lv_obj_add_flag(radio_ui_root_, LV_OBJ_FLAG_HIDDEN);
}

void TaijiWebRadio::RadioButtonFlashTimerCallback(lv_timer_t* timer) {
    auto* self = static_cast<TaijiWebRadio*>(lv_timer_get_user_data(timer));
    if (!self) return;
    for (int i = 0; i < 5; ++i) {
        auto* btn = self->radio_buttons_[i];
        if (!btn) continue;
        if (i >= 3) {
            lv_obj_set_style_bg_opa(btn, LV_OPA_COVER, LV_PART_MAIN);
            lv_obj_set_style_border_color(btn, lv_color_make(205, 139, 48), LV_PART_MAIN);
            lv_obj_set_style_border_width(btn, 2, LV_PART_MAIN);
        } else {
            lv_obj_set_style_bg_opa(btn, LV_OPA_TRANSP, LV_PART_MAIN);
            lv_obj_set_style_border_width(btn, 0, LV_PART_MAIN);
        }
    }
    // repeat_count=1 makes LVGL retire this one-shot timer after the callback.
    self->radio_button_flash_timer_ = nullptr;
}

void TaijiWebRadio::FlashRadioButton(int action) {
    if (action < 1 || action > 5 || !radio_buttons_[action - 1]) return;
    auto* btn = radio_buttons_[action - 1];
    if (radio_button_flash_timer_) {
        // Reuse the existing one-shot timer instead of deleting/recreating it
        // on rapid taps (avoids timer churn while LVGL is servicing input).
        lv_timer_reset(radio_button_flash_timer_);
        lv_timer_resume(radio_button_flash_timer_);
    }
    for (int i = 0; i < 5; ++i) {
        auto* item = radio_buttons_[i];
        if (!item) continue;
        if (i >= 3) {
            lv_obj_set_style_bg_opa(item, LV_OPA_COVER, LV_PART_MAIN);
            lv_obj_set_style_border_color(item, lv_color_make(205, 139, 48), LV_PART_MAIN);
            lv_obj_set_style_border_width(item, 2, LV_PART_MAIN);
        } else {
            lv_obj_set_style_bg_opa(item, LV_OPA_TRANSP, LV_PART_MAIN);
            lv_obj_set_style_border_width(item, 0, LV_PART_MAIN);
        }
    }
    lv_obj_set_style_bg_opa(btn, LV_OPA_70, LV_PART_MAIN);
    lv_obj_set_style_border_color(btn, lv_color_make(255, 204, 90), LV_PART_MAIN);
    lv_obj_set_style_border_width(btn, 4, LV_PART_MAIN);
    if (!radio_button_flash_timer_) {
        radio_button_flash_timer_ = lv_timer_create(RadioButtonFlashTimerCallback, 150, this);
        lv_timer_set_repeat_count(radio_button_flash_timer_, 1);
    }
}

void TaijiWebRadio::ShowRadioUi(bool show) {
    if (show && music_ui_visible_) ShowMusicUi(false);
    EnsureRadioUi();
    if (!radio_ui_root_) return;
    auto display = Board::GetInstance().GetDisplay();
    if (!display) return;
    {
        DisplayLockGuard lock(display);
        if (!lock) return;
        if (show) {
            UpdateRadioStationLabel();
            lv_obj_clear_flag(radio_ui_root_, LV_OBJ_FLAG_HIDDEN);
            lv_obj_move_foreground(radio_ui_root_);
            radio_ui_visible_ = true;
        } else {
            radio_ui_visible_ = false;
            lv_obj_add_flag(radio_ui_root_, LV_OBJ_FLAG_HIDDEN);
        }
        lv_obj_invalidate(lv_screen_active());
    }
    // Do this after releasing the GUI lock: the display method takes its own lock.
    display->SetRadioLowMotionMode(show);
}

void TaijiWebRadio::UpdateRadioStationLabel() {
    if (radio_volume_label_) {
        char volume_text[8];
        snprintf(volume_text, sizeof(volume_text), "%d%%", radio_.GetVolume());
        lv_label_set_text(radio_volume_label_, volume_text);
        lv_obj_clear_flag(radio_volume_label_, LV_OBJ_FLAG_HIDDEN);
    }
    if (!radio_station_label_) return;
    static const char* display_names[MAX_STATIONS] = {
        "Europa Plus", "Rock Classic", "Casseta Disco", "Rock Ataka",
        "Maximus Rock", "Rock Arsenal", "Nashe Rock", "Melodia"
    };
    const char* name = (current_slot_ >= 0 && current_slot_ < MAX_STATIONS)
        ? display_names[current_slot_] : "Internet Radio";
    lv_label_set_text(radio_station_label_, name);
    lv_obj_clear_flag(radio_station_label_, LV_OBJ_FLAG_HIDDEN);
}

void TaijiWebRadio::RadioUiEvent(lv_event_t* event) {
    auto* self = static_cast<TaijiWebRadio*>(lv_event_get_user_data(event));
    // LVGL 9 provides a typed widget-target accessor. Use it instead of
    // lv_event_get_target(), whose return type is void* in this LVGL build.
    lv_obj_t* target_obj = lv_event_get_target_obj(event);
    if (!self || target_obj == nullptr) return;
    intptr_t action = reinterpret_cast<intptr_t>(lv_obj_get_user_data(target_obj));
    // Some LVGL input paths can report a child label as the target.
    if (action < 1 || action > 5) {
        lv_obj_t* parent = lv_obj_get_parent(target_obj);
        if (parent) action = reinterpret_cast<intptr_t>(lv_obj_get_user_data(parent));
    }
    if (action < 1 || action > 5) {
        return;
    }
    ESP_LOGI(TAG, "Radio touch action=%ld", static_cast<long>(action));
    self->FlashRadioButton(static_cast<int>(action));
    // The board also has a manual CST816S tap path. Share the debounce window
    // so one physical tap cannot be processed once by LVGL and once manually.
    const int64_t now_us = esp_timer_get_time();
    if (now_us - self->last_radio_action_us_ < 450000) return;
    self->last_radio_action_us_ = now_us;
    if (action == 4 || action == 5) {
        const int delta = action == 4 ? -5 : 5;
        self->radio_.SetVolume(self->radio_.GetVolume() + delta);
        self->UpdateRadioStationLabel();
    } else if (action == 1) {
        int start = self->current_slot_;
        for (int n = 1; n <= MAX_STATIONS; ++n) {
            int slot = (start - n + MAX_STATIONS * 2) % MAX_STATIONS;
            if (!self->stations_[slot].url.empty()) { self->StartRadio(slot); break; }
        }
    } else if (action == 2) {
        self->StopRadio();
        Application::GetInstance().ToggleChatState();
    } else if (action == 3) self->NextStation();
}

void TaijiWebRadio::HandleTouchDown(int x, int y) {
    if (music_ui_visible_) {
        const int sx = 359 - x, sy = 359 - y;
        int action = 0;
        if (sy >= 4 && sy <= 72 && sx >= 45 && sx <= 315) action = 6;
        else if (sy >= 225 && sy <= 288) action = (sx >= 20 && sx < 120) ? 1 : ((sx >= 120 && sx < 240) ? 2 : ((sx >= 240 && sx <= 340) ? 3 : 0));
        else if (sy >= 291 && sy <= 344) action = (sx >= 75 && sx < 180) ? 4 : ((sx >= 185 && sx <= 285) ? 5 : 0);
        if (action) {
            auto display = Board::GetInstance().GetDisplay();
            if (display) { DisplayLockGuard lock(display); if (lock) {
                if (action == 6 && music_return_button_) lv_obj_set_style_border_width(music_return_button_, 2, LV_PART_MAIN);
                else if (action >= 1 && action <= 5 && music_buttons_[action - 1]) lv_obj_set_style_border_width(music_buttons_[action - 1], 4, LV_PART_MAIN);
            } }
        }
        return;
    }
    if (!radio_ui_visible_) return;
    const int sx = 359 - x;
    const int sy = 359 - y;
    int action = 0;
    if (sy >= 164 && sy <= 226) {
        if (sx >= 24 && sx <= 92) action = 4;        // volume +
        else if (sx >= 268 && sx <= 338) action = 5; // volume -
    } else if (sy >= 214 && sy <= 326) {
        action = (sx >= 15 && sx < 125) ? 1 :
                 ((sx >= 115 && sx < 225) ? 2 :
                 ((sx >= 215 && sx <= 340) ? 3 : 0));
    }
    if (!action) return;
    auto display = Board::GetInstance().GetDisplay();
    if (!display) return;
    DisplayLockGuard lock(display);
    if (lock) {
            FlashRadioButton(action);
    }
}

bool TaijiWebRadio::HandleTouchTap(int x, int y) {
    if (music_ui_visible_) {
        const int sx = 359 - x, sy = 359 - y;
        int action = 0;
        if (sy >= 4 && sy <= 72 && sx >= 45 && sx <= 315) action = 6;
        else if (sy >= 225 && sy <= 288) action = (sx >= 20 && sx < 120) ? 1 : ((sx >= 120 && sx < 240) ? 2 : ((sx >= 240 && sx <= 340) ? 3 : 0));
        else if (sy >= 291 && sy <= 344) action = (sx >= 75 && sx < 180) ? 4 : ((sx >= 185 && sx <= 285) ? 5 : 0);
        if (action) {
            // The board's manual CST816S handler and LVGL can observe the same
            // physical tap. Use one debounce timestamp so a single tap cannot
            // stop music and immediately retrigger another UI action.
            const int64_t now_us = esp_timer_get_time();
            if (now_us - last_music_action_us_ < 450000) return true;
            last_music_action_us_ = now_us;
            if (action == 6) {
                ESP_LOGI(TAG, "Touch return to assistant: stopping music");
                if (music_player_) music_player_->StopStreaming();
                auto& audio = Application::GetInstance().GetAudioService();
                audio.ResetDecoder();
                for (int wait_ms = 0; wait_ms < 100 && !audio.IsPlaybackIdle(); wait_ms += 5) vTaskDelay(pdMS_TO_TICKS(5));
                CancelSilentStandbyTimer();
                SetAssistantDuck(false);
                ShowMusicUi(false);
                Application::GetInstance().ExitRadioSilentIdle();
                Application::GetInstance().ToggleChatState();
                Application::GetInstance().ResetIdleDisplayTimer();
                UpdateWifiPowerSave();
            } else if (action == 1) MoveMusicHistory(-1);
            else if (action == 3) MoveMusicHistory(1);
            else if (action == 2) {
                if (music_player_ && music_player_->IsPlaying()) {
                    music_player_->StopStreaming();
                    auto& audio = Application::GetInstance().GetAudioService();
                    audio.ResetDecoder();
                    for (int wait_ms = 0; wait_ms < 100 && !audio.IsPlaybackIdle(); wait_ms += 5) vTaskDelay(pdMS_TO_TICKS(5));
                } else if (music_history_index_ >= 0 && music_history_index_ < (int)music_history_.size()) { auto item = music_history_[music_history_index_]; PlayMusicSearch(item.first, item.second, false); }
                UpdateMusicUi();
            } else {
                auto codec = Board::GetInstance().GetAudioCodec();
                if (codec) codec->SetOutputVolume(std::max(0, std::min(100, codec->output_volume() + (action == 4 ? -5 : 5))));
                UpdateMusicUi();
            }
        }
        return true;
    }
    // UI visibility, not decoder state, is authoritative: the stream can be
    // temporarily buffering while the radio screen remains on display.
    if (!radio_ui_visible_) return false;

    // The LCD is mirrored in both axes in config.h, while CST816S reports
    // native sensor coordinates. Convert to the visible 360x360 coordinate space.
    const int sx = 359 - x;
    const int sy = 359 - y;
    // The station-name area remains display-only, except for the two volume keys.
    // Assistant activation is disabled while radio owns the audio path.
    int action = 0;
    if (sy >= 174 && sy <= 220) {
        if (sx >= 36 && sx <= 78) action = 4;        // left: volume -
        else if (sx >= 282 && sx <= 324) action = 5; // right: volume +
        else return true;
    } else if (sy < 220) {
        return true;
    } else if (sy > 320) {
        return true; // ignore the bottom margin of the radio page
    } else if (sx >= 25 && sx < 115) action = 1;       // left: previous
    else if (sx >= 115 && sx < 210) action = 2;        // center: power / return
    else if (sx >= 210 && sx <= 330) action = 3;       // right: next
    if (!action) return true; // outside the three buttons: ignore safely
    auto display = Board::GetInstance().GetDisplay();
    if (display) {
        DisplayLockGuard lock(display);
        if (lock) FlashRadioButton(action);
    }
    // Always show the press, but do not start/stop/reconnect the audio pipeline
    // repeatedly when the user taps several times in quick succession.
    const int64_t now_us = esp_timer_get_time();
    if (now_us - last_radio_action_us_ < 450000) return true;
    last_radio_action_us_ = now_us;
    if (action == 4 || action == 5) {
        const int delta = action == 4 ? -5 : 5;
        radio_.SetVolume(radio_.GetVolume() + delta);
        auto display = Board::GetInstance().GetDisplay();
        if (display) {
            DisplayLockGuard lock(display);
            if (lock) UpdateRadioStationLabel();
        }
        return true;
    }
    if (action == 1) {
        int start = current_slot_;
        for (int n = 1; n <= MAX_STATIONS; ++n) {
            int slot = (start - n + MAX_STATIONS * 2) % MAX_STATIONS;
            if (!stations_[slot].url.empty()) { StartRadio(slot); return true; }
        }
        return true;
    }
    if (action == 2) {
        StopRadio();
        // The radio leaves the assistant in silent idle. Re-enter its normal
        // listening/assistant UI immediately after the user presses power.
        Application::GetInstance().ToggleChatState();
        return true;
    }
    NextStation();
    return true;
}

void TaijiWebRadio::StartRadio(int slot) {
    if (slot < 0 || slot >= MAX_STATIONS || stations_[slot].url.empty()) return;
    // Never stop/join network and audio threads from LVGL touch callbacks or MCP
    // callbacks. Keep only the latest requested station while a switch is in progress.
    pending_station_slot_.store(slot);
    bool expected = false;
    if (station_switch_task_running_.compare_exchange_strong(expected, true)) {
        if (xTaskCreate(&TaijiWebRadio::StationSwitchTask, "radio_switch", 4096, this, 5, nullptr) != pdPASS) {
            station_switch_task_running_.store(false);
            ESP_LOGE(TAG, "Could not create station-switch task; switching synchronously as fallback");
            const int requested = pending_station_slot_.exchange(-1);
            if (requested >= 0) StartRadioNow(requested);
        }
    }
}

void TaijiWebRadio::StationSwitchTask(void* arg) {
    auto* self = static_cast<TaijiWebRadio*>(arg);
    if (!self) { vTaskDelete(nullptr); return; }
    for (;;) {
        const int slot = self->pending_station_slot_.exchange(-1);
        if (slot >= 0) {
            self->StartRadioNow(slot);
            continue;
        }
        self->station_switch_task_running_.store(false);
        // Close the race where a new request arrives just as the worker exits.
        if (self->pending_station_slot_.load() >= 0) {
            bool expected = false;
            if (self->station_switch_task_running_.compare_exchange_strong(expected, true)) continue;
        }
        break;
    }
    vTaskDelete(nullptr);
}

void TaijiWebRadio::StartRadioNow(int slot) {
    if (music_player_ && music_player_->IsPlaying()) music_player_->StopStreaming();
    if (music_ui_visible_) ShowMusicUi(false);
    if (slot < 0 || slot >= MAX_STATIONS || stations_[slot].url.empty()) return;
    // Spotpear-style backend: PlayUrl() serializes lifecycle operations with a
    // control mutex and joins the old download/playback threads before a new
    // stream is started. Station numbers and the web UI remain our own layer.
    if (!radio_.PlayUrl(stations_[slot].url, stations_[slot].name)) {
        ESP_LOGE(TAG, "Failed to start station %d: %s", slot + 1, stations_[slot].url.c_str());
        current_slot_ = -1;
        UpdateWifiPowerSave();
        return;
    }

    current_slot_ = slot;
    ShowRadioUi(true);
    const auto app_state = Application::GetInstance().GetDeviceState();
    const bool voice_session_active = app_state == kDeviceStateListening ||
                                      app_state == kDeviceStateSpeaking ||
                                      app_state == kDeviceStateConnecting;
    CancelSilentStandbyTimer();
    if (voice_session_active) {
        // A station command is part of the current assistant turn: don't reset
        // its state or clear the microphone queue. Keep the stream ducked until
        // the 3-second post-command grace period expires.
        SetAssistantDuck(true);
    } else {
        Application::GetInstance().EnterRadioSilentIdle(false);
    }
    UpdateWifiPowerSave();
}

void TaijiWebRadio::EnterSilentRadioModeNow() {
    // Touch/swipe launch should not open a voice session or stream microphone
    // audio to the assistant. Keep the normal idle/wake-word behavior, but do
    // not wait the 10-second voice-command grace period.
    CancelSilentStandbyTimer();
    Application::GetInstance().EnterRadioSilentIdle();
}

void TaijiWebRadio::SilentStandbyTimerCallback(void* arg) {
    auto* self = static_cast<TaijiWebRadio*>(arg);
    if (!self || !self->IsRadioActive()) {
        return;
    }
    TaijiWebRadio::SetAssistantDuck(false);
    Application::GetInstance().EnterRadioSilentIdle(false);
}

bool TaijiWebRadio::PlayMusicSearch(const std::string& song, const std::string& artist, bool add_history) {
    if (!music_player_ || (song.empty() && artist.empty())) return false;
    // Searching/resolving can take several seconds. Keep Wi-Fi in performance
    // mode throughout that gap too, not only after the MP3 stream starts.
    music_search_active_.store(true);
    UpdateWifiPowerSave();
    StopRadio();
    music_player_->StopStreaming();

    // Flush assistant speech PCM before the MP3 decoder starts writing directly
    // to the codec. Otherwise AudioOutputTask can still output a queued voice
    // frame concurrently with the MP3 task, producing brief interleaving/stutter.
    auto& app = Application::GetInstance();
    auto& audio = app.GetAudioService();
    audio.ResetDecoder();
    for (int wait_ms = 0; wait_ms < 100 && !audio.IsPlaybackIdle(); wait_ms += 5) {
        vTaskDelay(pdMS_TO_TICKS(5));
    }
    // Schedule the silent-idle transition before the blocking search/download,
    // not after MP3 playback has already started.
    app.EnterRadioSilentIdle(false);

    if (!music_player_->Download(song, artist)) {
        music_search_active_.store(false);
        UpdateWifiPowerSave();
        UpdateMusicUi();
        return false;
    }
    if (add_history) {
        if (music_history_index_ + 1 < static_cast<int>(music_history_.size()))
            music_history_.erase(music_history_.begin() + music_history_index_ + 1, music_history_.end());
        music_history_.push_back({music_player_->GetCurrentSong(), music_player_->GetCurrentArtist()});
        music_history_index_ = static_cast<int>(music_history_.size()) - 1;
    }
    ShowRadioUi(false);
    if (!music_ui_visible_) ShowMusicUi(true);
    UpdateMusicUi();
    const auto app_state = Application::GetInstance().GetDeviceState();
    const bool voice_session_active = app_state == kDeviceStateListening ||
                                      app_state == kDeviceStateSpeaking ||
                                      app_state == kDeviceStateConnecting;
    (void)voice_session_active;
    // Stop any queued assistant narration immediately; the song should play silently.
    SetAssistantDuck(false);
    CancelSilentStandbyTimer();
    // Explicitly restore the display and performance mode when entering the player.
    auto& board = Board::GetInstance();
    if (auto display = board.GetDisplay()) display->SetPowerSaveMode(false);
    if (auto backlight = board.GetBacklight()) backlight->RestoreBrightness();
    board.SetPowerSaveLevel(PowerSaveLevel::PERFORMANCE);
    music_search_active_.store(false);
    UpdateWifiPowerSave();
    return true;
}

bool TaijiWebRadio::ConfirmShortSongPlayback() {
    if (!music_player_ || !music_player_->HasPendingShortSong()) return false;
    StopRadio();
    auto& app = Application::GetInstance();
    auto& audio = app.GetAudioService();
    audio.ResetDecoder();
    for (int wait_ms = 0; wait_ms < 100 && !audio.IsPlaybackIdle(); wait_ms += 5) vTaskDelay(pdMS_TO_TICKS(5));
    if (!music_player_->ConfirmPendingShortSong()) return false;
    if (music_history_index_ + 1 < static_cast<int>(music_history_.size()))
        music_history_.erase(music_history_.begin() + music_history_index_ + 1, music_history_.end());
    music_history_.push_back({music_player_->GetCurrentSong(), music_player_->GetCurrentArtist()});
    music_history_index_ = static_cast<int>(music_history_.size()) - 1;
    ShowRadioUi(false);
    ShowMusicUi(true);
    UpdateMusicUi();
    SetAssistantDuck(false);
    CancelSilentStandbyTimer();
    auto& board = Board::GetInstance();
    if (auto display = board.GetDisplay()) display->SetPowerSaveMode(false);
    if (auto backlight = board.GetBacklight()) backlight->RestoreBrightness();
    board.SetPowerSaveLevel(PowerSaveLevel::PERFORMANCE);
    UpdateWifiPowerSave();
    return true;
}

void TaijiWebRadio::MoveMusicHistory(int delta) {
    if (music_history_.empty()) return;
    int next = music_history_index_ + delta;
    if (next < 0 || next >= static_cast<int>(music_history_.size())) return;
    music_history_index_ = next;
    const auto item = music_history_[music_history_index_];
    PlayMusicSearch(item.first, item.second, false);
}

void TaijiWebRadio::EnsureMusicUi() {
    if (music_ui_root_) return;
    auto display = Board::GetInstance().GetDisplay();
    if (!display || !display->SupportsGuiOperations()) return;
    DisplayLockGuard lock(display);
    if (!lock) return;

    music_ui_root_ = lv_obj_create(lv_screen_active());
    lv_obj_set_size(music_ui_root_, 360, 360);
    lv_obj_set_pos(music_ui_root_, 0, 0);
    lv_obj_set_style_radius(music_ui_root_, LV_RADIUS_CIRCLE, LV_PART_MAIN);
    lv_obj_set_style_border_width(music_ui_root_, 0, LV_PART_MAIN);
    lv_obj_set_style_bg_color(music_ui_root_, lv_color_make(8, 15, 19), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(music_ui_root_, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_pad_all(music_ui_root_, 0, LV_PART_MAIN);
    lv_obj_clear_flag(music_ui_root_, LV_OBJ_FLAG_SCROLLABLE);

    // Glossy cyan crystal button: slightly lower than the old heading, with
    // a bright rim, vertical glass gradient and a visible pressed animation.
    music_return_button_ = lv_btn_create(music_ui_root_);
    lv_obj_set_size(music_return_button_, 244, 54);
    lv_obj_align(music_return_button_, LV_ALIGN_TOP_MID, 0, 22);
    lv_obj_set_style_radius(music_return_button_, 17, LV_PART_MAIN);
    lv_obj_set_style_bg_color(music_return_button_, lv_color_make(105, 229, 255), LV_PART_MAIN);
    lv_obj_set_style_bg_grad_color(music_return_button_, lv_color_make(0, 103, 202), LV_PART_MAIN);
    lv_obj_set_style_bg_grad_dir(music_return_button_, LV_GRAD_DIR_VER, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(music_return_button_, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_border_color(music_return_button_, lv_color_make(174, 246, 255), LV_PART_MAIN);
    lv_obj_set_style_border_width(music_return_button_, 2, LV_PART_MAIN);
    lv_obj_set_style_shadow_color(music_return_button_, lv_color_make(0, 185, 255), LV_PART_MAIN);
    lv_obj_set_style_shadow_width(music_return_button_, 18, LV_PART_MAIN);
    lv_obj_set_style_shadow_spread(music_return_button_, 2, LV_PART_MAIN);
    lv_obj_set_style_shadow_opa(music_return_button_, LV_OPA_60, LV_PART_MAIN);
    lv_obj_set_style_bg_color(music_return_button_, lv_color_make(0, 98, 171), LV_STATE_PRESSED);
    lv_obj_set_style_bg_grad_color(music_return_button_, lv_color_make(0, 55, 115), LV_STATE_PRESSED);
    lv_obj_set_style_border_color(music_return_button_, lv_color_make(220, 252, 255), LV_STATE_PRESSED);
    lv_obj_set_style_shadow_width(music_return_button_, 5, LV_STATE_PRESSED);
    lv_obj_set_style_translate_y(music_return_button_, 2, LV_STATE_PRESSED);
    lv_obj_set_user_data(music_return_button_, reinterpret_cast<void*>(static_cast<intptr_t>(6)));
    lv_obj_add_event_cb(music_return_button_, MusicUiEvent, LV_EVENT_CLICKED, this);
    lv_obj_t* return_label = lv_label_create(music_return_button_);
    lv_label_set_text(return_label, "Помощник");
    lv_obj_set_style_text_color(return_label, lv_color_white(), LV_PART_MAIN);
    lv_obj_set_style_text_font(return_label, &lv_font_montserrat_14, LV_PART_MAIN);
    lv_obj_center(return_label);

    music_artist_label_ = lv_label_create(music_ui_root_);
    lv_label_set_text(music_artist_label_, "Исполнитель");
    lv_label_set_long_mode(music_artist_label_, LV_LABEL_LONG_DOT);
    lv_obj_set_width(music_artist_label_, 250);
    lv_obj_set_style_text_align(music_artist_label_, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN);
    lv_obj_set_style_text_color(music_artist_label_, lv_color_make(175, 201, 207), LV_PART_MAIN);
    lv_obj_set_style_text_font(music_artist_label_, &lv_font_montserrat_14, LV_PART_MAIN);
    lv_obj_align(music_artist_label_, LV_ALIGN_TOP_MID, 0, 112);

    music_song_label_ = lv_label_create(music_ui_root_);
    lv_label_set_text(music_song_label_, "Название песни");
    lv_label_set_long_mode(music_song_label_, LV_LABEL_LONG_DOT);
    lv_obj_set_width(music_song_label_, 276);
    lv_obj_set_style_text_align(music_song_label_, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN);
    lv_obj_set_style_text_color(music_song_label_, lv_color_make(255, 222, 166), LV_PART_MAIN);
    lv_obj_set_style_text_font(music_song_label_, &lv_font_montserrat_14, LV_PART_MAIN);
    lv_obj_align(music_song_label_, LV_ALIGN_TOP_MID, 0, 140);

    music_status_label_ = lv_label_create(music_ui_root_);
    lv_label_set_text(music_status_label_, "Ожидание");
    lv_obj_set_style_text_color(music_status_label_, lv_color_make(122, 194, 150), LV_PART_MAIN);
    lv_obj_set_style_text_font(music_status_label_, &lv_font_montserrat_14, LV_PART_MAIN);
    lv_obj_align(music_status_label_, LV_ALIGN_TOP_MID, 0, 171);

    music_volume_label_ = lv_label_create(music_ui_root_);
    lv_label_set_text(music_volume_label_, "Громкость");
    lv_obj_set_style_text_color(music_volume_label_, lv_color_make(255, 190, 76), LV_PART_MAIN);
    lv_obj_set_style_text_font(music_volume_label_, &lv_font_montserrat_14, LV_PART_MAIN);
    lv_obj_align(music_volume_label_, LV_ALIGN_TOP_MID, 0, 198);

    // Five equally sized glass-like controls; volume keys are no longer tiny.
    const int xs[3] = {28, 144, 260};
    const char* labels[3] = {"|<", "STOP", ">|"};
    for (int i = 0; i < 3; ++i) {
        lv_obj_t* btn = lv_btn_create(music_ui_root_);
        music_buttons_[i] = btn;
        lv_obj_set_size(btn, 72, 52);
        lv_obj_set_pos(btn, xs[i], 235);
        lv_obj_set_style_radius(btn, 13, LV_PART_MAIN);
        lv_obj_set_style_bg_color(btn, lv_color_make(54, 103, 126), LV_PART_MAIN);
        lv_obj_set_style_bg_grad_color(btn, lv_color_make(13, 35, 49), LV_PART_MAIN);
        lv_obj_set_style_bg_grad_dir(btn, LV_GRAD_DIR_VER, LV_PART_MAIN);
        lv_obj_set_style_bg_opa(btn, LV_OPA_COVER, LV_PART_MAIN);
        lv_obj_set_style_border_color(btn, lv_color_make(109, 209, 237), LV_PART_MAIN);
        lv_obj_set_style_border_width(btn, 2, LV_PART_MAIN);
        lv_obj_set_style_shadow_color(btn, lv_color_make(0, 0, 0), LV_PART_MAIN);
        lv_obj_set_style_shadow_width(btn, 8, LV_PART_MAIN);
        lv_obj_set_style_shadow_spread(btn, 1, LV_PART_MAIN);
        lv_obj_set_style_shadow_opa(btn, LV_OPA_50, LV_PART_MAIN);
        lv_obj_set_style_bg_color(btn, lv_color_make(22, 151, 192), LV_STATE_PRESSED);
        lv_obj_set_style_bg_grad_color(btn, lv_color_make(4, 73, 104), LV_STATE_PRESSED);
        lv_obj_set_style_border_color(btn, lv_color_make(194, 247, 255), LV_STATE_PRESSED);
        lv_obj_set_style_shadow_width(btn, 2, LV_STATE_PRESSED);
        lv_obj_set_style_translate_y(btn, 2, LV_STATE_PRESSED);
        lv_obj_set_user_data(btn, reinterpret_cast<void*>(static_cast<intptr_t>(i + 1)));
        lv_obj_add_event_cb(btn, MusicUiEvent, LV_EVENT_CLICKED, this);
        lv_obj_t* label = lv_label_create(btn);
        lv_label_set_text(label, labels[i]);
        if (i == 1) music_center_button_label_ = label;
        lv_obj_set_style_text_color(label, lv_color_make(229, 250, 255), LV_PART_MAIN);
        lv_obj_set_style_text_font(label, &lv_font_montserrat_14, LV_PART_MAIN);
        lv_obj_center(label);
    }
    const int vxs[2] = {92, 196};
    const char* vlabels[2] = {"−", "+"};
    for (int i = 0; i < 2; ++i) {
        int action = i == 0 ? 4 : 5;
        lv_obj_t* btn = lv_btn_create(music_ui_root_);
        music_buttons_[action - 1] = btn;
        lv_obj_set_size(btn, 72, 46);
        lv_obj_set_pos(btn, vxs[i], 294);
        lv_obj_set_style_radius(btn, 13, LV_PART_MAIN);
        lv_obj_set_style_bg_color(btn, lv_color_make(54, 103, 126), LV_PART_MAIN);
        lv_obj_set_style_bg_grad_color(btn, lv_color_make(13, 35, 49), LV_PART_MAIN);
        lv_obj_set_style_bg_grad_dir(btn, LV_GRAD_DIR_VER, LV_PART_MAIN);
        lv_obj_set_style_bg_opa(btn, LV_OPA_COVER, LV_PART_MAIN);
        lv_obj_set_style_border_color(btn, lv_color_make(109, 209, 237), LV_PART_MAIN);
        lv_obj_set_style_border_width(btn, 2, LV_PART_MAIN);
        lv_obj_set_style_shadow_color(btn, lv_color_make(0, 0, 0), LV_PART_MAIN);
        lv_obj_set_style_shadow_width(btn, 8, LV_PART_MAIN);
        lv_obj_set_style_shadow_spread(btn, 1, LV_PART_MAIN);
        lv_obj_set_style_shadow_opa(btn, LV_OPA_50, LV_PART_MAIN);
        lv_obj_set_style_bg_color(btn, lv_color_make(22, 151, 192), LV_STATE_PRESSED);
        lv_obj_set_style_bg_grad_color(btn, lv_color_make(4, 73, 104), LV_STATE_PRESSED);
        lv_obj_set_style_border_color(btn, lv_color_make(194, 247, 255), LV_STATE_PRESSED);
        lv_obj_set_style_shadow_width(btn, 2, LV_STATE_PRESSED);
        lv_obj_set_style_translate_y(btn, 2, LV_STATE_PRESSED);
        lv_obj_set_user_data(btn, reinterpret_cast<void*>(static_cast<intptr_t>(action)));
        lv_obj_add_event_cb(btn, MusicUiEvent, LV_EVENT_CLICKED, this);
        lv_obj_t* label = lv_label_create(btn);
        lv_label_set_text(label, vlabels[i]);
        lv_obj_set_style_text_color(label, lv_color_make(229, 250, 255), LV_PART_MAIN);
        lv_obj_set_style_text_font(label, &lv_font_montserrat_14, LV_PART_MAIN);
        lv_obj_center(label);
    }
    lv_obj_add_flag(music_ui_root_, LV_OBJ_FLAG_HIDDEN);
}

void TaijiWebRadio::ShowMusicUi(bool show) {
    if (show && radio_ui_visible_) ShowRadioUi(false);
    EnsureMusicUi();
    if (!music_ui_root_) return;
    auto display = Board::GetInstance().GetDisplay();
    if (!display) return;
    {
        DisplayLockGuard lock(display);
        if (!lock) return;
        if (show) {
            UpdateMusicUiLocked();
            lv_obj_clear_flag(music_ui_root_, LV_OBJ_FLAG_HIDDEN);
            lv_obj_move_foreground(music_ui_root_);
            music_ui_visible_ = true;
        } else {
            lv_obj_add_flag(music_ui_root_, LV_OBJ_FLAG_HIDDEN);
            music_ui_visible_ = false;
        }
        // Force LVGL to repaint after hiding a full-screen root.
        lv_obj_invalidate(lv_screen_active());
    }
    display->SetRadioLowMotionMode(show);
}

void TaijiWebRadio::UpdateMusicUi() {
    if (!music_ui_root_) return;
    auto display = Board::GetInstance().GetDisplay();
    if (!display) return;
    DisplayLockGuard lock(display);
    if (!lock) return;
    UpdateMusicUiLocked();
}

void TaijiWebRadio::UpdateMusicUiLocked() {
    if (!music_ui_root_) return;
    if (music_player_) {
        const std::string artist = music_player_->GetCurrentArtist().empty() ? "Неизвестный исполнитель" : music_player_->GetCurrentArtist();
        const std::string song = music_player_->GetCurrentSong().empty() ? "Попросите включить песню" : music_player_->GetCurrentSong();
        lv_label_set_text(music_artist_label_, artist.c_str());
        lv_label_set_text(music_song_label_, song.c_str());
        const bool playing = music_player_->IsPlaying();
        lv_label_set_text(music_status_label_, playing ? "ВОСПРОИЗВЕДЕНИЕ" : "ОСТАНОВЛЕНО");
        if (music_center_button_label_) lv_label_set_text(music_center_button_label_, playing ? "STOP" : "PLAY");
    }
    auto codec = Board::GetInstance().GetAudioCodec();
    char volume[24];
    snprintf(volume, sizeof(volume), "Громкость %d%%", codec ? codec->output_volume() : 0);
    lv_label_set_text(music_volume_label_, volume);
}

void TaijiWebRadio::MusicUiEvent(lv_event_t* event) {
    auto* self = static_cast<TaijiWebRadio*>(lv_event_get_user_data(event));
    lv_obj_t* target = lv_event_get_target_obj(event);
    if (!self || !target) return;
    intptr_t action = reinterpret_cast<intptr_t>(lv_obj_get_user_data(target));
    if (action < 1 || action > 6) {
        lv_obj_t* parent = lv_obj_get_parent(target);
        if (parent) action = reinterpret_cast<intptr_t>(lv_obj_get_user_data(parent));
    }
    if (action < 1 || action > 6) return;
    // Claim the tap synchronously before dispatching the slow action to a task.
    // This closes the race with the board's parallel CST816S touch handler.
    const int64_t event_now = esp_timer_get_time();
    if (event_now - self->last_music_action_us_ < 450000) return;
    self->last_music_action_us_ = event_now;
    struct Args { TaijiWebRadio* self; int action; };
    auto* args = new (std::nothrow) Args{self, static_cast<int>(action)};
    if (!args) return;
    if (xTaskCreate([](void* raw) {
        auto* a = static_cast<Args*>(raw);
        TaijiWebRadio* s = a->self;
        const int act = a->action;
        delete a;
        if (act == 6) {
                ESP_LOGI(TAG, "Returning from music player to assistant; stopping music");
                if (s->music_player_) s->music_player_->StopStreaming();
                auto& audio = Application::GetInstance().GetAudioService();
                audio.ResetDecoder();
                for (int wait_ms = 0; wait_ms < 100 && !audio.IsPlaybackIdle(); wait_ms += 5) vTaskDelay(pdMS_TO_TICKS(5));
                s->CancelSilentStandbyTimer();
                TaijiWebRadio::SetAssistantDuck(false);
                s->ShowMusicUi(false);
                Application::GetInstance().ExitRadioSilentIdle();
                Application::GetInstance().ToggleChatState();
                Application::GetInstance().ResetIdleDisplayTimer();
                TaijiWebRadio::UpdateWifiPowerSave();
            } else if (act == 1) s->MoveMusicHistory(-1);
            else if (act == 3) s->MoveMusicHistory(1);
            else if (act == 2) {
                if (s->music_player_ && s->music_player_->IsPlaying()) {
                    s->music_player_->StopStreaming();
                    auto& audio = Application::GetInstance().GetAudioService();
                    audio.ResetDecoder();
                    for (int wait_ms = 0; wait_ms < 100 && !audio.IsPlaybackIdle(); wait_ms += 5) vTaskDelay(pdMS_TO_TICKS(5));
                } else if (s->music_history_index_ >= 0 && s->music_history_index_ < (int)s->music_history_.size()) {
                    const auto item = s->music_history_[s->music_history_index_];
                    s->PlayMusicSearch(item.first, item.second, false);
                }
                s->UpdateMusicUi();
            } else {
                auto codec = Board::GetInstance().GetAudioCodec();
                if (codec) codec->SetOutputVolume(std::max(0, std::min(100, codec->output_volume() + (act == 4 ? -5 : 5))));
                s->UpdateMusicUi();
            }
        vTaskDelete(nullptr);
    }, "music_ui_action", 4096, args, 4, nullptr) != pdPASS) delete args;
}

void TaijiWebRadio::StartSilentStandbyTimer() {
    if (!silent_standby_timer_) {
        esp_timer_create_args_t args = {
            .callback = &TaijiWebRadio::SilentStandbyTimerCallback,
            .arg = this,
            .dispatch_method = ESP_TIMER_TASK,
            .name = "radio_silent_idle",
            .skip_unhandled_events = true,
        };
        if (esp_timer_create(&args, &silent_standby_timer_) != ESP_OK) {
            silent_standby_timer_ = nullptr;
            ESP_LOGW(TAG, "Failed to create 10s silent standby timer");
            return;
        }
    }
    esp_timer_stop(silent_standby_timer_);
    esp_timer_start_once(silent_standby_timer_, 10 * 1000 * 1000);
}

void TaijiWebRadio::CancelSilentStandbyTimer() {
    if (silent_standby_timer_) {
        esp_timer_stop(silent_standby_timer_);
    }
}

bool TaijiWebRadio::StopRadio() {
    pending_station_slot_.store(-1);
    CancelSilentStandbyTimer();
    SetAssistantDuck(false);
    const auto state_before_stop = Application::GetInstance().GetDeviceState();
    const bool assistant_was_active = state_before_stop == kDeviceStateListening ||
                                      state_before_stop == kDeviceStateSpeaking ||
                                      state_before_stop == kDeviceStateConnecting;
    const bool active = radio_.IsPlaying() || radio_.IsDownloading();
    if (active) {
        ESP_LOGD(TAG, "Stopping radio");
    }
    const bool stopped = radio_.Stop();
    current_slot_ = -1;
    ShowRadioUi(false);
    // A stop command is often executed as an MCP action inside the active voice
    // turn. Do not tear down that turn; only leave radio-silent-idle when it was
    // already an idle radio-only session.
    if (!assistant_was_active) Application::GetInstance().ExitRadioSilentIdle();
    UpdateWifiPowerSave();
    return stopped;
}

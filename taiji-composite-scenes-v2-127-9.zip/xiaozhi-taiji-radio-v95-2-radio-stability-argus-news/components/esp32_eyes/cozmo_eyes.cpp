#include "cozmo_eyes.h"

#include "Face.h"
#include "eye_fb.h"

#include "esp_heap_caps.h"
#include "esp_random.h"

namespace {

// Each standard XiaoZhi emotion has 2-3 visually related EMO-style eye
// expressions. Selection is O(1), local and allocation-free apart from the
// returned short expression string; no extra LVGL objects or scene layers.
struct EmotionVariants {
    const char* name;
    const char* expressions[3];
    uint8_t count;
};

const EmotionVariants kEmotionVariants[] = {
    {"neutral", {"normal", "unimpressed", "focused"}, 3},
    {"happy", {"happy", "glee", "awe"}, 3},
    {"loving", {"happy", "glee", "awe"}, 3},
    {"delicious", {"happy", "glee", "awe"}, 3},
    {"laughing", {"glee", "happy", "squint"}, 3},
    {"funny", {"glee", "squint", "happy"}, 3},
    {"kissy", {"happy", "squint", "glee"}, 3},
    {"silly", {"glee", "squint", "skeptic"}, 3},
    {"sad", {"sad", "worried", "unimpressed"}, 3},
    {"crying", {"sad", "worried", "scared"}, 3},
    {"angry", {"angry", "annoyed", "furious"}, 3},
    {"embarrassed", {"worried", "squint", "skeptic"}, 3},
    {"surprised", {"surprised", "awe", "scared"}, 3},
    {"shocked", {"surprised", "scared", "awe"}, 3},
    {"thinking", {"focused", "skeptic", "suspicious"}, 3},
    {"confident", {"focused", "unimpressed", "happy"}, 3},
    {"winking", {"squint", "glee", "happy"}, 3},
    {"cool", {"unimpressed", "skeptic", "focused"}, 3},
    {"confused", {"skeptic", "suspicious", "worried"}, 3},
    {"sleepy", {"sleepy", "sad", "unimpressed"}, 3},
    {"normal", {"normal", "focused", "unimpressed"}, 3},
    {"relaxed", {"normal", "happy", "sleepy"}, 3},
    {"scared", {"scared", "worried", "surprised"}, 3},
    {"fearful", {"scared", "worried", "surprised"}, 3},
    {"worried", {"worried", "sad", "scared"}, 3},
    {"annoyed", {"annoyed", "unimpressed", "angry"}, 3},
    {"frustrated", {"frustrated", "angry", "annoyed"}, 3},
    {"suspicious", {"suspicious", "skeptic", "focused"}, 3},
    {"curious", {"awe", "skeptic", "focused"}, 3},
    {"bored", {"unimpressed", "sleepy", "skeptic"}, 3},
    {"disgusted", {"unimpressed", "annoyed", "squint"}, 3},
    {"proud", {"happy", "focused", "unimpressed"}, 3},
    {"relieved", {"happy", "normal", "sleepy"}, 3},
};

const EmotionVariants* FindEmotionVariants(const std::string& emotion) {
    for (const auto& item : kEmotionVariants) {
        if (emotion == item.name) return &item;
    }
    return nullptr;
}

const char* PickExpression(const std::string& emotion, const std::string& previous) {
    const EmotionVariants* variants = FindEmotionVariants(emotion);
    if (variants == nullptr) return "normal";
    uint32_t index = esp_random() % variants->count;
    if (variants->count > 1 && previous == variants->expressions[index]) {
        index = (index + 1 + (esp_random() % (variants->count - 1))) % variants->count;
    }
    return variants->expressions[index];
}

void ApplyExpression(Face* face, const std::string& expression) {
    if (expression == "angry") {
        face->Expression.GoTo_Angry();
    } else if (expression == "glee") {
        face->Expression.GoTo_Glee();
    } else if (expression == "happy") {
        face->Expression.GoTo_Happy();
    } else if (expression == "sad") {
        face->Expression.GoTo_Sad();
    } else if (expression == "worried") {
        face->Expression.GoTo_Worried();
    } else if (expression == "focused") {
        face->Expression.GoTo_Focused();
    } else if (expression == "annoyed") {
        face->Expression.GoTo_Annoyed();
    } else if (expression == "surprised") {
        face->Expression.GoTo_Surprised();
    } else if (expression == "skeptic") {
        face->Expression.GoTo_Skeptic();
    } else if (expression == "frustrated") {
        face->Expression.GoTo_Frustrated();
    } else if (expression == "unimpressed") {
        face->Expression.GoTo_Unimpressed();
    } else if (expression == "sleepy") {
        face->Expression.GoTo_Sleepy();
    } else if (expression == "suspicious") {
        face->Expression.GoTo_Suspicious();
    } else if (expression == "squint") {
        face->Expression.GoTo_Squint();
    } else if (expression == "furious") {
        face->Expression.GoTo_Furious();
    } else if (expression == "scared") {
        face->Expression.GoTo_Scared();
    } else if (expression == "awe") {
        face->Expression.GoTo_Awe();
    } else {
        face->Expression.GoTo_Normal();
    }
}

}  // namespace

CozmoEyes::CozmoEyes(int virtual_w, int virtual_h, int eye_size, int scale) {
    width_ = virtual_w * scale;
    height_ = virtual_h * scale;

    size_t bytes = static_cast<size_t>(width_) * height_ * sizeof(uint16_t);
    fb_ = static_cast<uint16_t*>(heap_caps_malloc(bytes, MALLOC_CAP_SPIRAM));
    if (fb_ == nullptr) {
        fb_ = static_cast<uint16_t*>(malloc(bytes));
    }
    g_fb.Configure(fb_, width_, height_, scale);

    face_ = std::make_unique<Face>(virtual_w, virtual_h, eye_size);
    // Keep the emotion selected by the application instead of switching randomly.
    face_->RandomBehavior = false;
    // Natural autonomous behaviour.
    face_->RandomLook = true;
    face_->RandomBlink = true;
    face_->Expression.GoTo_Normal();
}

CozmoEyes::~CozmoEyes() {
    face_.reset();
    if (fb_ != nullptr) {
        free(fb_);
    }
}

void CozmoEyes::SetColors(uint16_t bg, uint16_t ink) {
    std::lock_guard<std::mutex> lk(mutex_);
    g_fb.bg = bg;
    g_fb.ink = ink;
}

void CozmoEyes::SetEmotion(const std::string& emotion) {
    std::lock_guard<std::mutex> lk(mutex_);
    current_emotion_ = emotion;
    ++request_id_;  // A repeated emotion is a new expressive event too.
}

void CozmoEyes::Update() {
    if (face_ == nullptr || fb_ == nullptr) {
        return;
    }

    // Hold the lock for the whole frame so SetEmotion/SetColors
    // (called from other tasks) never race the render.
    std::lock_guard<std::mutex> lk(mutex_);

    if (request_id_ != applied_request_id_) {
        last_applied_expression_ = PickExpression(current_emotion_, last_applied_expression_);
        ApplyExpression(face_.get(), last_applied_expression_);
        applied_request_id_ = request_id_;
    }

    face_->Update();
}

bool CozmoEyes::IsMapped(const std::string& emotion) {
    return FindEmotionVariants(emotion) != nullptr;
}

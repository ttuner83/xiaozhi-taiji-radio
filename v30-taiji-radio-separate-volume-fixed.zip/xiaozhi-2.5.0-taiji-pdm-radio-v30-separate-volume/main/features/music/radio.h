#ifndef RADIO_H
#define RADIO_H

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

// Common interface for radio/music playback backends.
// The Taiji implementation uses this interface for the web-controlled
// Internet radio player while keeping the player implementation independent
// from the board-specific HTTP server.
class Radio {
public:
    virtual ~Radio() = default;

    virtual bool PlayStation(const std::string& station_name) = 0;
    virtual bool PlayUrl(const std::string& radio_url,
                         const std::string& station_name = "") = 0;
    virtual bool Stop() = 0;

    virtual std::vector<std::string> GetStationList() const = 0;
    virtual bool IsPlaying() const = 0;
    virtual std::string GetCurrentStation() const = 0;
    virtual size_t GetBufferSize() const = 0;
    virtual bool IsDownloading() const = 0;
    virtual int16_t* GetAudioData() = 0;
};

#endif  // RADIO_H

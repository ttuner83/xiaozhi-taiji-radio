#ifndef ESP32_RADIO_H
#define ESP32_RADIO_H

#include <atomic>
#include <condition_variable>
#include <functional>
#include <map>
#include <mutex>
#include <queue>
#include <string>
#include <thread>
#include <vector>

#include "radio.h"

// Internet radio player for XiaoZhi using the ESP Audio simple decoder.
// Supports MP3/AAC/OGG/FLAC streams. Sample rate is converted to the codec
// output sample rate in software.
extern "C" {
#include "esp_audio_simple_dec_default.h"
}

// Audio data chunk structure
struct RadioAudioChunk {
    uint8_t* data;
    size_t size;

    RadioAudioChunk() : data(nullptr), size(0) {}
    RadioAudioChunk(uint8_t* d, size_t s) : data(d), size(s) {}
};

// Radio station information structure
struct RadioStation {
    std::string name;         // Radio station name
    std::string url;          // Streaming URL
    std::string description;  // Description
    std::string genre;        // Genre
    float volume;             // Volume amplification factor (default 1.0 = 100%)

    RadioStation() : volume(1.0f) {}
    RadioStation(const std::string& n, const std::string& u, const std::string& d = "",
                 const std::string& g = "", float v = 1.0f)
        : name(n), url(u), description(d), genre(g), volume(v) {}
};

class Esp32Radio : public Radio {
private:
    std::string current_station_name_;
    std::string current_station_url_;
    bool station_name_displayed_;
    float current_station_volume_;  // Legacy station gain value; retained for station data compatibility
    std::atomic<int> radio_volume_{20}; // Independent radio volume, 0-100%

    // Predefined radio station list
    std::map<std::string, RadioStation> radio_stations_;

    std::atomic<bool> is_playing_;
    std::atomic<bool> is_downloading_;
    std::atomic<bool> music_mode_;  // True when playing music files from the SD card
    // Serializes PlayUrl()/Stop() so thread start/join never races
    std::mutex control_mutex_;
    std::thread play_thread_;
    std::thread download_thread_;

    // Audio buffer
    std::queue<RadioAudioChunk> audio_buffer_;
    std::mutex buffer_mutex_;
    std::condition_variable buffer_cv_;
    size_t buffer_size_;
    static constexpr size_t MAX_BUFFER_SIZE = 256 * 1024;  // 256KB buffer
    static constexpr size_t MIN_BUFFER_SIZE = 32 * 1024;   // 32KB minimum playback buffer

    // Simple decoder for radio streams
    esp_audio_simple_dec_handle_t aac_decoder_;
    esp_audio_simple_dec_cfg_t aac_cfg_;
    esp_audio_simple_dec_info_t aac_info_;
    bool aac_decoder_initialized_;
    bool aac_info_ready_;
    std::vector<uint8_t> aac_out_buffer_;

    // SD card music playlist
    std::vector<std::string> music_playlist_;
    size_t music_track_index_;

    // Announcement (e.g. low battery voice) support. Announce() interrupts the
    // current playback, plays a single audio file, then lets the caller resume.
    std::atomic<size_t> current_file_offset_{0};  // Read position in the active file
    bool announce_mode_ = false;
    std::function<void()> announce_finished_cb_;
    struct MusicResumeState {
        bool valid = false;      // A playback context was saved
        bool live_stream = false;  // true: live radio URL, false: music file
        std::string url;         // Live radio URL to restore
        std::string name;        // Station / track display name
        size_t track_index = 0;  // Music playlist index to restore
        size_t offset = 0;       // Approximate byte offset inside the track
    };
    MusicResumeState music_resume_;

    // Private methods
    void InitializeRadioStations();
    void DownloadRadioStream(const std::string& radio_url);
    void ReadFileStream(const std::string& path, size_t start_offset = 0);
    void PlayRadioStream();
    void ClearAudioBuffer();
    void CleanupAacDecoder();
    void StopLocked();
    // Start reader + playback threads for a local file (SD card).
    void SpawnReaderAndPlayer(const std::string& path, size_t start_offset = 0);
    // Start (or restart) a music playlist track from an approximate offset.
    void StartTrack(size_t track_index, size_t offset);

public:
    Esp32Radio();
    ~Esp32Radio();

    void Initialize();

    // Play a specific station
    virtual bool PlayStation(const std::string& station_name) override;

    // Play a station from a specific URL
    virtual bool PlayUrl(const std::string& radio_url,
                         const std::string& station_name = "") override;

    // Play music from the SD card 'music' folder.
    // track_hint: empty = whole playlist, or a number from GetMusicTracks() / part of a file name.
    bool PlayFile(const std::string& track_hint = "");

    // List music tracks found on the SD card ('<mount_point>/music'), sorted.
    std::vector<std::string> GetMusicTracks() const;

    // True while SD card music is playing.
    bool IsMusicMode() const { return music_mode_; }

    // Stop playback
    virtual bool Stop() override;

    // Interrupt the current playback and play a single announcement file from
    // the SD card (e.g. a low-battery voice phrase). Returns false if the file
    // cannot be played. The previous playback context is saved for
    // ResumeAfterAnnounce(). Call OnAnnounceFinished() to get the end of the
    // phrase (fires on the playback thread when the audio fully drains).
    bool Announce(const std::string& file_path);

    // Resume the playback that was interrupted by Announce(), if any.
    bool ResumeAfterAnnounce();

    // Registers a callback invoked when the announcement finishes playing.
    void OnAnnounceFinished(std::function<void()> callback);

    // True while an announcement phrase is being spoken.
    bool IsAnnouncing() const { return announce_mode_; }

    // Get the list of stations
    virtual std::vector<std::string> GetStationList() const override;

    // Get current playback status
    virtual bool IsPlaying() const override { return is_playing_; }
    virtual std::string GetCurrentStation() const override { return current_station_name_; }

    // Independent radio output volume (0-100%).
    int GetVolume() const;
    void SetVolume(int volume);

    // Buffer status
    virtual size_t GetBufferSize() const override { return buffer_size_; }
    virtual bool IsDownloading() const override { return is_downloading_; }
    virtual int16_t* GetAudioData() override { return nullptr; }
};

#endif  // ESP32_RADIO_H
#include "drone_map.h"

#include "application.h"
#include "board.h"
#include "display/display.h"
#include "mcp_server.h"

#include <cJSON.h>
#include <esp_crt_bundle.h>
#include <esp_log.h>

#include <algorithm>
#include <cmath>
#include <cstring>

#include "generated_tiles.h"

#define TAG "DroneMap"

namespace {
constexpr const char* kWsUrl = "wss://detector-aero.ru/api/pub/v1/stream";
constexpr const char* kWsHeaders =
    "Origin: https://detector-aero.ru\r\n"
    "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36\r\n"
    "Accept: */*\r\n"
    "Accept-Language: ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7\r\n"
    "Cache-Control: no-cache\r\n"
    "Pragma: no-cache\r\n";
constexpr int kSwipeThreshold = 70;
}

DroneMap::DroneMap() {
    RegisterTool();
}

DroneMap::~DroneMap() {
    StopWebSocket();
}

double DroneMap::WorldX(double lon) {
    constexpr int kZoom = 8;
    constexpr int kTileSize = 256;
    const double n = std::pow(2.0, kZoom);
    return (lon + 180.0) / 360.0 * n * kTileSize;
}

double DroneMap::WorldY(double lat) {
    constexpr int kZoom = 8;
    constexpr int kTileSize = 256;
    const double n = std::pow(2.0, kZoom);
    const double r = lat * M_PI / 180.0;
    return (1.0 - std::asinh(std::tan(r)) / M_PI) / 2.0 * n * kTileSize;
}

void DroneMap::EventScreenPosition(const Event& event, int& x, int& y) const {
    const double wx = WorldX(event.lon);
    const double wy = WorldY(event.lat);
    const double size = drone_map_world_size;
    x = static_cast<int>(std::lround((wx - drone_map_world_left) * 360.0 / size));
    y = static_cast<int>(std::lround((wy - drone_map_world_top) * 360.0 / size));
}

void DroneMap::EnsureUi() {
    if (root_) return;

    auto display = Board::GetInstance().GetDisplay();
    if (!display || !display->SupportsGuiOperations()) return;

    DisplayLockGuard lock(display);
    if (!lock) return;

    root_ = lv_obj_create(lv_screen_active());
    lv_obj_set_size(root_, 360, 360);
    lv_obj_set_pos(root_, 0, 0);
    lv_obj_set_style_radius(root_, 0, LV_PART_MAIN);
    lv_obj_set_style_border_width(root_, 0, LV_PART_MAIN);
    lv_obj_set_style_pad_all(root_, 0, LV_PART_MAIN);
    lv_obj_set_style_bg_color(root_, lv_color_black(), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(root_, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_clear_flag(root_, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_add_flag(root_, LV_OBJ_FLAG_HIDDEN);

    // generated_map_png is exactly 360x360, so LVGL displays it 1:1.
    map_image_ = lv_image_create(root_);
    lv_image_set_src(map_image_, &drone_map_image);
    lv_obj_set_size(map_image_, 360, 360);
    lv_obj_set_pos(map_image_, 0, 0);

    markers_layer_ = lv_obj_create(root_);
    lv_obj_set_size(markers_layer_, 360, 360);
    lv_obj_set_pos(markers_layer_, 0, 0);
    lv_obj_set_style_radius(markers_layer_, 0, LV_PART_MAIN);
    lv_obj_set_style_border_width(markers_layer_, 0, LV_PART_MAIN);
    lv_obj_set_style_pad_all(markers_layer_, 0, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(markers_layer_, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_clear_flag(markers_layer_, LV_OBJ_FLAG_SCROLLABLE);
}
void DroneMap::RedrawMarkers() {
    if (!markers_layer_) return;
    auto display = Board::GetInstance().GetDisplay();
    DisplayLockGuard lock(display);
    if (!lock) return;

    lv_obj_clean(markers_layer_);

    struct VisibleEvent { Event e; int x; int y; };
    std::vector<VisibleEvent> items;
    {
        std::lock_guard<std::mutex> guard(events_mutex_);
        for (const auto& kv : events_) {
            if (kv.second.status != "active") continue;
            int x, y;
            EventScreenPosition(kv.second, x, y);
            if (x < -25 || x > 385 || y < -25 || y > 385) continue;
            items.push_back({kv.second, x, y});
        }
    }

    std::vector<bool> used(items.size(), false);
    for (size_t i = 0; i < items.size(); ++i) {
        if (used[i]) continue;
        std::vector<size_t> group;
        group.push_back(i);
        used[i] = true;
        for (size_t j = i + 1; j < items.size(); ++j) {
            if (used[j]) continue;
            const int dx = items[i].x - items[j].x;
            const int dy = items[i].y - items[j].y;
            if (dx * dx + dy * dy <= 8 * 8) {
                group.push_back(j);
                used[j] = true;
            }
        }

        int cx = 0, cy = 0;
        for (auto idx : group) { cx += items[idx].x; cy += items[idx].y; }
        cx /= static_cast<int>(group.size());
        cy /= static_cast<int>(group.size());

        if (group.size() > 1) {
            lv_obj_t* badge = lv_obj_create(markers_layer_);
            lv_obj_set_size(badge, 22, 22);
            lv_obj_set_pos(badge, cx - 11, cy - 11);
            lv_obj_set_style_radius(badge, LV_RADIUS_CIRCLE, LV_PART_MAIN);
            lv_obj_set_style_bg_color(badge, lv_color_black(), LV_PART_MAIN);
            lv_obj_set_style_bg_opa(badge, LV_OPA_90, LV_PART_MAIN);
            lv_obj_set_style_border_width(badge, 2, LV_PART_MAIN);
            lv_obj_set_style_border_color(badge, lv_color_white(), LV_PART_MAIN);
            lv_obj_t* label = lv_label_create(badge);
            lv_label_set_text_fmt(label, "%u", static_cast<unsigned>(group.size()));
            lv_obj_set_style_text_color(label, lv_color_white(), LV_PART_MAIN);
            lv_obj_center(label);
            continue;
        }

        const Event& e = items[i].e;
        if (e.threat_type == "fpv") {
            lv_obj_t* label = lv_label_create(markers_layer_);
            lv_label_set_text(label, "X");
            lv_obj_set_style_text_color(label, lv_color_black(), LV_PART_MAIN);
            lv_obj_set_style_text_font(label, LV_FONT_DEFAULT, LV_PART_MAIN);
            lv_obj_set_style_text_opa(label, LV_OPA_COVER, LV_PART_MAIN);
            lv_obj_set_pos(label, cx - 7, cy - 10);
        } else {
            lv_obj_t* dot = lv_obj_create(markers_layer_);
            lv_obj_set_size(dot, 15, 15);
            lv_obj_set_pos(dot, cx - 7, cy - 7);
            lv_obj_set_style_radius(dot, LV_RADIUS_CIRCLE, LV_PART_MAIN);
            lv_obj_set_style_border_width(dot, 1, LV_PART_MAIN);
            lv_obj_set_style_border_color(dot, lv_color_white(), LV_PART_MAIN);
            lv_obj_set_style_bg_opa(dot, LV_OPA_COVER, LV_PART_MAIN);
            lv_obj_set_style_bg_color(dot,
                e.threat_type == "rocket" ? lv_color_make(255, 130, 0) : lv_color_make(220, 0, 0),
                LV_PART_MAIN);
        }
    }
}

void DroneMap::ApplyEvent(const Event& event) {
    {
        std::lock_guard<std::mutex> guard(events_mutex_);
        if (event.status == "active") events_[event.id] = event;
        else events_.erase(event.id);
    }
    if (visible_) RedrawMarkers();
}

void DroneMap::RemoveEvent(const std::string& id) {
    {
        std::lock_guard<std::mutex> guard(events_mutex_);
        events_.erase(id);
    }
    if (visible_) RedrawMarkers();
}

void DroneMap::HandleWebSocketData(const char* data, size_t len) {
    if (!data || !len) return;
    std::string text(data, len);
    cJSON* root = cJSON_ParseWithLength(text.data(), text.size());
    if (!root) {
        ESP_LOGW(TAG, "Detector-AERO JSON parse failed, len=%u", static_cast<unsigned>(len));
        return;
    }
    cJSON* type = cJSON_GetObjectItemCaseSensitive(root, "type");
    if (!cJSON_IsString(type)) { cJSON_Delete(root); return; }

    const char* t = type->valuestring;
    if (strcmp(t, "event_removed") == 0) {
        cJSON* id = cJSON_GetObjectItemCaseSensitive(root, "id");
        if (cJSON_IsString(id)) RemoveEvent(id->valuestring);
        cJSON_Delete(root);
        return;
    }

    if (strcmp(t, "event_new") == 0 || strcmp(t, "event_update") == 0) {
        cJSON* id = cJSON_GetObjectItemCaseSensitive(root, "id");
        cJSON* lat = cJSON_GetObjectItemCaseSensitive(root, "lat");
        cJSON* lon = cJSON_GetObjectItemCaseSensitive(root, "lon");
        cJSON* threat = cJSON_GetObjectItemCaseSensitive(root, "threat_type");
        cJSON* status = cJSON_GetObjectItemCaseSensitive(root, "status");
        if (cJSON_IsString(id) && cJSON_IsNumber(lat) && cJSON_IsNumber(lon) &&
            cJSON_IsString(threat) && cJSON_IsString(status)) {
            Event e;
            e.id = id->valuestring;
            e.lat = lat->valuedouble;
            e.lon = lon->valuedouble;
            e.threat_type = threat->valuestring;
            e.status = status->valuestring;
            ApplyEvent(e);
        }
    }
    cJSON_Delete(root);
}

void DroneMap::WebSocketEventHandler(void* handler_args, esp_event_base_t, int32_t event_id, void* event_data) {
    auto* self = static_cast<DroneMap*>(handler_args);
    if (!self) return;
    if (event_id == WEBSOCKET_EVENT_DATA) {
        auto* event = static_cast<esp_websocket_event_data_t*>(event_data);
        if (!event) {
            ESP_LOGW(TAG, "WebSocket DATA event without event data");
            return;
        }
        ESP_LOGI(TAG, "WS DATA: opcode=%d len=%d offset=%d total=%d",
                 event->op_code, event->data_len, event->payload_offset, event->payload_len);
        if (event->data_ptr && event->data_len > 0) {
            const size_t preview_len = std::min<size_t>(event->data_len, 180);
            std::string preview(event->data_ptr, preview_len);
            for (char& c : preview) {
                if (c == '\r' || c == '\n' || c == '\t') c = ' ';
                else if (static_cast<unsigned char>(c) < 0x20) c = '.';
            }
            ESP_LOGI(TAG, "WS DATA preview: %s%s", preview.c_str(),
                     event->data_len > preview_len ? "..." : "");
        }

        // esp_websocket_client may split a large WebSocket message into several
        // DATA events. Assemble text/continuation fragments before JSON parsing.
        if ((event->op_code == 1 || event->op_code == 0) && event->data_ptr && event->data_len > 0) {
            if (event->payload_offset == 0) self->ws_message_buffer_.clear();
            self->ws_message_buffer_.append(event->data_ptr, static_cast<size_t>(event->data_len));

            if (event->payload_len <= 0 ||
                self->ws_message_buffer_.size() >= static_cast<size_t>(event->payload_len)) {
                const size_t message_len = event->payload_len > 0
                    ? static_cast<size_t>(event->payload_len)
                    : self->ws_message_buffer_.size();
                self->HandleWebSocketData(self->ws_message_buffer_.data(), message_len);
                self->ws_message_buffer_.clear();
            }
        }
    } else if (event_id == WEBSOCKET_EVENT_CONNECTED) {
        ESP_LOGI(TAG, "Detector-AERO WebSocket CONNECTED");
        ESP_LOGI(TAG, "Detector-AERO stream handshake accepted");
    } else if (event_id == WEBSOCKET_EVENT_DISCONNECTED) {
        ESP_LOGW(TAG, "Detector-AERO WebSocket DISCONNECTED");
    } else if (event_id == WEBSOCKET_EVENT_ERROR) {
        ESP_LOGE(TAG, "Detector-AERO WebSocket ERROR (see esp_websocket/transport log above)");
    } else {
        ESP_LOGI(TAG, "Detector-AERO WebSocket event id=%ld", static_cast<long>(event_id));
    }
}

void DroneMap::StartWebSocket() {
    if (ws_started_) return;
    if (ws_) {
        esp_websocket_client_destroy(ws_);
        ws_ = nullptr;
    }
    esp_websocket_client_config_t cfg = {};
    cfg.uri = kWsUrl;
    cfg.buffer_size = 16384;
    cfg.task_stack = 6144;
    cfg.task_prio = 4;
    cfg.network_timeout_ms = 10000;
    cfg.disable_auto_reconnect = true;
    cfg.crt_bundle_attach = esp_crt_bundle_attach;
    cfg.headers = kWsHeaders;
    ESP_LOGI(TAG, "Detector-AERO WebSocket: %s", kWsUrl);
    ESP_LOGI(TAG, "Detector-AERO Origin: https://detector-aero.ru");
    ESP_LOGI(TAG, "Detector-AERO User-Agent: Chrome/144 Windows");
    ESP_LOGI(TAG, "Detector-AERO WS buffer: %d bytes", 16384);
    ws_ = esp_websocket_client_init(&cfg);
    if (!ws_) {
        ESP_LOGE(TAG, "WebSocket init failed");
        return;
    }
    esp_websocket_register_events(ws_, WEBSOCKET_EVENT_ANY, WebSocketEventHandler, this);
    if (esp_websocket_client_start(ws_) == ESP_OK) {
        ws_started_ = true;
    } else {
        esp_websocket_client_destroy(ws_);
        ws_ = nullptr;
    }
}

void DroneMap::StopWebSocket() {
    if (ws_) {
        if (ws_started_) esp_websocket_client_stop(ws_);
        esp_websocket_client_destroy(ws_);
        ws_ = nullptr;
    }
    ws_started_ = false;
    ws_message_buffer_.clear();
}

bool DroneMap::Show() {
    EnsureUi();
    if (!root_) return false;
    visible_ = true;
    ESP_LOGI(TAG, "Map show: 360x360, center=45.0319,35.3824, world_left=%.3f world_top=%.3f world_size=%.3f",
             drone_map_world_left, drone_map_world_top, drone_map_world_size);
    {
        DisplayLockGuard lock(Board::GetInstance().GetDisplay());
        if (!lock) return false;
        lv_obj_remove_flag(root_, LV_OBJ_FLAG_HIDDEN);
    }
    RedrawMarkers();
    StartWebSocket();
    return true;
}

void DroneMap::Hide() {
    if (!root_) return;
    visible_ = false;
    {
        DisplayLockGuard lock(Board::GetInstance().GetDisplay());
        if (lock) lv_obj_add_flag(root_, LV_OBJ_FLAG_HIDDEN);
    }
    StopWebSocket();
}

bool DroneMap::TouchDown(int x, int y) {
    touch_down_ = true;
    touch_start_x_ = x;
    touch_start_y_ = y;
    return visible_;
}

bool DroneMap::TouchMove(int x, int y) {
    if (!touch_down_ || !visible_) return false;
    return true;
}

bool DroneMap::TouchUp(int x, int y) {
    if (!touch_down_) return false;
    touch_down_ = false;
    const int dx = x - touch_start_x_;
    const int dy = y - touch_start_y_;

    if (!visible_) {
        if (dx < -kSwipeThreshold && std::abs(dx) > std::abs(dy)) {
            Show();
            return true;
        }
        return false;
    }

    if (touch_start_x_ < 80 && dx > kSwipeThreshold && std::abs(dx) > std::abs(dy)) {
        Hide();
        return true;
    }
    return true;
}

void DroneMap::RegisterTool() {
    auto& mcp = McpServer::GetInstance();
    mcp.AddTool("self.drone_map.show",
        "Show the live drone warning map centered on Feodosia. Use for requests such as: 'включи карту дронов', 'покажи карту дронов'.",
        PropertyList(),
        [this](const PropertyList&) -> ReturnValue {
            return Show();
        });
}

#pragma once

#include <map>
#include <mutex>
#include <string>
#include <vector>

#include <esp_websocket_client.h>
#include <lvgl.h>

class DroneMap {
public:
    DroneMap();
    ~DroneMap();

    bool Show();
    void Hide();
    bool IsVisible() const { return visible_; }

    // Returns true when the gesture was consumed by the map UI.
    bool TouchDown(int x, int y);
    bool TouchMove(int x, int y);
    bool TouchUp(int x, int y);

private:
    struct Event {
        std::string id;
        std::string threat_type;
        std::string status;
        double lat = 0;
        double lon = 0;
    };

    lv_obj_t* root_ = nullptr;
    lv_obj_t* map_image_ = nullptr;
    lv_obj_t* markers_layer_ = nullptr;

    std::map<std::string, Event> events_;
    mutable std::mutex events_mutex_;

    esp_websocket_client_handle_t ws_ = nullptr;
    bool ws_started_ = false;
    std::string ws_message_buffer_;
    bool visible_ = false;
    bool touch_down_ = false;
    int touch_start_x_ = 0;
    int touch_start_y_ = 0;

    void EnsureUi();
    void RedrawMarkers();
    void StartWebSocket();
    void StopWebSocket();
    void HandleWebSocketData(const char* data, size_t len);
    void ApplyEvent(const Event& event);
    void RemoveEvent(const std::string& id);
    void RegisterTool();

    static void WebSocketEventHandler(void* handler_args, esp_event_base_t base,
                                      int32_t event_id, void* event_data);

    static double WorldX(double lon);
    static double WorldY(double lat);
    void EventScreenPosition(const Event& event, int& x, int& y) const;
};

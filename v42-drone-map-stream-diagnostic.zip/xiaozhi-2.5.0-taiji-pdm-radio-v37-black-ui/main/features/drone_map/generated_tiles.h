// Placeholder. GitHub Actions replaces this with the fixed OpenTopoMap image.
#pragma once
#include <cstdint>
#include <cstddef>
#include <lvgl.h>

static constexpr double drone_map_world_left = 38746.369351;
static constexpr double drone_map_world_top = 23103.925085;
static constexpr double drone_map_world_size = 925.600000;
static constexpr size_t drone_map_rgb565_size = 360u * 360u * 2u;
static const uint8_t drone_map_rgb565[drone_map_rgb565_size] = {0};

static const lv_image_dsc_t drone_map_image = {
  .header = {
    .magic = LV_IMAGE_HEADER_MAGIC,
    .cf = LV_COLOR_FORMAT_RGB565,
    .flags = 0,
    .w = 360,
    .h = 360,
    .stride = 720,
    .reserved_2 = 0
  },
  .data_size = drone_map_rgb565_size,
  .data = drone_map_rgb565,
  .reserved = nullptr
};

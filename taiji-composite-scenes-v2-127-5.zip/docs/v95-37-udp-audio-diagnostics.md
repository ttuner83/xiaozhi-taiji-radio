# v95-37 UDP audio diagnostics

Adds `AUDIO_DIAG udp_audio_gap=... ms datagram_bytes=...` in the UDP audio receive callback in `main/protocols/mqtt_protocol.cc`.

Although the control protocol is MQTT, incoming audio packets are carried over UDP. The diagnostic measures the interval between received UDP datagrams, which is the relevant network receive path for speech audio. Existing packet sequence warnings remain enabled. Existing `AUDIO_DIAG playback_gap` logging is retained to correlate receive timing with audio output queue activity.

This is diagnostic-only; it does not change task priorities, buffering, or audio playback behavior. Build/device validation has not been performed.

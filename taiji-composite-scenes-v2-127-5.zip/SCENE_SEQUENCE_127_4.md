# Taiji scene composer 127-4 — ordered short scene sequences

Base: `taiji-scene-composer-v3-127-3.zip`

## Changes

- The local scene planner scans the whole recognized Russian transcript for multiple supported actions, sorts matches by their position, and creates up to five sequential scene episodes.
- Supported sequence families include shooting, jar/capture, hammering, sawing, campfire grilling/shashlik, dancing, greeting/waving, jumping, and running.
- Added distinct LVGL compositions for hammering, sawing, and campfire grilling.
- The same planner checks assistant `sentence_start` text if the user's STT transcript did not already trigger a scene. This supports acting out what Cosmo actually says, using the standard XiaoZhi protocol.
- Each episode defaults to 1800 ms; the display clamps scene durations to 1000–3000 ms. The queue is independent of TTS completion.
- Camera zoom-out occurs once at the beginning. The camera remains wide while the next scene replaces the previous one, then zooms back to the same live Cosmo eyes after the final scene.
- Directly negated action cues are filtered in the sequence planner (for example, “не буду стрелять”).

## Validation

- ZIP integrity and source-structure checks are performed when packaging.
- Full ESP-IDF compilation and physical Taiji Pi runtime testing have not been performed in this environment; do not treat this archive as a device-verified firmware build.

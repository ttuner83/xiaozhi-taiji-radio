#ifndef TAIJI_WEB_RADIO_H
#define TAIJI_WEB_RADIO_H

#include <array>
#include <string>
#include <vector>

#include "esp_http_server.h"
#include "sdmmc_cmd.h"
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

class Display;

// Implemented by the Taiji 360x360 display. Kept separate so the radio/player
// module does not depend on the board's concrete display class.
class TaijiRadioDisplayInterface {
public:
    virtual ~TaijiRadioDisplayInterface() = default;
    virtual void ShowRadioPlayer(const char* title, bool music) = 0;
    virtual void UpdateRadioSpectrum(const std::array<uint8_t, 18>& levels) = 0;
    virtual void HideRadioPlayer() = 0;
};

class TaijiWebRadio {
public:
    TaijiWebRadio();
    ~TaijiWebRadio();

    void Start();
    void Stop();

    bool PlaySelected();
    bool NextStation();
    bool StopPlayback();
    bool PlayMusic();
    bool NextMusic();
    bool StopMusic();
    bool IsPlaying() const { return radio_task_ != nullptr; }
    std::string GetCurrentName() const;
    void SetDisplay(Display* display) { display_ = display; }
    void RegisterMcpTools();

private:
    struct Station {
        std::string name;
        std::string url;
        std::string type;
    };

    httpd_handle_t server_ = nullptr;
    std::vector<Station> stations_;
    std::vector<std::string> music_files_;
    TaskHandle_t radio_task_ = nullptr;
    volatile bool radio_stop_ = false;
    int current_slot_ = -1;
    int current_music_ = -1;
    bool music_mode_ = false;
    bool sd_mounted_ = false;
    sdmmc_card_t* sd_card_ = nullptr;
    Display* display_ = nullptr;

    void LoadStations();
    void SaveStation(int slot, const Station& station);
    void ClearStation(int slot);
    void LoadMusicFiles();
    bool MountSdCard();
    void UnmountSdCard();

    static esp_err_t RootHandler(httpd_req_t* req);
    static esp_err_t StationsGetHandler(httpd_req_t* req);
    static esp_err_t StationsPostHandler(httpd_req_t* req);
    static esp_err_t PlayHandler(httpd_req_t* req);
    static esp_err_t StopHandler(httpd_req_t* req);
    static esp_err_t MusicGetHandler(httpd_req_t* req);
    static esp_err_t MusicPlayHandler(httpd_req_t* req);
    static esp_err_t MusicStopHandler(httpd_req_t* req);
    static esp_err_t MusicNextHandler(httpd_req_t* req);

    esp_err_t HandleRoot(httpd_req_t* req);
    esp_err_t HandleStationsGet(httpd_req_t* req);
    esp_err_t HandleStationsPost(httpd_req_t* req);
    esp_err_t HandlePlay(httpd_req_t* req);
    esp_err_t HandleStop(httpd_req_t* req);
    esp_err_t HandleMusicGet(httpd_req_t* req);
    esp_err_t HandleMusicPlay(httpd_req_t* req);
    esp_err_t HandleMusicStop(httpd_req_t* req);
    esp_err_t HandleMusicNext(httpd_req_t* req);

    void StartRadio(int slot);
    void StartMusic(int index);
    void StopRadio();

    static void RadioTaskEntry(void* arg);
    void RadioTask();
    void RadioTaskImpl(const Station& station);
    void MusicTaskImpl(const std::string& path);
    void UpdateSpectrum(const int16_t* samples, size_t count);
    void NotifyOutputActivity();
    void ShowPlayer(const std::string& title, bool music);
    void HidePlayer();

    static TaijiWebRadio* instance_;
};

#endif

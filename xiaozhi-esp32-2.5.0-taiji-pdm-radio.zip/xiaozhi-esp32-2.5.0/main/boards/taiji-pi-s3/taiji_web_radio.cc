#include "taiji_web_radio.h"

#include "application.h"
#include "audio_service.h"
#include "board.h"
#include "display.h"
#include "mcp_server.h"
#include "settings.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <dirent.h>
#include <string>
#include <functional>
#include <cctype>
#include <lvgl.h>

#include <cJSON.h>
#include <esp_audio_dec_default.h>
#include <esp_audio_simple_dec.h>
#include <esp_audio_simple_dec_default.h>
#include <esp_http_client.h>
#include <esp_log.h>
#include <esp_ae_rate_cvt.h>
#include <esp_vfs_fat.h>
#include <sdmmc_cmd.h>
#include <driver/sdmmc_host.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

#define TAG "TaijiWebRadio"
#define MAX_STATIONS 8
#define HTTP_BUF_SIZE 4096
#define PCM_BUF_SIZE 8192
#define RADIO_TASK_STACK 12288
#define SD_MOUNT_POINT "/sdcard"
#define SD_MUSIC_DIR "/sdcard/Music"
#define SD_CLK_GPIO GPIO_NUM_3
#define SD_CMD_GPIO GPIO_NUM_4
#define SD_D0_GPIO GPIO_NUM_2

TaijiWebRadio* TaijiWebRadio::instance_ = nullptr;

static const char kHtml[] = R"HTML(
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Taiji Pi Media</title><style>
body{font-family:Arial,sans-serif;max-width:760px;margin:20px auto;padding:0 12px;background:#f4f4f4;color:#222}h2{margin-bottom:8px}.card{background:#fff;padding:14px;margin:10px 0;border-radius:10px}input,select,button{font-size:16px;padding:9px;margin:4px 0;box-sizing:border-box}input{width:100%}button{cursor:pointer}.row{display:flex;gap:8px;flex-wrap:wrap}.row button{flex:1}small{color:#666;word-break:break-all}.playing{font-weight:bold}
</style></head><body><h2>Taiji Pi S3 — Radio / SD Player</h2>
<div class="card"><b>Радиостанции</b><div id="list">Загрузка...</div></div>
<div class="card"><b>Музыка с TF/SD</b><div id="music">Загрузка...</div><div class="row"><button onclick="musicStop()">Стоп</button><button onclick="musicNext()">Следующая</button></div></div>
<div class="card"><b>Добавить / изменить станцию</b><input id="slot" type="number" min="0" max="7" value="0"><input id="name" placeholder="Название станции"><input id="url" placeholder="http://... или https://..."><select id="type"><option value="mp3">MP3</option><option value="aac">AAC</option><option value="ogg">OGG/Opus</option><option value="wav">WAV</option></select><div class="row"><button onclick="save()">Сохранить</button><button onclick="stop()">Стоп</button></div></div>
<script>
async function load(){let r=await fetch('/api/radios');let a=await r.json();let h='';a.forEach((x,i)=>{if(!x.url)return;h+=`<div class="card"><b>${i}: ${esc(x.name||'Без названия')}</b><br><small>${esc(x.url)} [${esc(x.type||'mp3')}]</small><div class="row"><button onclick="play(${i})">▶ Играть</button><button onclick="edit(${i})">Изменить</button><button onclick="del(${i})">Удалить</button></div></div>`});document.getElementById('list').innerHTML=h||'Станций пока нет';}
async function loadMusic(){let r=await fetch('/api/music');let a=await r.json();let h='';a.forEach((x,i)=>h+=`<div><b>${i}: ${esc(x)}</b> <button onclick="musicPlay(${i})">▶</button></div>`);document.getElementById('music').innerHTML=h||'На карте нет /Music/*.mp3, *.aac, *.ogg, *.wav';}
function esc(s){return String(s).replace(/[&<>\"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;'}[c]))}
async function save(){await fetch('/api/radios',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({slot:+slot.value,name:name.value,url:url.value,type:type.value})});load();}
async function play(i){await fetch('/api/play?slot='+i);load();}
async function stop(){await fetch('/api/stop');}
async function del(i){await fetch('/api/radios',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({slot:i,delete:true})});load();}
async function edit(i){let a=await (await fetch('/api/radios')).json(),x=a[i];slot.value=i;name.value=x.name||'';url.value=x.url||'';type.value=x.type||'mp3';}
async function musicPlay(i){await fetch('/api/music/play?index='+i);loadMusic();}
async function musicStop(){await fetch('/api/music/stop');}
async function musicNext(){await fetch('/api/music/next');loadMusic();}
load();loadMusic();
</script></body></html>)HTML";

static bool ReadBody(httpd_req_t* req, std::string& body) {
    if (req->content_len <= 0 || req->content_len > 4096) return false;
    body.resize(req->content_len);
    size_t received = 0;
    while (received < body.size()) {
        int ret = httpd_req_recv(req, body.data() + received, body.size() - received);
        if (ret <= 0) return false;
        received += ret;
    }
    return true;
}

static bool IsMusicFile(const char* name) {
    if (!name) return false;
    std::string s(name);
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c){ return (char)std::tolower(c); });
    auto has = [&](const char* ext){ size_t n=std::strlen(ext); return s.size()>=n && s.compare(s.size()-n,n,ext)==0; };
    return has(".mp3") || has(".aac") || has(".ogg") || has(".wav");
}

TaijiWebRadio::TaijiWebRadio() {
    instance_ = this;
    LoadStations();
    MountSdCard();
    LoadMusicFiles();
}

TaijiWebRadio::~TaijiWebRadio() {
    Stop();
    UnmountSdCard();
    if (instance_ == this) instance_ = nullptr;
}

void TaijiWebRadio::LoadStations() {
    stations_.clear(); stations_.resize(MAX_STATIONS);
    Settings settings("radio", false);
    for (int i = 0; i < MAX_STATIONS; ++i) {
        std::string value = settings.GetString("r" + std::to_string(i), "");
        if (value.empty()) continue;
        cJSON* obj = cJSON_Parse(value.c_str()); if (!obj) continue;
        auto get = [&](const char* key) -> std::string { cJSON* item=cJSON_GetObjectItemCaseSensitive(obj,key); return cJSON_IsString(item)?item->valuestring:""; };
        stations_[i].name=get("name"); stations_[i].url=get("url"); stations_[i].type=get("type");
        if (stations_[i].type.empty()) stations_[i].type="mp3";
        cJSON_Delete(obj);
    }
    int saved = settings.GetInt("selected", 0);
    if (saved >= 0 && saved < MAX_STATIONS && !stations_[saved].url.empty()) current_slot_ = saved;
}

void TaijiWebRadio::SaveStation(int slot, const Station& station) {
    if (slot < 0 || slot >= MAX_STATIONS) return;
    cJSON* obj=cJSON_CreateObject(); cJSON_AddStringToObject(obj,"name",station.name.c_str()); cJSON_AddStringToObject(obj,"url",station.url.c_str()); cJSON_AddStringToObject(obj,"type",station.type.c_str());
    char* text=cJSON_PrintUnformatted(obj); Settings settings("radio",true); settings.SetString("r"+std::to_string(slot),text?text:""); if(text)cJSON_free(text); cJSON_Delete(obj); stations_[slot]=station;
}

void TaijiWebRadio::ClearStation(int slot) {
    if(slot<0||slot>=MAX_STATIONS)return; Settings settings("radio",true); settings.EraseKey("r"+std::to_string(slot)); stations_[slot]=Station{}; if(current_slot_==slot) current_slot_=-1;
}

bool TaijiWebRadio::MountSdCard() {
    if (sd_mounted_) return true;
    sdmmc_host_t host = SDMMC_HOST_DEFAULT();
    sdmmc_slot_config_t slot = SDMMC_SLOT_CONFIG_DEFAULT();
    slot.width = 1;
    slot.clk = SD_CLK_GPIO;
    slot.cmd = SD_CMD_GPIO;
    slot.d0 = SD_D0_GPIO;
    esp_vfs_fat_sdmmc_mount_config_t mount_cfg = { .format_if_mount_failed=false, .max_files=8, .allocation_unit_size=16*1024 };
    sdmmc_card_t* card=nullptr;
    esp_err_t err=esp_vfs_fat_sdmmc_mount(SD_MOUNT_POINT,&host,&slot,&mount_cfg,&card);
    if(err!=ESP_OK){ ESP_LOGW(TAG,"TF/SD mount failed: %s",esp_err_to_name(err)); return false; }
    sd_card_=card; sd_mounted_=true; ESP_LOGI(TAG,"TF/SD mounted"); return true;
}

void TaijiWebRadio::UnmountSdCard() {
    if(sd_mounted_){ esp_vfs_fat_sdcard_unmount(SD_MOUNT_POINT,sd_card_); sd_card_=nullptr; sd_mounted_=false; }
}

void TaijiWebRadio::LoadMusicFiles() {
    music_files_.clear();
    if(!sd_mounted_) return;
    DIR* dir=opendir(SD_MUSIC_DIR); if(!dir) return;
    while(auto* e=readdir(dir)){ if(e->d_type==DT_REG && IsMusicFile(e->d_name)) music_files_.push_back(std::string(SD_MUSIC_DIR)+"/"+e->d_name); }
    closedir(dir); std::sort(music_files_.begin(),music_files_.end());
}

void TaijiWebRadio::Start() {
    if(server_) return;
    httpd_config_t config=HTTPD_DEFAULT_CONFIG(); config.server_port=80; config.max_uri_handlers=20; config.stack_size=8192;
    if(httpd_start(&server_,&config)!=ESP_OK){server_=nullptr;ESP_LOGE(TAG,"Failed to start HTTP server");return;}
    httpd_uri_t root={.uri="/",.method=HTTP_GET,.handler=RootHandler,.user_ctx=this};
    httpd_uri_t get={.uri="/api/radios",.method=HTTP_GET,.handler=StationsGetHandler,.user_ctx=this};
    httpd_uri_t post={.uri="/api/radios",.method=HTTP_POST,.handler=StationsPostHandler,.user_ctx=this};
    httpd_uri_t play={.uri="/api/play",.method=HTTP_GET,.handler=PlayHandler,.user_ctx=this};
    httpd_uri_t stop={.uri="/api/stop",.method=HTTP_GET,.handler=StopHandler,.user_ctx=this};
    httpd_uri_t music_get={.uri="/api/music",.method=HTTP_GET,.handler=MusicGetHandler,.user_ctx=this};
    httpd_uri_t music_play={.uri="/api/music/play",.method=HTTP_GET,.handler=MusicPlayHandler,.user_ctx=this};
    httpd_uri_t music_stop={.uri="/api/music/stop",.method=HTTP_GET,.handler=MusicStopHandler,.user_ctx=this};
    httpd_uri_t music_next={.uri="/api/music/next",.method=HTTP_GET,.handler=MusicNextHandler,.user_ctx=this};
    httpd_register_uri_handler(server_,&root);httpd_register_uri_handler(server_,&get);httpd_register_uri_handler(server_,&post);httpd_register_uri_handler(server_,&play);httpd_register_uri_handler(server_,&stop);
    httpd_register_uri_handler(server_,&music_get);httpd_register_uri_handler(server_,&music_play);httpd_register_uri_handler(server_,&music_stop);httpd_register_uri_handler(server_,&music_next);
    ESP_LOGI(TAG,"Local radio/player server started");
}

void TaijiWebRadio::Stop() { StopRadio(); if(server_){httpd_stop(server_);server_=nullptr;} }

esp_err_t TaijiWebRadio::RootHandler(httpd_req_t* req){return static_cast<TaijiWebRadio*>(req->user_ctx)->HandleRoot(req);}
esp_err_t TaijiWebRadio::StationsGetHandler(httpd_req_t* req){return static_cast<TaijiWebRadio*>(req->user_ctx)->HandleStationsGet(req);}
esp_err_t TaijiWebRadio::StationsPostHandler(httpd_req_t* req){return static_cast<TaijiWebRadio*>(req->user_ctx)->HandleStationsPost(req);}
esp_err_t TaijiWebRadio::PlayHandler(httpd_req_t* req){return static_cast<TaijiWebRadio*>(req->user_ctx)->HandlePlay(req);}
esp_err_t TaijiWebRadio::StopHandler(httpd_req_t* req){return static_cast<TaijiWebRadio*>(req->user_ctx)->HandleStop(req);}
esp_err_t TaijiWebRadio::MusicGetHandler(httpd_req_t* req){return static_cast<TaijiWebRadio*>(req->user_ctx)->HandleMusicGet(req);}
esp_err_t TaijiWebRadio::MusicPlayHandler(httpd_req_t* req){return static_cast<TaijiWebRadio*>(req->user_ctx)->HandleMusicPlay(req);}
esp_err_t TaijiWebRadio::MusicStopHandler(httpd_req_t* req){return static_cast<TaijiWebRadio*>(req->user_ctx)->HandleMusicStop(req);}
esp_err_t TaijiWebRadio::MusicNextHandler(httpd_req_t* req){return static_cast<TaijiWebRadio*>(req->user_ctx)->HandleMusicNext(req);}

esp_err_t TaijiWebRadio::HandleRoot(httpd_req_t* req){httpd_resp_set_type(req,"text/html; charset=utf-8");return httpd_resp_send(req,kHtml,HTTPD_RESP_USE_STRLEN);}

esp_err_t TaijiWebRadio::HandleStationsGet(httpd_req_t* req){
    cJSON* a=cJSON_CreateArray(); for(int i=0;i<MAX_STATIONS;++i){cJSON* o=cJSON_CreateObject();cJSON_AddNumberToObject(o,"slot",i);cJSON_AddStringToObject(o,"name",stations_[i].name.c_str());cJSON_AddStringToObject(o,"url",stations_[i].url.c_str());cJSON_AddStringToObject(o,"type",stations_[i].type.c_str());cJSON_AddBoolToObject(o,"playing",current_slot_==i&&radio_task_&&!music_mode_);cJSON_AddItemToArray(a,o);} char* t=cJSON_PrintUnformatted(a);cJSON_Delete(a);httpd_resp_set_type(req,"application/json");esp_err_t r=httpd_resp_send(req,t?t:"[]",HTTPD_RESP_USE_STRLEN);if(t)cJSON_free(t);return r;
}

esp_err_t TaijiWebRadio::HandleStationsPost(httpd_req_t* req){
    std::string body;if(!ReadBody(req,body)){httpd_resp_send_err(req,HTTPD_400_BAD_REQUEST,"Invalid body");return ESP_OK;} cJSON* obj=cJSON_Parse(body.c_str());if(!obj){httpd_resp_send_err(req,HTTPD_400_BAD_REQUEST,"Invalid JSON");return ESP_OK;}
    cJSON* slot_item=cJSON_GetObjectItem(obj,"slot");int slot=cJSON_IsNumber(slot_item)?slot_item->valueint:-1;cJSON* del=cJSON_GetObjectItem(obj,"delete");
    if(cJSON_IsTrue(del)){StopRadio();ClearStation(slot);}else{cJSON* name=cJSON_GetObjectItem(obj,"name");cJSON* url=cJSON_GetObjectItem(obj,"url");cJSON* type=cJSON_GetObjectItem(obj,"type");if(slot<0||slot>=MAX_STATIONS||!cJSON_IsString(url)){cJSON_Delete(obj);httpd_resp_send_err(req,HTTPD_400_BAD_REQUEST,"Invalid station");return ESP_OK;}Station st;st.name=cJSON_IsString(name)?name->valuestring:"";st.url=url->valuestring;st.type=cJSON_IsString(type)?type->valuestring:"mp3";SaveStation(slot,st);}cJSON_Delete(obj);return httpd_resp_sendstr(req,"{\"ok\":true}");
}

static int QueryInt(httpd_req_t* req,const char* key,int def){char q[128];if(httpd_req_get_url_query_str(req,q,sizeof(q))!=ESP_OK)return def;char v[32];if(httpd_query_key_value(q,key,v,sizeof(v))!=ESP_OK)return def;return atoi(v);}

esp_err_t TaijiWebRadio::HandlePlay(httpd_req_t* req){int slot=QueryInt(req,"slot",-1);if(slot>=0)StartRadio(slot);else PlaySelected();return httpd_resp_sendstr(req,"{\"ok\":true}");}
esp_err_t TaijiWebRadio::HandleStop(httpd_req_t* req){StopRadio();return httpd_resp_sendstr(req,"{\"ok\":true}");}
esp_err_t TaijiWebRadio::HandleMusicGet(httpd_req_t* req){
    LoadMusicFiles(); cJSON* a=cJSON_CreateArray(); for(const auto& path:music_files_){std::string name=path.substr(path.find_last_of('/')+1);cJSON_AddItemToArray(a,cJSON_CreateString(name.c_str()));} char* t=cJSON_PrintUnformatted(a);cJSON_Delete(a);httpd_resp_set_type(req,"application/json");esp_err_t r=httpd_resp_send(req,t?t:"[]",HTTPD_RESP_USE_STRLEN);if(t)cJSON_free(t);return r;
}
esp_err_t TaijiWebRadio::HandleMusicPlay(httpd_req_t* req){StartMusic(QueryInt(req,"index",0));return httpd_resp_sendstr(req,"{\"ok\":true}");}
esp_err_t TaijiWebRadio::HandleMusicStop(httpd_req_t* req){StopMusic();return httpd_resp_sendstr(req,"{\"ok\":true}");}
esp_err_t TaijiWebRadio::HandleMusicNext(httpd_req_t* req){NextMusic();return httpd_resp_sendstr(req,"{\"ok\":true}");}

void TaijiWebRadio::StartRadio(int slot){
    StopRadio(); if(slot<0||slot>=MAX_STATIONS||stations_[slot].url.empty())return;
    Settings settings("radio",true);settings.SetInt("selected",slot);current_slot_=slot;current_music_=-1;music_mode_=false;
    Application::GetInstance().ResetProtocol();vTaskDelay(pdMS_TO_TICKS(150));radio_stop_=false;ShowPlayer(stations_[slot].name,false);xTaskCreate(RadioTaskEntry,"radio_stream",RADIO_TASK_STACK,this,4,&radio_task_);
}

bool TaijiWebRadio::PlaySelected(){
    if(current_slot_<0||current_slot_>=MAX_STATIONS||stations_[current_slot_].url.empty()){
        for(int i=0;i<MAX_STATIONS;++i)if(!stations_[i].url.empty()){current_slot_=i;break;}
    }
    if(current_slot_<0)return false;StartRadio(current_slot_);return true;
}

bool TaijiWebRadio::NextStation(){
    int start=current_slot_;for(int n=1;n<=MAX_STATIONS;++n){int i=(start+n+MAX_STATIONS)%MAX_STATIONS;if(!stations_[i].url.empty()){StartRadio(i);return true;}}return false;
}

bool TaijiWebRadio::StopPlayback(){StopRadio();return true;}

void TaijiWebRadio::StopRadio(){
    radio_stop_=true;
    if(radio_task_){for(int i=0;i<50&&radio_task_;++i)vTaskDelay(pdMS_TO_TICKS(20));}
    current_slot_ = (current_slot_>=0 && current_slot_<MAX_STATIONS && !stations_[current_slot_].url.empty()) ? current_slot_ : -1;
    music_mode_=false;HidePlayer();
}

void TaijiWebRadio::StartMusic(int index){
    LoadMusicFiles(); if(index<0||index>=(int)music_files_.size())return;StopRadio();music_mode_=true;current_music_=index;radio_stop_=false;ShowPlayer(music_files_[index].substr(music_files_[index].find_last_of('/')+1),true);xTaskCreate(RadioTaskEntry,"sd_music",RADIO_TASK_STACK,this,4,&radio_task_);
}

bool TaijiWebRadio::PlayMusic(){LoadMusicFiles();if(music_files_.empty())return false;StartMusic(current_music_>=0?current_music_:0);return true;}
bool TaijiWebRadio::NextMusic(){LoadMusicFiles();if(music_files_.empty())return false;int i=(current_music_+1)%(int)music_files_.size();StartMusic(i);return true;}
bool TaijiWebRadio::StopMusic(){StopRadio();return true;}

std::string TaijiWebRadio::GetCurrentName() const {
    if(music_mode_ && current_music_>=0 && current_music_<(int)music_files_.size())return music_files_[current_music_].substr(music_files_[current_music_].find_last_of('/')+1);
    if(current_slot_>=0&&current_slot_<MAX_STATIONS)return stations_[current_slot_].name;
    return {};
}

void TaijiWebRadio::RadioTaskEntry(void* arg){auto* self=static_cast<TaijiWebRadio*>(arg);self->RadioTask();self->radio_task_=nullptr;vTaskDelete(nullptr);}

static esp_audio_simple_dec_type_t DecoderType(const std::string& type){if(type=="aac")return ESP_AUDIO_SIMPLE_DEC_TYPE_AAC;if(type=="ogg")return ESP_AUDIO_SIMPLE_DEC_TYPE_OGG;if(type=="wav")return ESP_AUDIO_SIMPLE_DEC_TYPE_WAV;return ESP_AUDIO_SIMPLE_DEC_TYPE_MP3;}

void TaijiWebRadio::NotifyOutputActivity(){
    Application::GetInstance().GetAudioService().NotifyExternalOutputActivity();
}

void TaijiWebRadio::UpdateSpectrum(const int16_t* samples,size_t count){
    static std::array<uint8_t,18> levels{};
    if(!display_||count<32)return;
    // Lightweight band-energy meter. It is intentionally not a full FFT: 18 Goertzel-like
    // frequency probes keep CPU use low enough for the S3 while giving the same animated
    // spectrum effect on the round LCD.
    constexpr int bands=18; constexpr double f0=70.0; constexpr double ratio=1.28; const double fs=24000.0;
    for(int b=0;b<bands;++b){double f=f0*std::pow(ratio,b);if(f>10000)f=10000;double w=2.0*std::cos(2.0*M_PI*f/fs),s1=0,s2=0;size_t n=std::min<size_t>(count,256);for(size_t i=0;i<n;++i){double s=samples[i]/32768.0;double s0=s+w*s1-s2;s2=s1;s1=s0;}double power=s2*s2+s1*s1-w*s1*s2;int v=(int)(std::sqrt(std::max(0.0,power))/n*80.0);levels[b]=(uint8_t)std::clamp(v,2,100);}
    if(auto* d=dynamic_cast<TaijiRadioDisplayInterface*>(display_))d->UpdateRadioSpectrum(levels);
}

void TaijiWebRadio::ShowPlayer(const std::string& title,bool music){if(!display_)display_=Board::GetInstance().GetDisplay();if(auto* d=dynamic_cast<TaijiRadioDisplayInterface*>(display_))d->ShowRadioPlayer(title.c_str(),music);}
void TaijiWebRadio::HidePlayer(){if(auto* d=dynamic_cast<TaijiRadioDisplayInterface*>(display_))d->HideRadioPlayer();}

static bool DecodeAndOutput(TaijiWebRadio* self, const std::string& type, const std::function<int(char*,int)>& reader, AudioCodec* codec, volatile bool* stop_flag){
    esp_audio_dec_register_default();esp_audio_simple_dec_register_default();esp_audio_simple_dec_cfg_t cfg={};cfg.dec_type=DecoderType(type);cfg.use_frame_dec=false;esp_audio_simple_dec_handle_t decoder=nullptr;
    if(esp_audio_simple_dec_open(&cfg,&decoder)!=ESP_AUDIO_ERR_OK||!decoder){esp_audio_simple_dec_unregister_default();esp_audio_dec_unregister_default();return false;}
    std::vector<uint8_t> input(HTTP_BUF_SIZE),pcm(PCM_BUF_SIZE),stream;stream.reserve(HTTP_BUF_SIZE*2);esp_ae_rate_cvt_handle_t resampler=nullptr;int source_rate=0,source_channels=0;uint32_t spectrum_tick=0;
    while(!*stop_flag){int n=reader((char*)input.data(),HTTP_BUF_SIZE);if(n<=0)break;stream.insert(stream.end(),input.begin(),input.begin()+n);size_t consumed_total=0;while(!*stop_flag&&consumed_total<stream.size()){
        esp_audio_simple_dec_raw_t raw={};raw.buffer=stream.data()+consumed_total;raw.len=stream.size()-consumed_total;esp_audio_simple_dec_out_t out={};out.buffer=pcm.data();out.len=PCM_BUF_SIZE;auto dr=esp_audio_simple_dec_process(decoder,&raw,&out);if(dr==ESP_AUDIO_ERR_BUFF_NOT_ENOUGH){*stop_flag=true;break;}if(dr!=ESP_AUDIO_ERR_OK)break;
        if(out.decoded_size){esp_audio_simple_dec_info_t info={};if(esp_audio_simple_dec_get_info(decoder,&info)==ESP_AUDIO_ERR_OK&&info.sample_rate>0&&info.channel>0){int ch=info.channel;if(source_rate!=(int)info.sample_rate||source_channels!=ch){if(resampler){esp_ae_rate_cvt_close(resampler);resampler=nullptr;}source_rate=info.sample_rate;source_channels=ch;if(source_rate!=codec->output_sample_rate()){esp_ae_rate_cvt_cfg_t rcfg={.src_rate=(uint32_t)source_rate,.dest_rate=(uint32_t)codec->output_sample_rate(),.channel=1,.bits_per_sample=ESP_AUDIO_BIT16,.complexity=2,.perf_type=ESP_AE_RATE_CVT_PERF_TYPE_SPEED};esp_ae_rate_cvt_open(&rcfg,&resampler);}}
            int samples=out.decoded_size/sizeof(int16_t)/ch;int16_t* in=(int16_t*)pcm.data();if(ch>1){for(int i=0;i<samples;++i){int32_t sum=0;for(int c=0;c<ch;++c)sum+=in[i*ch+c];int32_t mixed=sum/ch;if(mixed>32767)mixed=32767;if(mixed<-32768)mixed=-32768;in[i]=(int16_t)mixed;}}
            if(resampler){uint32_t max_out=0;esp_ae_rate_cvt_get_max_out_sample_num(resampler,samples,&max_out);std::vector<int16_t> converted(max_out);uint32_t actual=max_out;esp_ae_rate_cvt_process(resampler,(esp_ae_sample_t*)in,samples,(esp_ae_sample_t*)converted.data(),&actual);converted.resize(actual);codec->OutputData(converted);if(self)self->NotifyOutputActivity();if(self)spectrum_tick+=actual; if(self&&spectrum_tick>=2400){self->UpdateSpectrum(converted.data(),converted.size());spectrum_tick=0;}}
            else{std::vector<int16_t> outv(in,in+samples);codec->OutputData(outv);if(self)self->NotifyOutputActivity();if(self)spectrum_tick+=samples;if(self&&spectrum_tick>=2400){self->UpdateSpectrum(outv.data(),outv.size());spectrum_tick=0;}}
        }
        if(raw.consumed==0)break;consumed_total+=raw.consumed;
    }if(consumed_total)stream.erase(stream.begin(),stream.begin()+consumed_total);if(stream.size()>65536)stream.clear();}
    }
    if(resampler)esp_ae_rate_cvt_close(resampler);esp_audio_simple_dec_close(decoder);esp_audio_simple_dec_unregister_default();esp_audio_dec_unregister_default();return true;
}

void TaijiWebRadio::RadioTask(){
    auto codec=Board::GetInstance().GetAudioCodec();if(!codec)return;
    // Keep the microphone alive while media plays so the user can still say
    // "Следующая радиостанция" / "Выключи радио".
    codec->EnableInput(true);
    codec->EnableOutput(true);
    if(music_mode_&&current_music_>=0&&current_music_<(int)music_files_.size())MusicTaskImpl(music_files_[current_music_]);
    else if(current_slot_>=0&&current_slot_<MAX_STATIONS)RadioTaskImpl(stations_[current_slot_]);
    codec->EnableOutput(false);HidePlayer();
}

void TaijiWebRadio::RadioTaskImpl(const Station& station){
    auto codec=Board::GetInstance().GetAudioCodec();if(!codec)return;esp_http_client_config_t cfg={};cfg.url=station.url.c_str();cfg.timeout_ms=10000;cfg.buffer_size=HTTP_BUF_SIZE;cfg.buffer_size_tx=1024;cfg.disable_auto_redirect=false;cfg.max_redirection_count=5;auto client=esp_http_client_init(&cfg);if(!client)return;
    if(esp_http_client_open(client,0)!=ESP_OK)goto cleanup;if(esp_http_client_fetch_headers(client)<0)goto cleanup;if(esp_http_client_get_status_code(client)<200||esp_http_client_get_status_code(client)>=400)goto cleanup;
    DecodeAndOutput(this,station.type,[&](char* b,int n){return esp_http_client_read(client,b,n);},codec,&radio_stop_);
cleanup:esp_http_client_close(client);esp_http_client_cleanup(client);
}

void TaijiWebRadio::MusicTaskImpl(const std::string& path){
    auto codec=Board::GetInstance().GetAudioCodec();if(!codec)return;FILE* f=fopen(path.c_str(),"rb");if(!f)return;std::string ext=path.substr(path.find_last_of('.')+1);std::transform(ext.begin(),ext.end(),ext.begin(),[](unsigned char c){return(char)std::tolower(c);});
    DecodeAndOutput(this,ext,[&](char* b,int n){return (int)fread(b,1,n,f);},codec,&radio_stop_);fclose(f);
}

// MCP voice controls. The LLM sees explicit tool descriptions, so natural Russian
// phrases such as "Включи радио" / "Следующая радиостанция" / "Выключи радио"
// are mapped to these device-side actions.
static void RegisterTaijiMediaTools(TaijiWebRadio* radio){
    auto& mcp=McpServer::GetInstance();
    mcp.AddTool("self.radio.play","Start the selected saved Internet radio station. Use for Russian requests such as: 'Включи радио', 'Запусти радио', 'Включи выбранную радиостанцию'.",PropertyList(),[radio](const PropertyList&)->ReturnValue{return radio->PlaySelected();});
    mcp.AddTool("self.radio.next","Switch to the next configured Internet radio station and start it. Use for Russian requests such as: 'Следующая радиостанция', 'Переключи радио'.",PropertyList(),[radio](const PropertyList&)->ReturnValue{return radio->NextStation();});
    mcp.AddTool("self.radio.stop","Stop Internet radio playback. Use for Russian requests such as: 'Выключи радио', 'Останови радио'.",PropertyList(),[radio](const PropertyList&)->ReturnValue{return radio->StopPlayback();});
    mcp.AddTool("self.music.play","Start music playback from the TF/SD card /Music folder. Use for Russian requests such as: 'Включи музыку', 'Запусти музыку с карты'.",PropertyList(),[radio](const PropertyList&)->ReturnValue{return radio->PlayMusic();});
    mcp.AddTool("self.music.next","Play the next music file from the TF/SD card. Use for Russian requests such as: 'Следующая песня', 'Следующий трек'.",PropertyList(),[radio](const PropertyList&)->ReturnValue{return radio->NextMusic();});
    mcp.AddTool("self.music.stop","Stop TF/SD music playback. Use for Russian requests such as: 'Выключи музыку', 'Останови музыку'.",PropertyList(),[radio](const PropertyList&)->ReturnValue{return radio->StopMusic();});
}

void TaijiWebRadio::RegisterMcpTools(){
    RegisterTaijiMediaTools(this);
}


# Taiji Pi S3 PDM — Radio + SD Music

This build is based on Xiaozhi ESP32 v2.5.0 and keeps the existing `taiji-pi-s3-pdm` microphone/audio board configuration.

## Voice commands

- `Включи радио` — starts the saved/selected station.
- `Следующая радиостанция` — switches to the next configured station.
- `Выключи радио` — stops radio.
- `Включи музыку` — starts the first supported file from TF/SD `/Music`.
- `Следующая песня` — next SD track.
- `Выключи музыку` — stops SD music.

The radio station list remains configurable through the local web page on the device IP address. Up to 8 stations are stored persistently.

## SD music

Create a `Music` directory in the TF/SD card root and put MP3/AAC/OGG/WAV files there.
The current implementation uses the JC3636W518C 1-bit SDMMC wiring: CLK GPIO3, CMD GPIO4, D0 GPIO2.

## Display

When radio or SD music is active, the normal assistant screen is covered by a dedicated circular player screen showing mode, title and an animated 18-band spectrum meter. On stop, the normal Xiaozhi screen returns.

## Audio power keep-alive

Radio and SD playback write decoded PCM directly to `AudioCodec::OutputData()`. Every such PCM frame calls `AudioService::NotifyExternalOutputActivity()`, refreshing the audio output activity timestamp. This prevents the approximately 15-second audio power saver from disabling the amplifier while direct PCM playback is active. After playback stops, normal power saving is restored.

The microphone remains enabled during media playback so the Xiaozhi wake/voice path can still receive commands such as `Следующая радиостанция` and `Выключи радио`.

## Important

Do not change the `taiji-pi-s3-pdm` selection or its PDM microphone configuration. Flash the resulting `build/merged-binary.bin` at address `0x0`.

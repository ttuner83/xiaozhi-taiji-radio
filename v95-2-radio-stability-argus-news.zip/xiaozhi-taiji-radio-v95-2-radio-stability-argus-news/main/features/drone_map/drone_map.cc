#include "drone_map.h"
#include "mcp_server.h"
#include <cJSON.h>
#include <esp_crt_bundle.h>
#include <esp_http_client.h>
#include <esp_heap_caps.h>
#include <esp_log.h>
#include <algorithm>
#include <cctype>
#include <cstring>
#include <ctime>
#include <set>
#include <string>
#include <utility>
#include <vector>

#define TAG "ArgusVoice"

namespace {
constexpr const char* kArgusUrl = "https://argusmap.online/api/live";
constexpr size_t kMaxResponseBytes = 256 * 1024;
struct MapPoint { const char* name; int x; int y; };
// Pixel anchors for map333.png (360x360). Points not labelled on the image are approximate.
constexpr MapPoint kMapPoints[] = {
    {"Армянск",72,111}, {"Красноперекопск",91,137}, {"Джанкой",151,148},
    {"Раздольное",48,155}, {"Раздольном",48,155}, {"Стерегущее",31,151}, {"Стерегущем",31,151},
    {"Гвардейское",116,207}, {"Гвардейском",116,207}, {"Гвардейского",116,207}, {"Гвардейскому",116,207},
    {"Черноморское",22,176}, {"Евпатория",73,201},
    {"Саки",91,207}, {"Саках",91,207}, {"Саков",91,207}, {"Молочное",66,194}, {"Молочном",66,194}, {"Молочного",66,194}, {"Molochne",66,194}, {"Molochnoe",66,194}, {"Simferopol",127,228}, {"Симферополь",127,228}, {"Бахчисарай",95,244},
    {"Севастополь",73,262}, {"Ялта",128,278}, {"Алушта",151,265},
    {"Белогорск",178,222}, {"Старый Крым",207,220}, {"Судак",187,246},
    {"Коктебель",215,226}, {"Феодосия",235,210}, {"Чауда",222,246},
    {"Кировское",204,201}, {"Яркое Поле",213,198}, {"Ярком Поле",213,198}, {"Яркого Поля",213,198}, {"Владиславовка",224,204}, {"Владиславовке",224,204}, {"Владиславовки",224,204}, {"Щёлкино",263,157}, {"Ленино",261,190},
    {"Керчь",294,184}, {"Керченский пролив",319,201}, {"переправ",311,213},
    // Taman peninsula locations are approximate because they sit outside the Crimea artwork.
    {"Темрюк",319,284}, {"Темрюке",319,284}, {"Темрюка",319,284},
    {"Темрюкский район",316,294}, {"Темрюкского района",316,294}, {"Темрюкском районе",316,294},
    {"Temryuk",319,284}, {"Temryuk district",316,294},
    {"Анапа",326,309}, {"Анапе",326,309}, {"Анапу",326,309},
    {"Арабатская стрелка",179,127}, {"Арабатской стрелки",179,127}, {"Сиваш",120,105},
    {"Азовское море",211,80}, {"Азовское море",278,72}, {"Азовское море",337,85},
    // Northern Sea of Azov and adjacent coast, included in spoken reports too.
    {"Геническ",177,69}, {"Геническе",177,69}, {"Геническа",177,69},
    {"Кирилловка",218,55}, {"Кирилловке",218,55}, {"Кирилловки",218,55},
    {"Мелитополь",204,48}, {"Мелитополе",204,48}, {"Мелитополя",204,48},
    {"Бердянск",246,40}, {"Бердянске",246,40}, {"Бердянска",246,40},
    {"Приморск",235,48}, {"Приморске",235,48}, {"Приморска",235,48},
    {"Мариуполь",284,29}, {"Мариуполе",284,29}, {"Мариуполя",284,29},
    {"Новоазовск",316,31}, {"Новоазовске",316,31}, {"Новоазовска",316,31},
    {"Ейск",329,52}, {"Ейске",329,52}, {"Ейска",329,52},
    {"Приморско-Ахтарск",337,66}, {"Приморско-Ахтарске",337,66},
    {"Таганрог",342,34}, {"Таганроге",342,34}, {"Ростов-на-Дону",337,13}, {"Ростове-на-Дону",337,13},
    {"Henichesk",177,69}, {"Kyrylivka",218,55}, {"Melitopol",204,48},
    {"Berdiansk",246,40}, {"Mariupol",284,29}, {"Novoazovsk",316,31}, {"Yeysk",329,52},
    {"Тарханкут",20,190}, {"Ленинский район",254,214}, {"Феодосийский залив",247,196},
    {"порт",239,207}, {"Портовое",39,164}, {"Портовом",39,164},
    {"Armyansk",72,111}, {"Krasnoperekopsk",91,137}, {"Dzhankoy",151,148},
    {"Steregushchee",31,151}, {"Portovoe",39,164}, {"Gvardeyskoye",116,207},
    {"Razdolnoe",48,155}, {"Chornomorske",22,176}, {"Yevpatoriya",73,201},
    {"Saki",91,207}, {"Simferopol",127,228}, {"Bakhchisarai",95,244},
    {"Sevastopol",73,262}, {"Yalta",128,278}, {"Alushta",151,265},
    {"Belogorsk",178,222}, {"Stary Krym",207,220}, {"Sudak",187,246},
    {"Koktebel",215,226}, {"Feodosia",235,210}, {"Chauda",222,246},
    {"Kirovsky",204,201}, {"Kirovske",204,201}, {"Shcholkine",263,157},
    {"Lenino",261,190}, {"Kerch",294,184}, {"Kerch Strait",319,201},
    {"ferry",311,213}, {"Arabat Spit",179,127}, {"Sivash",120,105},
    {"Azov Sea",278,72}, {"Tarkhankut",20,190}, {"Leninsky",254,214},
    {"Feodosia port",239,207}, {"port of Feodosia",239,207}
};

std::string LowerUtf8(std::string value) {
    std::string out;
    out.reserve(value.size());
    for (size_t i = 0; i < value.size();) {
        const unsigned char c = static_cast<unsigned char>(value[i]);
        if (c < 0x80) {
            out.push_back(static_cast<char>(std::tolower(c)));
            ++i;
        } else if (i + 1 < value.size() && c == 0xD0) {
            const unsigned char d = static_cast<unsigned char>(value[i + 1]);
            if (d >= 0x90 && d <= 0x9F) { out.push_back(static_cast<char>(0xD0)); out.push_back(static_cast<char>(d + 0x20)); }
            else if (d >= 0xA0 && d <= 0xAF) { out.push_back(static_cast<char>(0xD1)); out.push_back(static_cast<char>(d - 0x20)); }
            else if (d == 0x81) { out.push_back(static_cast<char>(0xD1)); out.push_back(static_cast<char>(0x91)); }
            else { out.push_back(value[i]); out.push_back(value[i + 1]); }
            i += 2;
        } else {
            out.push_back(value[i++]);
        }
    }
    return out;
}

bool ContainsNoCase(const std::string& text, const char* phrase) {
    if (!phrase || !*phrase) return false;
    return LowerUtf8(text).find(LowerUtf8(phrase)) != std::string::npos;
}

// Reduce Russian words to a conservative stem so that city names match common
// grammatical cases (e.g. Feodosia/Feodosii, Kerch/Kerchi, Arabatskoy strelki).
// This is intentionally token-based: it does not match arbitrary substrings.
std::string RussianStem(std::string word) {
    static const char* suffixes[] = {
        "иями", "ями", "ами", "иями", "иями", "ского", "цкого", "ному", "нему",
        "ыми", "ими", "ого", "его", "ому", "ему", "ией", "ией", "иях", "иях",
        "иям", "ием", "ией", "ская", "цкая", "ской", "цкой", "ские", "цкие",
        "иями", "ями", "ами", "ией", "ия", "ии", "ие", "ей", "ой", "ый", "ий",
        "ая", "яя", "ое", "ее", "ом", "ем", "ам", "ям", "ах", "ях", "ы", "и",
        "а", "я", "ь", "й", "е", "у", "ю"
    };
    for (const char* suffix : suffixes) {
        const size_t n = strlen(suffix);
        if (word.size() > n + 2 && word.compare(word.size() - n, n, suffix) == 0) {
            word.resize(word.size() - n);
            break;
        }
    }
    return word;
}

struct WordToken { std::string word; size_t pos; };
std::vector<WordToken> TokenizeWords(const std::string& text) {
    std::vector<WordToken> out;
    size_t i = 0;
    while (i < text.size()) {
        const unsigned char c = static_cast<unsigned char>(text[i]);
        const bool word_char = (c >= 128) || std::isalnum(c);
        if (!word_char) { ++i; continue; }
        const size_t start = i;
        while (i < text.size()) {
            const unsigned char d = static_cast<unsigned char>(text[i]);
            if (!(d >= 128 || std::isalnum(d))) break;
            ++i;
        }
        out.push_back({text.substr(start, i - start), start});
    }
    return out;
}

size_t FindLocationPosition(const std::string& lowered_text, const char* raw_name) {
    if (!raw_name || !*raw_name) return std::string::npos;
    const std::string lowered_name = LowerUtf8(raw_name);
    // Latin transliterations are matched as complete phrases, case-insensitively.
    bool has_cyrillic = false;
    for (unsigned char c : lowered_name) if (c >= 0xD0) { has_cyrillic = true; break; }
    if (!has_cyrillic) return lowered_text.find(lowered_name);

    const auto text_words = TokenizeWords(lowered_text);
    const auto name_words = TokenizeWords(lowered_name);
    if (name_words.empty()) return std::string::npos;
    std::vector<std::string> roots;
    roots.reserve(name_words.size());
    for (const auto& word : name_words) roots.push_back(RussianStem(word.word));

    size_t best = std::string::npos;
    for (size_t i = 0; i < text_words.size(); ++i) {
        if (RussianStem(text_words[i].word) != roots[0]) continue;
        size_t cursor = i + 1;
        bool matched = true;
        for (size_t n = 1; n < roots.size(); ++n) {
            // Multi-word place names may have a short connective word between parts.
            size_t found = cursor;
            while (found < text_words.size() && found - cursor <= 2 && RussianStem(text_words[found].word) != roots[n]) ++found;
            if (found >= text_words.size() || found - cursor > 2) { matched = false; break; }
            cursor = found + 1;
        }
        if (matched && (best == std::string::npos || text_words[i].pos < best)) best = text_words[i].pos;
    }
    return best;
}

void AppendJsonStrings(const cJSON* item, std::string& out) {
    if (!item) return;
    if (cJSON_IsString(item) && item->valuestring) {
        if (!out.empty()) out.push_back(' ');
        out += item->valuestring;
        return;
    }
    if (cJSON_IsArray(item) || cJSON_IsObject(item)) {
        for (const cJSON* child = item->child; child; child = child->next) AppendJsonStrings(child, out);
    }
}

struct ResponseBuffer { char* data = nullptr; size_t size = 0; size_t capacity = 0; bool overflow = false; };
esp_err_t HttpEventHandler(esp_http_client_event_t* evt) {
    if (evt && evt->event_id == HTTP_EVENT_ON_DATA && evt->user_data && evt->data && evt->data_len > 0) {
        auto* r = static_cast<ResponseBuffer*>(evt->user_data);
        const size_t n = static_cast<size_t>(evt->data_len);
        if (r->data && r->size + n < r->capacity) { memcpy(r->data + r->size, evt->data, n); r->size += n; r->data[r->size] = '\0'; }
        else r->overflow = true;
    }
    return ESP_OK;
}

// Voice queries cover the full map region: Crimea, Anapa, Temryuk, the Sea of Azov
// and its northern shore. Every map alias is allowed; duplicate aliases are collapsed
// by coordinates when possible and by canonical name in the spoken result.
bool IsCrimeaPoint(const MapPoint& p) {
    (void)p;
    return true;
}

std::string CanonicalName(const MapPoint& p) {
    // Prefer Russian names in the spoken response; map aliases share coordinates.
    for (const auto& c : kMapPoints) {
        if (c.x != p.x || c.y != p.y) continue;
        bool ascii = true;
        for (const unsigned char* q = reinterpret_cast<const unsigned char*>(c.name); *q; ++q) if (*q >= 0x80) { ascii = false; break; }
        if (!ascii && IsCrimeaPoint(c)) return c.name;
    }
    return p.name;
}

std::string QueryArgusLocations() {
    ResponseBuffer r; r.capacity = kMaxResponseBytes;
    r.data = static_cast<char*>(heap_caps_malloc(r.capacity, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
    if (!r.data) return "Не удалось проверить данные Argus: недостаточно памяти.";
    r.data[0] = '\0';
    esp_http_client_config_t cfg = {};
    cfg.url = kArgusUrl; cfg.timeout_ms = 3500; cfg.crt_bundle_attach = esp_crt_bundle_attach;
    cfg.event_handler = HttpEventHandler; cfg.user_data = &r; cfg.buffer_size = 4096; cfg.buffer_size_tx = 1024;
    auto client = esp_http_client_init(&cfg);
    if (!client) { heap_caps_free(r.data); return "Не удалось подключиться к данным Argus."; }
    esp_http_client_set_method(client, HTTP_METHOD_GET);
    esp_http_client_set_header(client, "Accept", "application/json");
    esp_http_client_set_header(client, "User-Agent", "TaijiPi-ESP32/2.5.0");
    const esp_err_t err = esp_http_client_perform(client);
    const int status = esp_http_client_get_status_code(client);
    esp_http_client_cleanup(client);
    if (err != ESP_OK || status != 200 || r.size == 0 || r.overflow) {
        ESP_LOGW(TAG, "Argus request failed: %s status=%d bytes=%u overflow=%d", esp_err_to_name(err), status, (unsigned)r.size, r.overflow);
        heap_caps_free(r.data); return "Сейчас не удалось получить данные Argus. Попробуй повторить запрос позже.";
    }

    std::set<std::string> locations;
    int accepted = 0;
    std::vector<const char*> starts; bool in_string = false, escaped = false;
    for (const char* q = r.data; *q; ++q) {
        if (in_string) { if (escaped) escaped = false; else if (*q == '\\') escaped = true; else if (*q == '"') in_string = false; continue; }
        if (*q == '"') in_string = true;
        else if (*q == '{') starts.push_back(q);
        else if (*q == '}' && !starts.empty()) {
            const char* start = starts.back(); starts.pop_back();
            size_t len = (size_t)(q - start + 1); if (len < 40 || len > 65536) continue;
            std::string raw(start, len);
            if (raw.find("\"label\"") == std::string::npos) continue;
            if (raw.find("\"status\"") == std::string::npos && raw.find("\"type\"") == std::string::npos && raw.find("\"threatCategory\"") == std::string::npos && raw.find("\"threatType\"") == std::string::npos) continue;
            cJSON* item = cJSON_ParseWithLength(start, len); if (!item) continue;
            cJSON* label = cJSON_GetObjectItemCaseSensitive(item, "label");
            cJSON* status_item = cJSON_GetObjectItemCaseSensitive(item, "status");
            cJSON* type_item = cJSON_GetObjectItemCaseSensitive(item, "type");
            cJSON* expiry = cJSON_GetObjectItemCaseSensitive(item, "expiresAt");
            const bool regional = cJSON_IsString(status_item) && status_item->valuestring && strcmp(status_item->valuestring, "air_alert") == 0;
            const bool point_event = cJSON_IsString(type_item) && type_item->valuestring && (strcmp(type_item->valuestring, "point") == 0 || strcmp(type_item->valuestring, "event") == 0);
            const cJSON* threat_category = cJSON_GetObjectItemCaseSensitive(item, "threatCategory");
            const cJSON* threat_type = cJSON_GetObjectItemCaseSensitive(item, "threatType");
            const bool typed_threat = (threat_category != nullptr) || (threat_type != nullptr);
            if (!cJSON_IsString(label) || !label->valuestring || (!regional && !point_event && !typed_threat)) { cJSON_Delete(item); continue; }
            if (cJSON_IsString(status_item) && status_item->valuestring) {
                const std::string status = LowerUtf8(status_item->valuestring);
                if (status == "resolved" || status == "ended" || status == "inactive" || status == "cancelled" || status == "canceled" || status == "expired") { cJSON_Delete(item); continue; }
            }
            if (cJSON_IsString(expiry) && expiry->valuestring && strlen(expiry->valuestring) >= 20) {
                time_t now = time(nullptr);
                if (now > 1700000000) { struct tm utc = {}; gmtime_r(&now, &utc); char iso[24] = {}; strftime(iso, sizeof(iso), "%Y-%m-%dT%H:%M:%SZ", &utc); if (strncmp(expiry->valuestring, iso, 19) <= 0) { cJSON_Delete(item); continue; } }
            }
            ++accepted;
            std::string text; AppendJsonStrings(item, text); const std::string lowered = LowerUtf8(text);
            std::vector<std::pair<size_t, const MapPoint*>> matches;
            for (const auto& p : kMapPoints) {
                if (!IsCrimeaPoint(p)) continue;
                size_t pos = FindLocationPosition(lowered, p.name);
                if (pos != std::string::npos) matches.push_back({pos, &p});
            }
            std::sort(matches.begin(), matches.end(), [](const auto& a, const auto& b) { if (a.first != b.first) return a.first < b.first; return strlen(a.second->name) > strlen(b.second->name); });
            std::set<std::pair<int,int>> seen_xy;
            for (const auto& m : matches) if (seen_xy.insert({m.second->x, m.second->y}).second) locations.insert(CanonicalName(*m.second));
            cJSON* point_array = cJSON_GetObjectItemCaseSensitive(item, "points");
            if (cJSON_IsArray(point_array)) {
                for (cJSON* pt = point_array->child; pt; pt = pt->next) {
                    cJSON* lat = cJSON_GetObjectItemCaseSensitive(pt, "lat");
                    cJSON* lng = cJSON_GetObjectItemCaseSensitive(pt, "lng");
                    if (!cJSON_IsNumber(lat) || !cJSON_IsNumber(lng) || lat->valuedouble < 44.3 || lat->valuedouble > 46.0 || lng->valuedouble < 32.0 || lng->valuedouble > 36.9) continue;
                    const int x = 204 + static_cast<int>((lng->valuedouble - 35.2) * 48.0);
                    const int y = 201 - static_cast<int>((lat->valuedouble - 45.2) * 65.0);
                    const MapPoint* nearest = nullptr; int best = 24 * 24;
                    for (const auto& p : kMapPoints) {
                        if (!IsCrimeaPoint(p)) continue;
                        const int dx = p.x - x, dy = p.y - y, d = dx * dx + dy * dy;
                        if (d < best) { best = d; nearest = &p; }
                    }
                    if (nearest) locations.insert(CanonicalName(*nearest));
                }
            }
            const bool crimea = ContainsNoCase(text, "Crimea") || ContainsNoCase(text, "Крым");
            const bool azov = ContainsNoCase(text, "Азов") || ContainsNoCase(text, "Azov");
            const bool anapa = ContainsNoCase(text, "Анап") || ContainsNoCase(text, "Anapa");
            const bool temryuk = ContainsNoCase(text, "Темрюк") || ContainsNoCase(text, "Temryuk");
            if (regional && matches.empty()) {
                if (azov) locations.insert("Азовское море");
                else if (anapa) locations.insert("Анапа");
                else if (temryuk) locations.insert("Темрюк");
                else if (crimea) locations.insert("Симферополь");
            }
            cJSON_Delete(item);
        }
    }
    ESP_LOGI(TAG, "One-shot Argus query accepted=%d regional locations=%u", accepted, (unsigned)locations.size());
    heap_caps_free(r.data);
    if (locations.empty()) return accepted == 0 ? "Небо чистое." : "Argus передаёт активные события, но не удалось определить их локации в пределах карты.";
    std::string answer = "По данным Argus, активные локации в пределах карты Крыма и Азовского региона: ";
    bool first = true; for (const auto& name : locations) { if (!first) answer += ", "; answer += name; first = false; }
    answer += "."; return answer;
}
std::string XmlDecodeAndStrip(std::string value) {
    const std::pair<const char*, const char*> entities[] = {
        {"&amp;", "&"}, {"&lt;", "<"}, {"&gt;", ">"}, {"&quot;", "\""}, {"&apos;", "'"}, {"&#39;", "'"}, {"&nbsp;", " "}
    };
    for (const auto& e : entities) {
        size_t pos = 0;
        while ((pos = value.find(e.first, pos)) != std::string::npos) { value.replace(pos, strlen(e.first), e.second); pos += strlen(e.second); }
    }
    std::string out; bool tag = false;
    for (char c : value) {
        if (c == '<') { tag = true; continue; }
        if (c == '>') { tag = false; continue; }
        if (!tag) out.push_back(c);
    }
    // Collapse whitespace to keep spoken output compact.
    std::string clean; bool space = false;
    for (unsigned char c : out) {
        if (std::isspace(c)) { space = !clean.empty(); continue; }
        if (space) clean.push_back(' ');
        clean.push_back(static_cast<char>(c)); space = false;
    }
    return clean;
}

std::string ExtractXmlTag(const std::string& item, const char* tag) {
    const std::string open = std::string("<") + tag + ">";
    const std::string close = std::string("</") + tag + ">";
    size_t a = item.find(open);
    if (a == std::string::npos) {
        // RSS feeds sometimes add attributes to the tag.
        a = item.find(std::string("<") + tag);
        if (a == std::string::npos) return {};
        a = item.find('>', a);
        if (a == std::string::npos) return {};
        ++a;
    } else a += open.size();
    size_t b = item.find(close, a);
    if (b == std::string::npos) return {};
    std::string value = item.substr(a, b - a);
    const size_t cdata = value.find("<![CDATA[");
    if (cdata != std::string::npos) {
        const size_t end = value.find("]]>", cdata + 9);
        if (end != std::string::npos) value = value.substr(cdata + 9, end - (cdata + 9));
    }
    return XmlDecodeAndStrip(value);
}

std::string QueryYandexMainNews() {
    ResponseBuffer r; r.capacity = 96 * 1024;
    r.data = static_cast<char*>(heap_caps_malloc(r.capacity, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
    if (!r.data) return "Не удалось загрузить новости: недостаточно памяти.";
    r.data[0] = '\0';
    esp_http_client_config_t cfg = {};
    cfg.url = "https://news.yandex.ru/index.rss";
    cfg.timeout_ms = 5000;
    cfg.crt_bundle_attach = esp_crt_bundle_attach;
    cfg.event_handler = HttpEventHandler; cfg.user_data = &r;
    cfg.buffer_size = 4096; cfg.buffer_size_tx = 1024;
    auto client = esp_http_client_init(&cfg);
    if (!client) { heap_caps_free(r.data); return "Не удалось подключиться к RSS-ленте новостей."; }
    esp_http_client_set_method(client, HTTP_METHOD_GET);
    esp_http_client_set_header(client, "User-Agent", "TaijiPi-News/1.0");
    esp_http_client_set_header(client, "Accept", "application/rss+xml, application/xml, text/xml");
    const esp_err_t err = esp_http_client_perform(client);
    const int status = esp_http_client_get_status_code(client);
    esp_http_client_cleanup(client);
    if (err != ESP_OK || status != 200 || r.size == 0 || r.overflow) {
        ESP_LOGW(TAG, "Yandex RSS request failed: %s status=%d bytes=%u", esp_err_to_name(err), status, (unsigned)r.size);
        heap_caps_free(r.data);
        return "Сейчас не удалось получить главные новости из RSS. Попробуй повторить запрос позже.";
    }
    std::string xml(r.data, r.size);
    heap_caps_free(r.data);
    std::string answer = "Главные новости из ленты Яндекса. Прочитай каждую новость кратко, а после каждой добавь один короткий комментарий в своём обычном живом стиле, не выдавая предположения за факты. ";
    size_t pos = 0; int count = 0;
    while (count < 3) {
        size_t a = xml.find("<item", pos);
        if (a == std::string::npos) break;
        a = xml.find('>', a); if (a == std::string::npos) break; ++a;
        size_t b = xml.find("</item>", a); if (b == std::string::npos) break;
        const std::string item = xml.substr(a, b - a);
        std::string title = ExtractXmlTag(item, "title");
        std::string desc = ExtractXmlTag(item, "description");
        if (!title.empty()) {
            answer += "Новость "; answer += std::to_string(count + 1); answer += ": "; answer += title; answer += ". ";
            if (!desc.empty()) { if (desc.size() > 360) desc.resize(360); answer += "Кратко: "; answer += desc; answer += ". "; }
            ++count;
        }
        pos = b + 7;
    }
    if (count == 0) return "RSS-лента открылась, но в ней не удалось найти новости для чтения.";
    answer += "Не добавляй отдельное длинное вступление или заключение.";
    return answer;
}
} // namespace

ArgusVoiceQuery::ArgusVoiceQuery() { RegisterTool(); }
ArgusVoiceQuery::~ArgusVoiceQuery() = default;

void ArgusVoiceQuery::RegisterTool() {
    auto& mcp = McpServer::GetInstance();
    mcp.AddTool("self.drone_map.get_active_locations",
        "Однократно запросить текущие активные события Argus и перечислить все распознанные локации в пределах карты: Крым, Анапа, Темрюк, Азовское море и его северное побережье. ОБЯЗАТЕЛЬНО вызывай этот инструмент, если пользователь спрашивает «где летят дроны», «есть ли дроны», «что по дронам в Крыму» или о текущих угрозах. Если активных локаций нет, ответ инструмента будет «Небо чистое». Данные не опрашиваются в фоне.",
        PropertyList(), [](const PropertyList&) -> ReturnValue { return QueryArgusLocations(); });
    mcp.AddTool("self.news.get_main_news",
        "Однократно загрузить главные новости дня из RSS https://news.yandex.ru/index.rss. ОБЯЗАТЕЛЬНО вызывай при просьбах «главные новости дня», «расскажи новости», «что нового сегодня». Инструмент возвращает до трёх заголовков и кратких описаний; прочитай их вслух и после каждой добавь свой короткий комментарий в живом разговорном стиле, не выдумывая факты.",
        PropertyList(), [](const PropertyList&) -> ReturnValue { return QueryYandexMainNews(); });
}

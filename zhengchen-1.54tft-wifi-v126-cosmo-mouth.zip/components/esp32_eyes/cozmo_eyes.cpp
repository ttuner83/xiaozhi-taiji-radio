#include "cozmo_eyes.h"

#include "Face.h"
#include "eye_fb.h"

#include "esp_heap_caps.h"
#include "esp_random.h"
#include <algorithm>

namespace {

// Maps XiaoZhi emotion names onto esp32-eyes expressions.
const char* MapEmotion(const std::string& emotion) {
    if (emotion == "neutral" || emotion == "normal" || emotion == "relaxed") {
        return (esp_random() & 1) ? "normal" : "unimpressed";
    }
    if (emotion == "happy" || emotion == "loving" || emotion == "delicious") {
        return (esp_random() & 1) ? "happy" : "glee";
    }
    if (emotion == "laughing" || emotion == "funny" || emotion == "kissy" || emotion == "silly") {
        return (esp_random() & 1) ? "glee" : "awe";
    }
    if (emotion == "sad" || emotion == "crying") {
        return (esp_random() & 1) ? "sad" : "worried";
    }
    if (emotion == "angry") {
        return (esp_random() & 1) ? "angry" : "annoyed";
    }
    if (emotion == "embarrassed") {
        return (esp_random() & 1) ? "worried" : "scared";
    }
    if (emotion == "surprised" || emotion == "shocked") {
        return (esp_random() & 1) ? "surprised" : "awe";
    }
    if (emotion == "thinking" || emotion == "confident") {
        return (esp_random() & 1) ? "focused" : "skeptic";
    }
    if (emotion == "winking") {
        return (esp_random() & 1) ? "squint" : "sleepy";
    }
    if (emotion == "cool" || emotion == "confused") {
        return (esp_random() & 1) ? "skeptic" : "suspicious";
    }
    if (emotion == "sleepy") {
        return "sleepy";
    }
    return nullptr;
}

void ApplyExpression(Face* face, const std::string& expression) {
    if (expression == "angry") {
        face->Expression.GoTo_Angry();
    } else if (expression == "glee") {
        face->Expression.GoTo_Glee();
    } else if (expression == "happy") {
        face->Expression.GoTo_Happy();
    } else if (expression == "sad") {
        face->Expression.GoTo_Sad();
    } else if (expression == "worried") {
        face->Expression.GoTo_Worried();
    } else if (expression == "focused") {
        face->Expression.GoTo_Focused();
    } else if (expression == "annoyed") {
        face->Expression.GoTo_Annoyed();
    } else if (expression == "surprised") {
        face->Expression.GoTo_Surprised();
    } else if (expression == "skeptic") {
        face->Expression.GoTo_Skeptic();
    } else if (expression == "frustrated") {
        face->Expression.GoTo_Frustrated();
    } else if (expression == "unimpressed") {
        face->Expression.GoTo_Unimpressed();
    } else if (expression == "sleepy") {
        face->Expression.GoTo_Sleepy();
    } else if (expression == "suspicious") {
        face->Expression.GoTo_Suspicious();
    } else if (expression == "squint") {
        face->Expression.GoTo_Squint();
    } else if (expression == "furious") {
        face->Expression.GoTo_Furious();
    } else if (expression == "scared") {
        face->Expression.GoTo_Scared();
    } else if (expression == "awe") {
        face->Expression.GoTo_Awe();
    } else {
        face->Expression.GoTo_Normal();
    }
}

}  // namespace

CozmoEyes::CozmoEyes(int virtual_w, int virtual_h, int eye_size, int scale) {
    width_ = virtual_w * scale;
    height_ = virtual_h * scale;

    size_t bytes = static_cast<size_t>(width_) * height_ * sizeof(uint16_t);
    fb_ = static_cast<uint16_t*>(heap_caps_malloc(bytes, MALLOC_CAP_SPIRAM));
    if (fb_ == nullptr) {
        fb_ = static_cast<uint16_t*>(malloc(bytes));
    }
    g_fb.Configure(fb_, width_, height_, scale);

    face_ = std::make_unique<Face>(virtual_w, virtual_h, eye_size);
    // Keep the emotion selected by the application instead of switching randomly.
    face_->RandomBehavior = false;
    // Natural autonomous behaviour.
    face_->RandomLook = true;
    face_->RandomBlink = true;
    face_->CenterX = 60;
    face_->CenterY = 43;
    face_->EyeSize = 29;
    face_->EyeInterDistance = 8;
    face_->Expression.GoTo_Normal();
}

CozmoEyes::~CozmoEyes() {
    face_.reset();
    if (fb_ != nullptr) {
        free(fb_);
    }
}

void CozmoEyes::SetColors(uint16_t bg, uint16_t ink) {
    std::lock_guard<std::mutex> lk(mutex_);
    g_fb.bg = bg;
    g_fb.ink = ink;
}

void CozmoEyes::SetEmotion(const std::string& emotion) {
    std::lock_guard<std::mutex> lk(mutex_);
    current_emotion_ = emotion;
}

void CozmoEyes::SetSpeaking(bool speaking) {
    std::lock_guard<std::mutex> lk(mutex_);
    speaking_ = speaking;
}

void CozmoEyes::Update() {
    if (face_ == nullptr || fb_ == nullptr) {
        return;
    }

    // Hold the lock for the whole frame so SetEmotion/SetColors
    // (called from other tasks) never race the render.
    std::lock_guard<std::mutex> lk(mutex_);

    if (current_emotion_ != last_applied_) {
        const char* expr = MapEmotion(current_emotion_);
        ApplyExpression(face_.get(), expr != nullptr ? expr : "normal");
        last_applied_ = current_emotion_;
    }

    face_->Update();

    // Programmatic mouth in the lower half of the same RGB565 framebuffer.
    // Animate only while the device is actually in the speaking state.
    if (speaking_) {
        mouth_phase_ += 1;
        const int wave = static_cast<int>((mouth_phase_ / 2) % 6);
        const int mouth_w = 34 + ((mouth_phase_ / 7) % 3) * 3;
        const int mouth_h = 5 + wave * 2;
        const int cx = width_ / 2;
        const int cy = 174;
        for (int y = -mouth_h; y <= mouth_h; ++y) {
            const float ny = static_cast<float>(y) / static_cast<float>(mouth_h + 1);
            const float shape = 1.0f - ny * ny;
            const int half = static_cast<int>((mouth_w / 2) * shape);
            for (int x = -half; x <= half; ++x) {
                const int px = cx + x;
                const int py = cy + y;
                if (px >= 0 && px < width_ && py >= 0 && py < height_) {
                    fb_[py * width_ + px] = g_fb.ink;
                }
            }
        }
    } else {
        // Emotion-dependent resting mouth: a compact neutral smile/frown.
        const bool negative = current_emotion_ == "sad" || current_emotion_ == "angry" || current_emotion_ == "worried";
        const int cx = width_ / 2;
        const int cy = 176;
        for (int x = -19; x <= 19; ++x) {
            int y = cy + (negative ? -1 : 1) + (x * x) / 150;
            if (y >= 0 && y < height_) fb_[y * width_ + cx + x] = g_fb.ink;
        }
    }
}

bool CozmoEyes::IsMapped(const std::string& emotion) {
    return MapEmotion(emotion) != nullptr;
}

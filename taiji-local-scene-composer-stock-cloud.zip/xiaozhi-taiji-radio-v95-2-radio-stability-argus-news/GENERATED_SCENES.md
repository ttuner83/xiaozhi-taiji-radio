# Taiji Pi local generated-scene composer

This version works with the **stock XiaoZhi cloud server**. It does not require a custom server, server-side prompt, new websocket fields, or an image-generation API.

## How it works

1. The standard XiaoZhi server sends its normal `type: "stt"` transcript to the device.
2. Taiji runs a small local Russian phrase detector on the ESP32-S3.
3. If it detects an explicit visual request, a game invitation, a context phrase (for example a jar or shooting), or a strong-emotion phrase, it composes a temporary scene locally.
4. As a second autonomous trigger, Taiji also watches the standard XiaoZhi `emotion` metadata. Strong tags (`angry`, `shocked`, `surprised`, `crying`, `laughing`) can start a scene even when the transcript did not match a local phrase. A scene already started from STT is not restarted by the emotion event.
5. The existing LVGL renderer draws and animates the scene. On the normal `tts state: "stop"` event it waits until the scene has been visible for at least 3 seconds, then restores the normal Cosmo display. A 45-second watchdog handles a lost TTS-stop event.

Normal conversation does not start a scene. Current local trigger phrases include `давай поиграем`, `нарисуй`, `покажи`, `изобрази`, phrases about putting Cosmo in a jar or shooting at it, and deliberately intense emotional phrases such as `я в ярости`, `я в шоке`, `я в восторге`, `я тебя обожаю`, and `я умираю со смеху`. The detector normalizes Russian uppercase/lowercase text. The standard cloud emotion metadata provides an additional autonomous strong-emotion signal.

## On-device scene composition

The ESP32 creates the scene from LVGL primitives; no finished image is downloaded. The first composer contains procedural compositions for game, jar, comic shooting reaction, and strong-emotion bursts. Small deterministic layout variations are derived from the transcript. Each scene is a list of circles, rectangles, outlines, lines, and labels with independent floating motion.

## Important limits

This is local rule-based interpretation, **not an on-device LLM**. It can react autonomously to strong phrases and known semantic cues, but it cannot reliably understand every novel metaphor or invent a semantically accurate scene for arbitrary text. It also does not generate photorealistic artwork. Expanding the local phrase/scene grammar and renderer can add more scene families without changing the cloud server; fully open-ended semantic creativity would require a model or structured scene description that the stock server does not currently provide.

## Trigger contract compatibility

The renderer still accepts an optional server-provided `scene` object for compatibility with custom servers, but local STT-based scenes no longer depend on that field.

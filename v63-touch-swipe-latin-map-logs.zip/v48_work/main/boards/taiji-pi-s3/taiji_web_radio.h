#ifndef TAIJI_WEB_RADIO_H
#define TAIJI_WEB_RADIO_H

#include <string>
#include <esp_timer.h>
#include <vector>
#include "lvgl.h"

#include "esp_http_server.h"
#include "features/music/esp32_radio.h"

class TaijiWebRadio {
public:
    TaijiWebRadio();
    ~TaijiWebRadio();

    void Start();
    void Stop();

    bool PlaySelected();
    bool PlayStation(int station_number);
    bool NextStation();
    bool StopPlayback();

    // Synchronize Wi-Fi power-save mode with radio/voice-assistant activity.
    static void UpdateWifiPowerSave();

    bool IsRadioActive() const { return radio_.IsPlaying() || radio_.IsDownloading(); }
    // Manual CST816S touch handling (the board polls touch outside LVGL).
    bool HandleTouchTap(int x, int y);

private:
    struct Station {
        std::string name;
        std::string url;
        std::string type;
    };

    httpd_handle_t server_ = nullptr;
    std::vector<Station> stations_;
    Esp32Radio radio_;
    int current_slot_ = -1;

    void LoadStations();
    void SaveStation(int slot, const Station& station);
    void ClearStation(int slot);

    static esp_err_t RootHandler(httpd_req_t* req);
    static esp_err_t StationsGetHandler(httpd_req_t* req);
    static esp_err_t StationsPostHandler(httpd_req_t* req);
    static esp_err_t PlayHandler(httpd_req_t* req);
    static esp_err_t StopHandler(httpd_req_t* req);

    esp_err_t HandleRoot(httpd_req_t* req);
    esp_err_t HandleStationsGet(httpd_req_t* req);
    esp_err_t HandleStationsPost(httpd_req_t* req);
    esp_err_t HandlePlay(httpd_req_t* req);
    esp_err_t HandleStop(httpd_req_t* req);

    void StartRadio(int slot);
    bool StopRadio();
    void EnsureRadioUi();
    void ShowRadioUi(bool show);
    void UpdateRadioStationLabel();
    static void RadioUiEvent(lv_event_t* event);
    lv_obj_t* radio_ui_root_ = nullptr;
    lv_obj_t* radio_station_label_ = nullptr;
    lv_obj_t* radio_meter_needle_ = nullptr;
    esp_timer_handle_t radio_meter_timer_ = nullptr;
    int radio_meter_phase_ = 0;
    static void RadioMeterTimerCallback(void* arg);
    void UpdateRadioMeterNeedle();

    void StartSilentStandbyTimer();
    void CancelSilentStandbyTimer();
    static void SilentStandbyTimerCallback(void* arg);
    esp_timer_handle_t silent_standby_timer_ = nullptr;

    static TaijiWebRadio* instance_;
};

#endif
